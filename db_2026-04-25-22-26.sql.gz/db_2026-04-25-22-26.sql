--
-- PostgreSQL database cluster dump
--

\restrict kLjgYZuXW9yuLhmr7RuSIZcO1l3ektbWlfjKIckdBXV088TYdne8SKi2jpj0T5F

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE kvitkova_user;
ALTER ROLE kvitkova_user WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:piHHIL43vg6EhPVqcsF6wA==$cyvB/KaWSGi3K/QuS2lwD2/GenRdFlCRmnV0YLfOYMs=:1dKn6ZZCKC84HjC8NkYvoa/tSTAYLKjAHWxn7AcZUTg=';

--
-- User Configurations
--








\unrestrict kLjgYZuXW9yuLhmr7RuSIZcO1l3ektbWlfjKIckdBXV088TYdne8SKi2jpj0T5F

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict NQuiGRG1FthgwLpHJHljml24JMw0SS3riGH1XtNTnoj4KUx8N4BwqV9nbC78xzr

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict NQuiGRG1FthgwLpHJHljml24JMw0SS3riGH1XtNTnoj4KUx8N4BwqV9nbC78xzr

--
-- Database "kvitkova_crm" dump
--

--
-- PostgreSQL database dump
--

\restrict 4lupL01gFYERhCRWpDS0YLO50RlG5zsZwGvDE9DY2NJZf8PODQYRVnApyo68HCP

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: kvitkova_crm; Type: DATABASE; Schema: -; Owner: kvitkova_user
--

CREATE DATABASE kvitkova_crm WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE kvitkova_crm OWNER TO kvitkova_user;

\unrestrict 4lupL01gFYERhCRWpDS0YLO50RlG5zsZwGvDE9DY2NJZf8PODQYRVnApyo68HCP
\connect kvitkova_crm
\restrict 4lupL01gFYERhCRWpDS0YLO50RlG5zsZwGvDE9DY2NJZf8PODQYRVnApyo68HCP

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_log; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.activity_log (
    id integer NOT NULL,
    user_id integer,
    user_label character varying(100),
    action character varying(20),
    entity_type character varying(30),
    entity_id integer,
    description character varying(255),
    created_at timestamp without time zone
);


ALTER TABLE public.activity_log OWNER TO kvitkova_user;

--
-- Name: activity_log_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.activity_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.activity_log_id_seq OWNER TO kvitkova_user;

--
-- Name: activity_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.activity_log_id_seq OWNED BY public.activity_log.id;


--
-- Name: ai_agent_log; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.ai_agent_log (
    id integer NOT NULL,
    user_id integer NOT NULL,
    action_type character varying(50),
    entity_type character varying(50),
    entity_id integer,
    before_data json,
    after_data json,
    ai_message text,
    status character varying(20),
    error_msg text,
    created_at timestamp without time zone
);


ALTER TABLE public.ai_agent_log OWNER TO kvitkova_user;

--
-- Name: ai_agent_log_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.ai_agent_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.ai_agent_log_id_seq OWNER TO kvitkova_user;

--
-- Name: ai_agent_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.ai_agent_log_id_seq OWNED BY public.ai_agent_log.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO kvitkova_user;

--
-- Name: certificates; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.certificates (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    type character varying(20) NOT NULL,
    value_amount numeric(10,2),
    value_size character varying(10),
    subscription_type character varying(20),
    expires_at date NOT NULL,
    status character varying(20) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp without time zone,
    used_at timestamp without time zone,
    order_id integer,
    comment text,
    created_by_user_id integer
);


ALTER TABLE public.certificates OWNER TO kvitkova_user;

--
-- Name: certificates_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.certificates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.certificates_id_seq OWNER TO kvitkova_user;

--
-- Name: certificates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.certificates_id_seq OWNED BY public.certificates.id;


--
-- Name: client; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.client (
    id integer NOT NULL,
    instagram character varying(128),
    phone character varying(32),
    telegram character varying(128),
    credits integer,
    marketing_source character varying(64),
    personal_discount character varying(16),
    created_at date,
    name character varying(128),
    phone_viber boolean DEFAULT false NOT NULL,
    phone_telegram boolean DEFAULT false NOT NULL,
    phone_whatsapp boolean DEFAULT false NOT NULL,
    email character varying(256)
);


ALTER TABLE public.client OWNER TO kvitkova_user;

--
-- Name: client_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.client_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.client_id_seq OWNER TO kvitkova_user;

--
-- Name: client_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.client_id_seq OWNED BY public.client.id;


--
-- Name: courier; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.courier (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    phone character varying(32),
    active boolean,
    deliveries_count integer,
    telegram_chat_id bigint,
    telegram_username character varying(64),
    telegram_registered boolean,
    telegram_notifications_enabled boolean,
    last_telegram_activity timestamp without time zone,
    is_taxi boolean DEFAULT false NOT NULL,
    communication_channel character varying(20),
    nickname character varying(64),
    working_days character varying(50),
    comment text,
    rating integer
);


ALTER TABLE public.courier OWNER TO kvitkova_user;

--
-- Name: courier_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.courier_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.courier_id_seq OWNER TO kvitkova_user;

--
-- Name: courier_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.courier_id_seq OWNED BY public.courier.id;


--
-- Name: delivery; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.delivery (
    id integer NOT NULL,
    order_id integer NOT NULL,
    client_id integer NOT NULL,
    delivery_date date NOT NULL,
    status character varying(32),
    comment text,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    street character varying(128),
    building_number character varying(32),
    floor character varying(16),
    entrance character varying(16),
    is_pickup boolean,
    time_from character varying(8),
    time_to character varying(8),
    size character varying(32),
    phone character varying(32),
    courier_id integer,
    delivered_at timestamp without time zone,
    status_changed_at timestamp without time zone,
    price_at_delivery integer,
    preferences text,
    delivery_method character varying(32) DEFAULT 'courier'::character varying NOT NULL,
    address_comment text,
    bouquet_type character varying(64),
    composition_type character varying(64),
    florist_status character varying(32)
);


ALTER TABLE public.delivery OWNER TO kvitkova_user;

--
-- Name: delivery_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.delivery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.delivery_id_seq OWNER TO kvitkova_user;

--
-- Name: delivery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.delivery_id_seq OWNED BY public.delivery.id;


--
-- Name: delivery_routes; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.delivery_routes (
    id integer NOT NULL,
    courier_id integer,
    route_date date NOT NULL,
    status character varying(32) DEFAULT 'draft'::character varying NOT NULL,
    delivery_price integer,
    deliveries_count integer,
    total_distance_km double precision,
    estimated_duration_min integer,
    telegram_message_id bigint,
    sent_at timestamp without time zone,
    accepted_at timestamp without time zone,
    rejected_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    cached_result_json text,
    cached_at timestamp without time zone,
    start_time time without time zone
);


ALTER TABLE public.delivery_routes OWNER TO kvitkova_user;

--
-- Name: delivery_routes_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.delivery_routes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.delivery_routes_id_seq OWNER TO kvitkova_user;

--
-- Name: delivery_routes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.delivery_routes_id_seq OWNED BY public.delivery_routes.id;


--
-- Name: florist_sale; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.florist_sale (
    id integer NOT NULL,
    florist_id integer NOT NULL,
    created_by integer NOT NULL,
    amount numeric(10,2) NOT NULL,
    bonus_percent numeric(5,2) DEFAULT 5.0 NOT NULL,
    bonus_amount numeric(10,2) NOT NULL,
    comment text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.florist_sale OWNER TO kvitkova_user;

--
-- Name: florist_sale_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.florist_sale_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.florist_sale_id_seq OWNER TO kvitkova_user;

--
-- Name: florist_sale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.florist_sale_id_seq OWNED BY public.florist_sale.id;


--
-- Name: order; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public."order" (
    id integer NOT NULL,
    client_id integer NOT NULL,
    recipient_name character varying(128) NOT NULL,
    recipient_phone character varying(32) NOT NULL,
    recipient_social character varying(128),
    city character varying(64) NOT NULL,
    street character varying(128) NOT NULL,
    building_number character varying(32),
    floor character varying(16),
    entrance character varying(16),
    is_pickup boolean,
    size character varying(32) NOT NULL,
    custom_amount integer,
    time_from character varying(8),
    time_to character varying(8),
    comment text,
    preferences text,
    for_whom character varying(64) NOT NULL,
    created_at timestamp without time zone,
    delivery_method character varying(32) DEFAULT 'courier'::character varying NOT NULL,
    address_comment text,
    bouquet_type character varying(64),
    composition_type character varying(64),
    subscription_id integer,
    sequence_number integer,
    delivery_date date NOT NULL,
    discount integer
);


ALTER TABLE public."order" OWNER TO kvitkova_user;

--
-- Name: order_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.order_id_seq OWNER TO kvitkova_user;

--
-- Name: order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.order_id_seq OWNED BY public."order".id;


--
-- Name: prices; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.prices (
    id integer NOT NULL,
    subscription_type_id integer NOT NULL,
    size_id integer NOT NULL,
    price integer DEFAULT 0 NOT NULL
);


ALTER TABLE public.prices OWNER TO kvitkova_user;

--
-- Name: prices_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.prices_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.prices_id_seq OWNER TO kvitkova_user;

--
-- Name: prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.prices_id_seq OWNED BY public.prices.id;


--
-- Name: recipient_phone; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.recipient_phone (
    id integer NOT NULL,
    order_id integer NOT NULL,
    phone character varying(32) NOT NULL,
    "position" integer
);


ALTER TABLE public.recipient_phone OWNER TO kvitkova_user;

--
-- Name: recipient_phone_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.recipient_phone_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.recipient_phone_id_seq OWNER TO kvitkova_user;

--
-- Name: recipient_phone_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.recipient_phone_id_seq OWNED BY public.recipient_phone.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(80) NOT NULL,
    description character varying(255)
);


ALTER TABLE public.roles OWNER TO kvitkova_user;

--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO kvitkova_user;

--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: route_deliveries; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.route_deliveries (
    id integer NOT NULL,
    route_id integer NOT NULL,
    delivery_id integer NOT NULL,
    stop_order integer NOT NULL,
    distance_from_previous_km double precision,
    duration_from_previous_min integer,
    planned_arrival timestamp without time zone,
    actual_arrival timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.route_deliveries OWNER TO kvitkova_user;

--
-- Name: route_deliveries_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.route_deliveries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.route_deliveries_id_seq OWNER TO kvitkova_user;

--
-- Name: route_deliveries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.route_deliveries_id_seq OWNED BY public.route_deliveries.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    type character varying(64) NOT NULL,
    value character varying(255) NOT NULL,
    description text,
    created_at timestamp without time zone
);


ALTER TABLE public.settings OWNER TO kvitkova_user;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.settings_id_seq OWNER TO kvitkova_user;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: subscription; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.subscription (
    id integer NOT NULL,
    client_id integer NOT NULL,
    type character varying(32) NOT NULL,
    status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    delivery_day character varying(16) NOT NULL,
    time_from character varying(8),
    time_to character varying(8),
    recipient_name character varying(128) NOT NULL,
    recipient_phone character varying(32) NOT NULL,
    recipient_social character varying(128),
    city character varying(64) NOT NULL,
    street character varying(128) NOT NULL,
    building_number character varying(32),
    floor character varying(16),
    entrance character varying(16),
    is_pickup boolean DEFAULT false,
    address_comment text,
    delivery_method character varying(32) DEFAULT 'courier'::character varying NOT NULL,
    size character varying(32) NOT NULL,
    custom_amount integer,
    bouquet_type character varying(64),
    composition_type character varying(64),
    for_whom character varying(64) NOT NULL,
    comment text,
    preferences text,
    is_wedding boolean DEFAULT false NOT NULL,
    is_extended boolean DEFAULT false,
    followup_status character varying(32),
    followup_at timestamp without time zone,
    created_at timestamp without time zone,
    is_renewal_reminder boolean DEFAULT false NOT NULL,
    contact_date date,
    draft_comment text,
    draft_bank_link character varying(512),
    draft_wedding_date date,
    discount integer,
    delivery_count integer DEFAULT 4 NOT NULL
);


ALTER TABLE public.subscription OWNER TO kvitkova_user;

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.subscription_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.subscription_id_seq OWNER TO kvitkova_user;

--
-- Name: subscription_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.subscription_id_seq OWNED BY public.subscription.id;


--
-- Name: transaction; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.transaction (
    id integer NOT NULL,
    transaction_type character varying(16) DEFAULT 'credit'::character varying NOT NULL,
    client_id integer,
    amount integer NOT NULL,
    payment_type character varying(32),
    expense_type character varying(64),
    comment text,
    date date NOT NULL,
    created_at timestamp without time zone
);


ALTER TABLE public.transaction OWNER TO kvitkova_user;

--
-- Name: transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.transaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transaction_id_seq OWNER TO kvitkova_user;

--
-- Name: transaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.transaction_id_seq OWNED BY public.transaction.id;


--
-- Name: user; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public."user" (
    id integer NOT NULL,
    email character varying(120) NOT NULL,
    username character varying(80) NOT NULL,
    password_hash character varying(256) NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone,
    last_login timestamp without time zone,
    user_type character varying(20),
    display_name character varying(120),
    last_seen timestamp without time zone
);


ALTER TABLE public."user" OWNER TO kvitkova_user;

--
-- Name: user_id_seq; Type: SEQUENCE; Schema: public; Owner: kvitkova_user
--

CREATE SEQUENCE public.user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.user_id_seq OWNER TO kvitkova_user;

--
-- Name: user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: kvitkova_user
--

ALTER SEQUENCE public.user_id_seq OWNED BY public."user".id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: kvitkova_user
--

CREATE TABLE public.user_roles (
    user_id integer NOT NULL,
    role_id integer NOT NULL
);


ALTER TABLE public.user_roles OWNER TO kvitkova_user;

--
-- Name: activity_log id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.activity_log ALTER COLUMN id SET DEFAULT nextval('public.activity_log_id_seq'::regclass);


--
-- Name: ai_agent_log id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.ai_agent_log ALTER COLUMN id SET DEFAULT nextval('public.ai_agent_log_id_seq'::regclass);


--
-- Name: certificates id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.certificates ALTER COLUMN id SET DEFAULT nextval('public.certificates_id_seq'::regclass);


--
-- Name: client id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.client ALTER COLUMN id SET DEFAULT nextval('public.client_id_seq'::regclass);


--
-- Name: courier id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.courier ALTER COLUMN id SET DEFAULT nextval('public.courier_id_seq'::regclass);


--
-- Name: delivery id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.delivery ALTER COLUMN id SET DEFAULT nextval('public.delivery_id_seq'::regclass);


--
-- Name: delivery_routes id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.delivery_routes ALTER COLUMN id SET DEFAULT nextval('public.delivery_routes_id_seq'::regclass);


--
-- Name: florist_sale id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.florist_sale ALTER COLUMN id SET DEFAULT nextval('public.florist_sale_id_seq'::regclass);


--
-- Name: order id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public."order" ALTER COLUMN id SET DEFAULT nextval('public.order_id_seq'::regclass);


--
-- Name: prices id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.prices ALTER COLUMN id SET DEFAULT nextval('public.prices_id_seq'::regclass);


--
-- Name: recipient_phone id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.recipient_phone ALTER COLUMN id SET DEFAULT nextval('public.recipient_phone_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: route_deliveries id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.route_deliveries ALTER COLUMN id SET DEFAULT nextval('public.route_deliveries_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: subscription id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.subscription ALTER COLUMN id SET DEFAULT nextval('public.subscription_id_seq'::regclass);


--
-- Name: transaction id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.transaction ALTER COLUMN id SET DEFAULT nextval('public.transaction_id_seq'::regclass);


--
-- Name: user id; Type: DEFAULT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public."user" ALTER COLUMN id SET DEFAULT nextval('public.user_id_seq'::regclass);


--
-- Data for Name: activity_log; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.activity_log (id, user_id, user_label, action, entity_type, entity_id, description, created_at) FROM stdin;
\.


--
-- Data for Name: ai_agent_log; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.ai_agent_log (id, user_id, action_type, entity_type, entity_id, before_data, after_data, ai_message, status, error_msg, created_at) FROM stdin;
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.alembic_version (version_num) FROM stdin;
add_activity_log
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.certificates (id, code, type, value_amount, value_size, subscription_type, expires_at, status, created_at, used_at, order_id, comment, created_by_user_id) FROM stdin;
\.


--
-- Data for Name: client; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.client (id, instagram, phone, telegram, credits, marketing_source, personal_discount, created_at, name, phone_viber, phone_telegram, phone_whatsapp, email) FROM stdin;
1	polla_pauline	+380738386147	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
2	o.svshk	+380980295696	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
3	sergeev__serg	+380686704212	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
4	sophia.klishch	+380678987764	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
5	r__natalya	+380934584596	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
6	yar.7ka	+380933451028	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
7	o.scherbatuk	+380983901238	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
8	ev.suhinin	+380665602711	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
9	dennys_pol	+380677343550	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
10	suchasnykyakyys	+380985532522	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
11	wyshnev_sky	+380680329442	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
12	detakertchn	+380953983182	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
13	svitlana_bolman	+380634955644	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
14	izi_pizzy420	+380939684266	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
15	_im__julia_	+380951091991	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
16	uma.ksenia	+380957061776	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
17	drain.228	+380509097968	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
18	@dangelskaa	+380950049193	@dangelskaa	0	\N	\N	2026-04-22	\N	f	f	f	\N
19	kateryna_maslo._	+380663217765	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
20	natalie_dellis	+380978949882	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
21	saint.zh	+380673161570	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
22	anna_naydenko	+380636054731	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
23	alli_knopka	+380636054731	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
24	a.eto.hana	+380938357656	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
25	anastasiyagrape	+380938426664	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
26	masiuk_olena	+380981293891	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
27	levitovagolovina		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
28	viktoriav.v	+380632520856	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
29	melnyk_bogdan_	+380974329253	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
30	e.d.1a.r.d (helloiamlera)	+380500502786	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
31	nadia dorota	+380932561020	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
32	olga strzhelskaya	+380504102047	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
33	portfolioanut	+380632636872	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
34	magdya93	+380502742008	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
35	oleksandra_mahera	+380686448020	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
36	sudilkovsky	+380681248880	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
37	maryna.roo	+380950010177	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
38	shchotse	+380933387698	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
39	_vd_al_	+380637951213	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
40	ne_anastasia	+380685618783	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
41	sergey.j.kovalenko	+380675604583	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
42	fd.clinic M	+380733339103	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
43	fd.clinic L	+380733339103	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
44	mykytasoloid	+380983872550	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
45	me.dotty	+380955677501	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
46	ivan_ta_mishchenko	+380951758912	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
47	krikopolo	+380631734425	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
48	markmagura	+380979017436	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
49	dk.sm01 (iva00876)	+380503845936	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
50	anna_hanna.hello	+380939345737	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
51	bibliary	+380633828186	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
52	vikki.karakat	+380633924833	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
53	volodymyr_ukr	+380979155548	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
54	so_zhezhe	+380930554342	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
55	Akaru	+380687198398	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
56	roman_stavnykovych	+380988553910	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
57	iuliiasatarenko	+380930401469	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
58	v4d1mm	+380989549429	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
59	yolana_kamenchuk	+380955609834	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
60	Dominion		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
61	tommywhitedj	+380635338857	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
62	super_khodor	+380994494536	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
63	viktoriia_berezhnaya	+380997418935	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
64	v.kapustian	+380506761809	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
65	chelovek_bez_brovey	+380508277579	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
66	Dominion (5 букетів)		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
67	Dominion (Олег адміністрація)		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
68	Eugene.lifeisgood	+380689658896	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
69	v.yatskin	+380932050705	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
70	juliaxyoungx	+380637094900	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
71	bkht_ol	+380979414055	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
72	mvyshkovska	+380632652906	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
73	elizabeth_komar3	+380936526999	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
74	nick_henko	+380672017417	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
75	maksohrimenko	+380509214660	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
76	annakozlenkoo	+380930518755	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
77	lunkova.julia		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
78	stefy.shady	+380997124576	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
79	velichkovskaya	+380957898240	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
80	zarina.netovkina	+380973122112	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
81	darya_kolorova	+380939058266	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
82	darya_holovko		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
83	iakovlevaolga	+380504133156	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
84	mmm13sha	+380664848683	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
85	yaktokazhut	+380968206629	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
86	oleksandra_makarenko	+380509915916	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
87	serhii_moose	+380673022019	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
88	tatusya.p	+380676569191	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
89	vladkyshkan	+380930243414	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
90	bedavaleria	+380971799050	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
91	prokopenko.anzhella		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
92	anastasia_belka	+380939639685	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
93	Anatoliy.Shevchuk	+380634427767	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
94	kovalollya	+380688696239	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
95	singularkz_	+380678734545	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
96	cherniukandrei	+380965341557	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
97	timinskiy_sergey	+380980007755	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
98	@oliinyk_ira	+380634403710	@oliinyk_ira	0	\N	\N	2026-04-22	\N	f	f	f	\N
99	ndrsnk	+380664762657	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
100	anya_krasilnik	+380939702704	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
101	sergio_omelyanenko	+380932791224	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
102	julia.taranets	+380937473168	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
103	krzz73	+380994890384	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
104	artemlesovoy	+380953115283	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
105	den_maksymenko	+380638885808	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
106	from41k	+380987064180	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
107	timershaehov_denis	+380978652455	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
108	guru_1_	+380974642791	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
109	thelarsan	+380938570473	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
110	max_solovyov_drivovo	+380632795179	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
111	logachevay	+380505304348	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
112	asya_kovalenka	+380938571527	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
113	steys_kovalenko	+380951528723	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
114	kosyak18	+380733244538	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
115	мама Лілі		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
116	radko_farmer	+380974600885	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
117	vladyslav.suprun	+380950747092	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
118	yulia_klochai	+380506332604	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
119	suzi1703		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
120	gorunuchya	+380968055618	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
121	@prostokvl_di	+380507372687	@prostokvl_di	0	\N	\N	2026-04-22	\N	f	f	f	\N
122	nicolay2323	+380660094955	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
123	yarl2457	+380931697568	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
124	misterprojector	+380688639394	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
125	heretech1	+380969710365	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
126	gutsulkakseniia	+380639839160	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
127	alexandra_strlnk	+380935936986	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
128	_denis_naumenko_	+380950726509	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
129	n.tlp	+380971057810	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
130	denys_pakhomov	+380637064481	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
131	basov_ou	+380937354753	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
132	@naleksina	+380993437671	@naleksina	0	\N	\N	2026-04-22	\N	f	f	f	\N
133	slava.velizade	+380639575007	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
134	white.inside	+380964142486	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
135	ro_mczik	+380632898650	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
136	_vegas_bear	+380731877552	\N	0	\N	25	2026-04-22	\N	f	f	f	\N
137	a_olegovuch	+380630553160	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
138	sophy.barysheva	+380685470037	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
139	natasha_abr	+380931850411	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
140	shevyira	+380991923902	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
141	yulia_zaychenko_		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
142	denys_tretiak	+380687446392	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
143	nastyakudasheva	+380987673583	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
144	izabellayurievna	+380968548888	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
145	bogdan.behold	+380936343873	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
146	maks.fox_33	+380988723168	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
147	liubov.revutska	+380965324488	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
148	karinakrava	+380631099010	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
150	chillvanix	+380930360104	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
151	darka_zakrevska	+380660110886	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
152	honcharruk	+380978820691	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
153	vladislavgladky	+380939784839	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
154	and_chokhliad	+380930558636	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
155	Іващенко Володимир (whats up)	+380672332945	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
156	viziryakina (UGC)	+380684225088	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
157	kiravasylievaa (UGC)	+380689920404	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
158	roman_from_uae	+380932110293	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
159	mofot57815	+380931935192	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
160	the_vlad_	+380938266541	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
161	the.kir.ko		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
162	talay_in	+380638423850	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
163	Андрій	+380969657837	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
164	rastishka087	+380957780768	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
165	Лєра		\N	0	\N	10	2026-04-22	\N	f	f	f	\N
166	napiv_robot	+380631533300	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
167	victoriia_tory	+380634253688	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
168	serhiiy_herts	+380991391878	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
169	anna_stylist_ukraine	+380966570192	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
170	lilith__a	+380979528683	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
171	o.kruhlov	+380672366170	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
172	daniilalexandrovich	+380932474080	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
173	natali.tereschuk	+380677641661	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
174	@Eli24_seg	+380678201612	@Eli24_seg	0	\N	\N	2026-04-22	\N	f	f	f	\N
175	lebov460	+380730794922	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
176	olesia_pavlovnaa	+380502269806	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
177	mr.crosss	+380932729150	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
178	@Vik_Y	+380505923183	@Vik_Y	0	\N	10	2026-04-22	\N	f	f	f	\N
179	vl.mykhalko	+380507135061	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
180	vadi.belousov	+380935177477	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
181	i.vadimko	+380969015861	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
182	stanislav__55555	+380503281191	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
183	chay0chek	+380934326868	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
184	v.zemlyanichka	+380935178975	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
185	rusofobiia	+380961171177	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
186	leonenko.dmitry	+380990461812	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
187	andrii_popovych	+380935936937	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
188	anastasiapohodiy.999s	+380992192105	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
189	hwldmr	+380975117727	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
190	garikkalantarov	+380988087077	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
191	snorlax	+380957394684	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
192	Клієнт Анна (разова)	+380939322415	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
193	_vznn_	+380684225450	\N	0	Тікток	\N	2026-04-22	\N	f	f	f	\N
194	qnt_ang	+380976969999	\N	0	Тікток	\N	2026-04-22	\N	f	f	f	\N
195	pshenychnyy_artem	+380684475144	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
196	halynaboiko_art	+380635322030	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
197	dimalexp	+380939075136	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
198	holubovv	+380934062791	\N	0	Тікток	\N	2026-04-22	\N	f	f	f	\N
199	yuliia_rytsyk_smm	+380500536265	\N	0	контент інстаграм	5	2026-04-22	\N	f	f	f	\N
200	mbryl	+380503302337	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
201	Оффлайнклієнт (разова)		\N	0	побачили офлайн	\N	2026-04-22	\N	f	f	f	\N
202	epodgaetskiy	+380501917592	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
203	tarasproniv	+380985444497	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
204	julia_firefly	+380731622316	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
205	alisa_shepard	+380674928072	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
206	mar.mishitina (UGC)	+380990161911	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
207	dixon_che	+380979378565	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
208	yuriy.katsarskiy	+380937705659	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
209	vn_novoseltseva	+380668881491	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
210	andrey_yankovskii	+380665007431	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
211	yegor.kuts	+380671201222	\N	0	контент інстаграм	5	2026-04-22	\N	f	f	f	\N
212	naasic	+380932333221	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
213	d.yara___	+380953922368	\N	0	UGC/блогери	\N	2026-04-22	\N	f	f	f	\N
214	eugenecbybw	+380635126214	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
215	natalieklymenko	+380675952442	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
216	artem.zaritskyi	+380502540008	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
217	sasha_okhota	+380501445551	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
218	anastasia.bugai_		\N	0	розповіли друзі	10	2026-04-22	\N	f	f	f	\N
219	oblyvachekaterina	+380662421595	\N	0	UGC/блогери	\N	2026-04-22	\N	f	f	f	\N
220	katerynas	+380678539329	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
221	viktor.yashchenko	+380505356003	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
222	dimka_pashtepa	+380979840888	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
223	butterfly_effect.dd		\N	0	побачили офлайн	10	2026-04-22	\N	f	f	f	\N
224	anna.lakshtanova	+380995211322	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
225	lerian_sunshine	+380977338121	\N	0	розповіли друзі	10	2026-04-22	\N	f	f	f	\N
226	sergiy_razubaev	+380972538383	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
227	igoro_b	+380970227288	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
228	aleksandrr.h	+380678421143	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
229	_amp_r	+380668772554	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
230	iryna.lukashevych	+380939394079	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
231	julekkharkova	+380976692200	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
232	alexnevskyy	+380932716939	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
233	alexandrov_282		\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
234	juli_khomutianska	+380678539329	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
235	ket.tet4er	+380630671437	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
236	k.margarita_a	+380689654024	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
237	sviatoslavshkurko	+380502267783	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
238	anastasia.plehova	+380934534000	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
239	vrindakunda_		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
240	anastasiia_ivashyna	+380664265222	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
241	cheftelova_anna	+380963662263	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
242	denis_kudin	+380679148763	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
243	avolkaolka		\N	0	гугл пошук	\N	2026-04-22	\N	f	f	f	\N
244	oreh.orehovich	+380505558000	\N	0	контент інстаграм	10	2026-04-22	\N	f	f	f	\N
245	keyda.666		\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
246	serezhabordyug	+380986424806	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
247	sat_an	+380930401469	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
248	lissalisa.s	+380934555117	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
249	ol.humeniuk	+380639355506	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
250	omivancenobi	+380672203240	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
251	victoriademchuk	+380636394493	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
252	natalie_velko	+380976074080	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
253	markus060899	+380665969872	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
254	@dendoncer	+380987730305	@dendoncer	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
255	_tfortelnay_	+380983250505	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
256	aspislunaris	+380986232467	\N	0	гугл пошук	10	2026-04-22	\N	f	f	f	\N
257	magrit.gmaster	+380937675758	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
258	vadvolk	+380961119325	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
259	gliwinskiy	+380675443334	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
260	ariiie.ll		\N	0	\N	20	2026-04-22	\N	f	f	f	\N
261	annvelkova	+380731520205	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
262	Аліна	+380509752940	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
263	kryvo_viktor		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
264	@vitnok	+380937548009	@vitnok	0	\N	\N	2026-04-22	\N	f	f	f	\N
265	Ярик	+380975303997	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
266	baraburu	+380509171463	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
267	turlo_dmitriy	+380661761018	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
268	melena07	+380676754000	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
269	dolmatov_denis	+380632622655	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
270	Владос	+380664292296	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
272	taniahorda	+380979205990	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
149	0007_artem	+380937581026	\N	0	розповіли друзі	10	2026-04-22	\N	f	f	f	\N
273	tatiana_t_br	+380966940796	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
274	Ірина (oreh.orehovich)	+380731088820	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
275	artisans. ua	+380957954595	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
276	kulbachko_v.s	+380665848204	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
277	dasha8ka		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
278	svitlana__fedoruk	+380937790973	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
279	smoked.semga	+380677665212	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
280	@Blaskoo	+380506167723	@Blaskoo	0	\N	\N	2026-04-22	\N	f	f	f	\N
281	alla4526	+380679209090	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
282	vyshnev_sky	+380680329442	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
283	dr.kolominskaya	+380504560115	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
284	bodriy77	+380730586465	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
286	max_mel_ua	+380503858670	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
287	igorkushnir	+380936846666	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
288	annaaa_sabov	+380939966522	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
289	max_kavas	+380988657782	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
290	_.dmytro._.igorovich._	+380931527444	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
291	_detaker_	+380674093256	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
292	Катя і Ренат (Весільна підписка)	+380675604982	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
293	oleksiik05	+380506815855	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
294	s_l_on	+380635838197	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
295	antoniofarando	+380994809708	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
296	denys_lakusta	+380977219806	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
297	m_lykhoshvai	+380668924391	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
298	maxym_nikitin	+380999803197	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
299	rudnitskih	+380969818032	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
300	_techer_	+380990794929	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
301	artem_lime	+380984934309	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
302	vitaliy.krylov	+380631442129	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
303	yermolovych_d	+380971984262	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
304	r.omansa		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
305	illia_sherstiuk	+380938854337	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
306	firstmaryna	+380730680990	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
307	nikolaybelokon	+380501550395	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
308	xany.rar	+380992872019	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
309	natamohnata	+380503101561	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
310	boni_fase	+380663727389	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
311	akamamor	+380633354053	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
312	neoncomp	+380508193528	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
313	@karocheya	+380955941504	@karocheya	0	\N	5	2026-04-22	\N	f	f	f	\N
314	neikr1		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
315	olexandr_marusyak95	+380994432728	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
316	@alextve	+380934554095	@alextve	0	\N	\N	2026-04-22	\N	f	f	f	\N
317	s_derebera	+380630644930	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
318	garmash.football	+380964727947	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
319	art.kukh	+380931850411	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
320	kittsunnne	+380997556889	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
321	ievgen_malikov	+380937759446	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
322	Ілюшка	+380668229179	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
323	@vasylchaban	+380509621070	@vasylchaban	0	\N	10	2026-04-22	\N	f	f	f	\N
324	agneshka_odr	+380937050050	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
325	fisherious	+380967564048	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
326	burya4ok_ua	+380968163969	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
327	dmitro2250	+380979810519	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
328	beatus_taras		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
329	yurchik.blinov	+380632731718	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
330	helennnn.p	+380683578678	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
331	iamalexander09	+380630425025	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
285	yulia.psychologist	+380988343411	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
332	sergiy_razubaev (корп замовлення)	+380961858578	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
333	romanvozbrannyi	+380951652925	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
334	emilgerashchenkov	+380950657198	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
335	olha_shustra	+380674045114	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
336	Олег (Клієнт Запоріжжя)	+380962998483	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
337	yana_aleksyeyenko	+380503340689	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
338	migunov_m_	+380671353651	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
339	zhembotskyi	+380989718057	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
340	tymirina	+380508778172	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
341	volola_	+380993163814	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
342	kirill_vorobiov_997	+380953557750	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
343	alex_kraft	+380509012701	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
344	69_kalia_69	+380999283538	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
345	Юрій (Самовивіз)		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
346	qua5ar	+380738981488	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
347	Олег (доставка Біла церква)		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
348	shugaychik	+380633724228	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
349	stepankevich_		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
350	mark__4e__	+380991705037	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
351	yariksegen7	+380632627353	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
352	voronko.vl	+380951982648	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
353	Олена Хмелюк	+380973926519	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
354	@ketbarn	+380672647647	@ketbarn	0	\N	\N	2026-04-22	\N	f	f	f	\N
355	Олександр	+380733241309	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
356	@Kaparica(тг)	+380661918594	@Kaparica(тг)	0	\N	\N	2026-04-22	\N	f	f	f	\N
357	@danyl_romanov	+380931115199	@danyl_romanov	0	\N	\N	2026-04-22	\N	f	f	f	\N
358	bodya_pewpew	+380970109855	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
271	irinaeroshenko84	+380674679249	\N	0	розповіли друзі	10	2026-04-22	\N	f	f	f	\N
359	Кукс	+380953348177	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
360	Клієнт 1 (по телефону)		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
361	anna_houdiakova	+380996006156	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
362	krssh_	+380507269575	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
363	elena.jyoti	+380958600108	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
364	alexhashek	+380975307229	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
365	silverhand__johnny_silverhand	+380996548443	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
366	yaroslav_bastun1	+380987603053	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
367	wedding_in_karpathians		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
368	yaroslav.petlivchuk	+380931527444	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
369	alionka_kolinko	+380979296085	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
370	vvladyslavva_	+380954724973	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
371	thatside_ua	+380680976527	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
372	blablamasha	+380675657357	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
373	maryna.didenko	+380934467115	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
374	dr.svitlana_dovhaliuk	+380985643385	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
375	@vbpgm	+380973532089	@vbpgm	0	\N	\N	2026-04-22	\N	f	f	f	\N
376	anzhelika.liashenko		\N	0	\N	100	2026-04-22	\N	f	f	f	\N
377	nkali_	+380632245930	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
378	marnin_inc	+380936623659	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
379	nizhno.olena	+380975202210	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
380	ma.estet	+380505783310	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
381	helen_khrulenko	+380932627827	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
382	tanushka20	+380953540020	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
383	shcherbatiuk__svitlana	+380630242742	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
384	m.butinskaia	+380632873292	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
386	pancatsky	+380932902905	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
387	art.tema__	+380962450849	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
388	s_mastilovskyi	+380634696085	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
389	oshyshman	+380664355400	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
390	sokolovsky___ihor	+380990460838	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
391	vshmrsky	+380680202074	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
392	phynnerris	+380931527444	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
393	anashapovalova	+380509624159	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
394	marton4ik_	+380504465357	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
395	kodifav	+380638067519	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
396	life_isap	+380504195590	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
397	anytamacya	+380991630376	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
398	da.sha.ku	+380991950119	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
399	lion_style_yt	+380951041172	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
400	styhiya_ph	+380674841444	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
401	vi_kvim	+380502587320	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
402	1foxbird2	+380689949884	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
403	katya.shypovska	+380975848281	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
404	charlie.bravo.01	+380500853916	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
405	nikolenkotatyana	+380934278045	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
406	olga__kuryshko	+380503706343	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
407	grigorjevskaja.olga	+380509005670	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
385	vasylevska	+380503567113	\N	0	постійний клієнт	10	2026-04-22	\N	f	f	f	\N
408	alisaphunter	+380683502524	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
409	yanaantonyuk	+380635731736	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
410	marieopapa	+380992436656	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
411	oleksandr_bakhmach	+380993594894	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
412	boyko.iam	+380669143517	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
413	an.dovbysh	+380939363118	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
414	vvvv0000777	+380677883702	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
415	nimets_irina		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
416	Аня Максименко		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
417	maksym_sokol	+380669167362	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
418	5133pwa1k3r	+380635373792	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
419	anastacy.ss	+380634349108	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
420	o.gulevka	+380972286184	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
421	poputchikkkkkk	+380973131636	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
422	marusya.club	+380952503022	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
423	dmytro_naum	+380678375174	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
424	lyudmyla_deynychenko		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
425	n.byshevych	+380674463545	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
426	mariiashpiro	+380931442493	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
427	nadiyapgv	+380983057076	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
428	sonyamerzlikina	+380664551450	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
430	bogdan.khomutov	+380935302553	\N	0	Тікток	\N	2026-04-22	\N	f	f	f	\N
431	chilikova_julli	+380634686108	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
432	chytlit.chytlit	+380632286441	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
433	a.vs4n	+380661990101	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
434	ok.agency	+380956481005	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
435	tanya_bondaa	+380630368068	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
436	dobriy_nrav_	+380660148742	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
437	tyap4uk1988	+380973995757	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
438	ltcodename	+380636087217	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
439	lenaveselova1981	+380674928728	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
440	anaaakliepova	+380636562451	\N	0	Тікток	\N	2026-04-22	\N	f	f	f	\N
441	sidorov4474	+380967593098	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
442	yulia.kotiuk	+380931237241	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
443	igrikp7	+380939092791	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
444	inna.zdesenko	+380985997799	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
445	koalooo	+380992246646	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
446	Тоха з Мастер Шеф	+380952043686	\N	0	Тікток	5	2026-04-22	\N	f	f	f	\N
447	zhora_i_ezhi	+380639827596	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
448	tania_cozy_kohut	+380990771670	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
449	pyshnenkoaleksei		\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
450	dasha_felger	+380937049024	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
451	rubankos	+380505384342	\N	0	Тікток	\N	2026-04-22	\N	f	f	f	\N
452	uwuwu9231	+380954118251	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
453	@rosina_moginska		@rosina_moginska	0	\N	\N	2026-04-22	\N	f	f	f	\N
454	ramon453	+380637016700	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
455	janamazurash	+380674797635	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
456	dimakovalevskyi	+380684150519	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
457	sasha_shulhin	+380680621838	\N	0	гугл пошук	10	2026-04-22	\N	f	f	f	\N
458	yulia_gavelya (UGC)	+380681448357	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
459	rom81svv	+380957954595	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
460	mykola_fedko	+380955384235	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
461	guide.in.a.hat	+380955433850	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
462	lalakrista09	+380502229827	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
463	kr.zvg	+380980011641	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
464	k.sheketa	+380958413931	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
465	alicolenco	+380979713623	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
466	@Viktjuk	+380930775985	@Viktjuk	0	\N	\N	2026-04-22	\N	f	f	f	\N
467	@Jan_Pawel_Drugi	+380504184406	@Jan_Pawel_Drugi	0	\N	\N	2026-04-22	\N	f	f	f	\N
468	r_kreg	+380668447841	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
469	ksen_ivanova9	+380677344429	\N	0	UGC/блогери	\N	2026-04-22	\N	f	f	f	\N
470	maria_evdokimova	+380672602999	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
429	ya.katron	+380938157670	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
471	maximus696merciful	+380637688818	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
472	skarlat.yuliia	+380989558500	\N	0	гугл пошук	\N	2026-04-22	\N	f	f	f	\N
473	alina_lizina	+380673705111	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
474	alina.gaydar	+380504560115	\N	0	розповіли друзі	5	2026-04-22	\N	f	f	f	\N
475	yevhenikka		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
476	zaborska.ya	+380991234504	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
477	brbnw	+380933779767	\N	0	побачили офлайн	10	2026-04-22	\N	f	f	f	\N
478	grebeniuk__	+380938133299	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
479	dr.kryvetska	+380673705111	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
480	ingigerdaaa	+380672359406	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
481	maria.panasiy	+380963010171	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
482	_desport	+380999069682	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
483	lis.avrm	+380668816281	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
484	lilia_kashyrina	+380660135682	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
485	innesa_garden	+380964640740	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
486	Alex.seo	+380971170775	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
487	nastia_bali	+380932020231	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
488	ilisovyii	+380682853112	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
489	ya_radzievska	+380667172291	\N	0	постійний клієнт	\N	2026-04-22	\N	f	f	f	\N
490	@SofiZu	+380680848848	@SofiZu	0	\N	\N	2026-04-22	\N	f	f	f	\N
491	zheleznyak.ua	+380503460098	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
492	kkaminskaya	+380669994707	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
493	elizabeth.and.art	+380503432066	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
494	nosyrendezvous	+380666123398	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
495	vlad._kucherenko	+380960810643	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
496	Тетяна(кураж)	+380630344657	\N	0	побачили офлайн	\N	2026-04-22	\N	f	f	f	\N
497	annaheaven	+380676133613	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
498	Ольга (Кураж)	+380951108747	\N	0	побачили офлайн	\N	2026-04-22	\N	f	f	f	\N
499	@AlbinaKukharchuk	+380961896936	@AlbinaKukharchuk	0	\N	\N	2026-04-22	\N	f	f	f	\N
500	ninarakelian	+380952801780	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
501	alliiss.on	+380964994045	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
502	valerie_bzenko	+380966724224	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
503	vvasyletskyy	+380939309870	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
504	askorbenko_wedding	+380962503792	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
505	svetlanaa.gl	+380996362135	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
506	kerchik7700	+380636014549	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
507	hanna_hurko_psy	+380668272390	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
508	anastasssi.a	+380997011108	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
509	@ivn_k	+380936600036	@ivn_k	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
510	sash.kin	+380931298868	\N	0	UGC/блогери	100	2026-04-22	\N	f	f	f	\N
511	dr.hanna.parkhomenko	+380939349948	\N	0	UGC/блогери	\N	2026-04-22	\N	f	f	f	\N
512	anelie.ya	+380639916896	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
513	kresttena	+380660823577	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
514	Паша Козачок	+380963455676	Паша Козачок	0	побачили офлайн	\N	2026-04-22	\N	f	f	f	\N
515	korolkirill_	+380971162542	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
516	maria_viktoriiaa	+380961135002	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
517	tati__williams	+380937364350	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
518	olenka.dekhtiaruk	+380677238394	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
519	lana_zhuk		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
520	pohrebniak_n	+380931298198	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
521	Павло(сайт)	+380678853213	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
522	lebedevalebedevalebedeva	+380950820837	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
523	rozzman_	+380663677726	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
524	alexkomova	+380938182166	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
525	aartur.io	+380506215507	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
526	Кристина Попкова (сайт)	+380504755859	\N	0	гугл пошук	5	2026-04-22	\N	f	f	f	\N
527	Ivan	+380961378570	\N	0	гугл пошук	\N	2026-04-22	\N	f	f	f	\N
528	anna_levus	+380978139185	\N	0	контент інстаграм	10	2026-04-22	\N	f	f	f	\N
529	Денис(сайт)	+380674185869	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
530	dmitro.karpenko		\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
531	kyivux	+380664379613	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
532	sb.kristina13	+380666553119	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
533	shklovetss	+380972623939	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
534	sannya.l	+380935722917	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
535	@IlliaDemydov		@IlliaDemydov	0	гугл пошук	\N	2026-04-22	\N	f	f	f	\N
536	mxmskch	+380964009370	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
537	olha_boiko1	+380958028728	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
538	ganyatko	+380507529485	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
539	ksyusha_babenkova	+380984565131	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
540	alena_naumenkko		\N	0	UGC/блогери	\N	2026-04-22	\N	f	f	f	\N
541	lenamokrenko	+380977489133	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
542	@willowyveronika	+380980914841	@willowyveronika	0	розповіли друзі	15	2026-04-22	\N	f	f	f	\N
543	Олександр(сайт)	+380660809519	\N	0	гугл пошук	\N	2026-04-22	\N	f	f	f	\N
544	Артур(сайт)	+380934849348	\N	0	гугл пошук	\N	2026-04-22	\N	f	f	f	\N
545	so.wedding.ua - @vika_yanchuk12	+380500542767	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
546	srgmas	+380936076440	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
547	karnaricompany	+380502899551	\N	0	гугл пошук	\N	2026-04-22	\N	f	f	f	\N
548	@Lori_Loyj	+380955976183	@Lori_Loyj	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
549	olga_pushka	+380962264326	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
550	Олег	+380500542767	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
551	@Soloviova_Olha		@Soloviova_Olha	0	побачили офлайн	\N	2026-04-22	\N	f	f	f	\N
553	@vmikhailets	+380938104923	@vmikhailets	0	\N	\N	2026-04-22	\N	f	f	f	\N
554	deadinside.forever_	+380934785566	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
555	irasiz	+380931917895	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
556	funtasty_event.agency	+380936236570	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
557	lavender.wedding - a.zhuravka	+380679655416	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
558	@U_5_3_R_N_4_M_3	+380970385771	@U_5_3_R_N_4_M_3	0	Таргет	10	2026-04-22	\N	f	f	f	\N
559	@myushchyshyn	+380663714466	@myushchyshyn	0	розповіли друзі	10	2026-04-22	\N	f	f	f	\N
560	omir.olhord	+380679080075	\N	0	контент інстаграм	100	2026-04-22	\N	f	f	f	\N
561	valeria_chantseva		\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
562	juleeseas	+380684811741	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
563	tetianagozha	+380937078155	\N	0	UGC/блогери	\N	2026-04-22	\N	f	f	f	\N
564	che_lik	+380975903535	\N	0	розповіли друзі	5	2026-04-22	\N	f	f	f	\N
565	@eugenie_pl	+380504429583	@eugenie_pl	0	побачили офлайн	\N	2026-04-22	\N	f	f	f	\N
566	lavender.wedding 2 - \nloginoriginal	+380997098603	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
567	jspase	+380634950193	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
568	Валерія(сайт)	+380956109308	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
569	potaninroma	+380938133299	\N	0	розповіли друзі	10	2026-04-22	\N	f	f	f	\N
570	denis.piliai	+380631596401	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
552	@antipinio	+380504633358	@antipinio	0	постійний клієнт	\N	2026-04-22	\N	f	f	f	\N
571	svitlanakravchenko_	+380931011490	\N	0	побачили офлайн	\N	2026-04-22	\N	f	f	f	\N
572	@Pasha_Rybenko	+380965875275	@Pasha_Rybenko	0	\N	\N	2026-04-22	\N	f	f	f	\N
573	star.linka	+380973093279	\N	0	гугл пошук	\N	2026-04-22	\N	f	f	f	\N
574	goncharovaksenia	+380971057810	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
575	buchmills	+380977670527	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
576	vladi2512	+380679483720	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
577	Роман	+380504268230	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
578	@sailor_17	+380508176890	@sailor_17	0	\N	5	2026-04-22	\N	f	f	f	\N
579	o.karachova	+380974766043	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
580	meliora._		\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
581	@Faina_Harmash	+380633687766	@Faina_Harmash	0	\N	\N	2026-04-22	\N	f	f	f	\N
582	coach_kapon_team	+380933722811	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
583	appolin27		\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
584	namaximum.events - terletskaya.k	+380633550384	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
585	@Goddesthebeautiful	+380985578356	@Goddesthebeautiful	0	\N	\N	2026-04-22	\N	f	f	f	\N
587	the_day_ua		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
588	andrii.slipukha	+380934325070	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
589	@luck_is_not_exuse	+380635315923	@luck_is_not_exuse	0	\N	\N	2026-04-22	\N	f	f	f	\N
590	kirilkononchuk2018	+380636330294	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
591	matvii_kovbasa	+380972825555	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
592	@fosterposter	+380676125686	@fosterposter	0	\N	10	2026-04-22	\N	f	f	f	\N
593	denis.shebeko	+380678445212	\N	0	гугл пошук	100	2026-04-22	\N	f	f	f	\N
594	julia_julya	+380981299967	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
595	karinalovinska	+380734792811	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
596	alexandr0949	+380990384888	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
597	tanyafffa	+380676626486	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
598	bohdan1rt	+380681979071	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
599	@MDeshka	+380951585683	@MDeshka	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
600	aqui.lon	+380673994411	\N	0	UGC/блогери	\N	2026-04-22	\N	f	f	f	\N
601	irina_volodievna	+380931669045	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
602	polyvanaya_karinaa	+380673803909	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
603	Тетяна Кагадій (сайт)	+380666494149	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
604	Клієнт Весільна ( 14.10)	+380962503792	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
605	maks.zatynaychenko	+380665060740	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
606	anton77792025	+380936334014	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
607	its.darinochka	+380955540337	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
608	@Ikhriapin	+380979402983	@Ikhriapin	0	\N	\N	2026-04-22	\N	f	f	f	\N
609	2 Сергій (вотсап) 093 578	+380988100404	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
610	Марина - yulia.psychologist	+380988343411	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
611	goncul_cooperation	+380730479264	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
612	0 66 878 8148 Gleb Beketov	+380999307656	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
613	0 93 111 5199 Dariya Shutyleva	+380739922299	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
614	valery_eatinkyiv	+380936302810	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
615	lvloroz	+380987182252	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
616	abpacaz@gmail.com(сайт)	+380504429583	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
617	ksenia.khonii	+380936315727	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
618	SG	+380979448184	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
619	moolooko__	+380984884343	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
620	pavlenko_ldml	+380939540166	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
621	Natalia (сайт)	+380675069986	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
622	karyna.huk	+380674195539	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
624	@Tomoki	+380932375940	@Tomoki	0	\N	\N	2026-04-22	\N	f	f	f	\N
625	mariastriha	+380503566639	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
626	tatyana_sob		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
627	@Mike_Kovtun	+380682668787	@Mike_Kovtun	0	\N	\N	2026-04-22	\N	f	f	f	\N
628	@HannaNetrebska	+380689374919	@HannaNetrebska	0	\N	\N	2026-04-22	\N	f	f	f	\N
629	romepenko	+380632272425	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
630	Лариса(сайт)	+380953217624	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
631	you_never_know_you_never_know	+380939265645	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
632	ulastanislavska_ad	+380935060766	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
633	Олександр(сайт) - Наталія Пасічна	+380633647646	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
634	@portyeq	+380969991654	@portyeq	0	\N	\N	2026-04-22	\N	f	f	f	\N
635	olena_syn_	+380993622375	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
636	oshyshman 2 (kimka.li)	+380503829449	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
637	oshyshman 3 (ruda.alya)	+380639972388	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
638	denys.sirchenko	+380939364764	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
639	@Mslinos	+380503053236	@Mslinos	0	побачили офлайн	15	2026-04-22	\N	f	f	f	\N
640	y.vovk_	+380685475845	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
641	beardcat68	+380997756141	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
623	marianna_altukhova	+380664123410	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
586	\N	+380666746225	\N	0	\N	25	2026-04-22	Владос(Білобров)	f	f	f	\N
642	Оффлайн клієнт (26.11)	+380933898294	\N	0	Таргет	15	2026-04-22	\N	f	f	f	\N
643	@dnskh_cooperation	+380966509672	@dnskh_cooperation	0	\N	100	2026-04-22	\N	f	f	f	\N
644	@LinaVolontyr	+380637195161	@LinaVolontyr	0	\N	15	2026-04-22	\N	f	f	f	\N
645	@ShutnickJr	+380952859465	@ShutnickJr	0	\N	15	2026-04-22	\N	f	f	f	\N
646	Офлайн клієнт		\N	0	\N	15	2026-04-22	\N	f	f	f	\N
647	oksanita	+380505579268	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
648	zherebelovska	+380931834945	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
649	ssamchukk	+380986382262	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
650	makarovska_tanya	+380660799711	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
651	seregagusev72024	+380635645956	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
652	lizabeth.fox	+380638089041	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
653	dima75244	+380976605968	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
654	Кав'ярня		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
655	ruslan_punch	+380683434714	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
656	Sviatoslav Tarasenko - 0 50 800 90	+380508009052	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
658	avonakina	+380507493577	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
659	jenya_butler		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
660	Валерія Товстолєс	+380631345225	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
661	+380979527244	+380979527244	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
662	d.skachidub	+380970940099	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
663	v_novik	+380635972297	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
664	mrgrape777	+380958705987	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
665	jorgeenelmundo	+380673255791	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
666	kira_lisman	+380959059908	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
667	@kate_deu	+380675861254	@kate_deu	0	\N	\N	2026-04-22	\N	f	f	f	\N
668	_alina_doroshenko_		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
669	psy.oksana.sidun	+380677746504	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
670	valeriya.gaidukevych		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
671	@syanushevych	+380635953069	@syanushevych	0	\N	\N	2026-04-22	\N	f	f	f	\N
672	thisisannya	+380669296330	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
673	valeriie.13	+380667242675	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
674	@kolosovaaaam	+380637763294	@kolosovaaaam	0	\N	\N	2026-04-22	\N	f	f	f	\N
675	@llless	+380675061581	@llless	0	\N	\N	2026-04-22	\N	f	f	f	\N
676	@lil_nik	+380500803066	@lil_nik	0	\N	\N	2026-04-22	\N	f	f	f	\N
677	alina_tsviak		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
678	Natalie Padalka	+380639507722	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
679	mint_drop	+380667862609	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
680	@rst_rvr	+380957509479	@rst_rvr	0	\N	\N	2026-04-22	\N	f	f	f	\N
681	may.yarr_		\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
682	Паханчик	+380506400810	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
683	@victoriaprotsenko	+380660634688	@victoriaprotsenko	0	\N	\N	2026-04-22	\N	f	f	f	\N
684	tsaruchok	+380633806699	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
685	ye.olena	+380931276183	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
686	vladgeleshko	+380964369763	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
687	ksu_klymenko	+380633432683	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
688	0 50 462 700(сайт)	+380505468528	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
689	coasty_right	+380633018035	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
690	ann.vasilieva		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
691	daniela_ikim	+380683808345	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
692	olya_olya_m	+380677730522	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
693	@bonfire_0	+380635079161	@bonfire_0	0	\N	\N	2026-04-22	\N	f	f	f	\N
694	Samantha Gullion (seleneschild@gmail.com)	+380631144585	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
695	@xomenkoN	+380973451765	@xomenkoN	0	\N	5	2026-04-22	\N	f	f	f	\N
696	Ярон (підписка XXL)	+380666959041	\N	0	\N	25	2026-04-22	\N	f	f	f	\N
697	tania_drama	+380988849193	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
698	@Rare1_1	+380660797526	@Rare1_1	0	\N	\N	2026-04-22	\N	f	f	f	\N
699	@yu_z_art	+380933737393	@yu_z_art	0	\N	\N	2026-04-22	\N	f	f	f	\N
700	darina_diachuk		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
701	trigovai_	+380983981268	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
702	vkostiuk	+380930182101	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
703	shved_artphoto	+380675063590	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
704	@leka_np	+380500550032	@leka_np	0	\N	100	2026-04-22	\N	f	f	f	\N
705	ba.ser	+380962788368	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
706	shemraika	+380993749966	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
707	@trubadur3d	+380931633293	@trubadur3d	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
708	@Dr_urology	+380976216423	@Dr_urology	0	\N	\N	2026-04-22	\N	f	f	f	\N
709	daria_za	+380988777222	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
710	chewie1337	+380635920795	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
711	amelina_oleksandra	+380680808282	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
712	andreydolinskyy	+380930045677	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
713	rekrut_juliya	+380930732003	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
714	nazarovaalena	+380639775557	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
657	byshovets_m	+380988100404	\N	0	постійний клієнт	10	2026-04-22	\N	f	f	f	\N
715	@shumakova_natalia	+380506955193	@shumakova_natalia	0	\N	\N	2026-04-22	\N	f	f	f	\N
716	0676902810 вотцап(сайт)	+380935641375	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
717	0679572538 - вотцап(сайт)	+380965466770	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
718	@cosm_alina	+380660088171	@cosm_alina	0	\N	\N	2026-04-22	\N	f	f	f	\N
719	@shadow1330	+380954066757	@shadow1330	0	\N	\N	2026-04-22	\N	f	f	f	\N
720	Maria	+380662536991	Maria	0	\N	\N	2026-04-22	\N	f	f	f	\N
721	3 Сергій (вотсап) 093 578	+380633446653	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
722	0664473644 вайбер	+380995377440	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
723	@sfhswym	+380676301500	@sfhswym	0	\N	\N	2026-04-22	\N	f	f	f	\N
724	anastasia.strilets	+380662074061	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
725	bezsmertna_angelina	+380971050015	\N	0	\N	100	2026-04-22	\N	f	f	f	\N
726	julia_grishko		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
727	turik_ivan	+380681517660	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
728	_zakha.rrr_	+380972751645	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
730	olya_iva (daria_basarab)	+380676695511	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
731	vkashernaya	+380631470253	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
732	volontyr.alx	+380637195161	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
733	viktoriia___myronenko	+380931542743	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
734	julia Chumak	+380973989000	julia Chumak	0	\N	\N	2026-04-22	\N	f	f	f	\N
735	meloman_505	+380957831271	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
736	anniesokolan	+380965073111	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
737	ilona.kucherian		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
738	lisenkoivan384	+380972453827	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
739	dmitriydesire	+380505875246	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
740	ariel_style_	+380666559773	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
741	miia_mereniuk	+380508422848	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
742	natalia.karbowska	+380503303426	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
743	+380999338237	+380999338237	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
744	@oleksiizav	+380985043276	@oleksiizav	0	\N	\N	2026-04-22	\N	f	f	f	\N
745	+380979914551	+380680746113	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
746	@usermane_Polina	+380954314350	@usermane_Polina	0	\N	\N	2026-04-22	\N	f	f	f	\N
747	district___17	+380508462161	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
748	bohdan_spark	+380972449990	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
749	+380631255468	+380631255468	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
750	___0l._	+380508517456	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
751	oleh_zubakha	+380677029741	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
752	mfridrikhson	+380664400467	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
753	@lorinnser	+380661691584	@lorinnser	0	\N	\N	2026-04-22	\N	f	f	f	\N
754	sasha_winston	+380993519919	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
755	polishchuk_dmitriy	+380502126567	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
756	ivangolovat1195	+380686211519	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
757	sianastasiss	+380686135441	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
758	vlad.sidelnikov_	+380983549387	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
759	eugene_p44	+380634016806	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
760	+380954881198	+380954881198	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
761	vanya_babets	+380631446499	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
762	skum228	+380634365806	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
763	+380500699466	+380979986079	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
764	vladylenny	+380673340805	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
765	jekki_	+380978427925	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
766	meltseva	+380674090104	\N	0	Тікток	\N	2026-04-22	\N	f	f	f	\N
767	the__illich	+380971721183	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
768	@k1son	+380962590476	@k1son	0	\N	\N	2026-04-22	\N	f	f	f	\N
769	Brend	+380674645949	Brend	0	\N	\N	2026-04-22	\N	f	f	f	\N
770	anastasiia_sevastenko	+380977056215	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
771	iwasrapedbyeminem	+380975049744	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
772	0634269261	+380676111488	0634269261	0	\N	\N	2026-04-22	\N	f	f	f	\N
773	+380938946008	+380938946008	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
774	Dmytro	+380665330787	Dmytro	0	\N	\N	2026-04-22	\N	f	f	f	\N
775	@a_zodiak		@a_zodiak	0	\N	\N	2026-04-22	\N	f	f	f	\N
776	@little_Olegovich	+380672642415	@little_Olegovich	0	\N	\N	2026-04-22	\N	f	f	f	\N
777	@Vikik007	+380973818107	@Vikik007	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
778	@Island_of_Sol	+380639788574	@Island_of_Sol	0	\N	\N	2026-04-22	\N	f	f	f	\N
779	@bebra254	+380686020353	@bebra254	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
780	borodavanya	+380506903113	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
781	+380673282398	+380673980243	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
782	@omarakebaniy	+380637064481	@omarakebaniy	0	\N	\N	2026-04-22	\N	f	f	f	\N
783	+380672946343	+380985942541	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
784	oleskostyniuk1		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
785	dt_kornienko	+380937814119	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
786	neyler_	+380638077563	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
787	@artem6561	+380981328901	@artem6561	0	\N	\N	2026-04-22	\N	f	f	f	\N
788	офрайнклиент	+380994090003	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
789	@daria_basarab	+380676695511	@daria_basarab	0	\N	\N	2026-04-22	\N	f	f	f	\N
790	0 97 439 91 85(телеграм	+380689870400	0 97 439 91 85(телеграм	0	\N	\N	2026-04-22	\N	f	f	f	\N
791	a.blts	+380982900590	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
792	ikrutow	+380931384957	\N	0	\N	25	2026-04-22	\N	f	f	f	\N
793	+380504441105	+380972154488	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
794	@lanabuzok	+380689347563	@lanabuzok	0	\N	\N	2026-04-22	\N	f	f	f	\N
729	v.a.chistyakov.97	+380633689697	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
795	@andriibibik	+380504112920	@andriibibik	0	\N	\N	2026-04-22	\N	f	f	f	\N
796	evgen_kutovoj	+380988431297	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
797	miracle.afterglow	+380935096131	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
798	Е.В.М.	+380677444555	Е.В.М.	0	\N	10	2026-04-22	\N	f	f	f	\N
799	sashkobaleha	+380932604194	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
800	mari_odintcova	+380636272286	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
801	@VPixel(Телеграм)	+380660177157	@VPixel(Телеграм)	0	\N	\N	2026-04-22	\N	f	f	f	\N
802	viktoria.kutsenkooo	+380681342109	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
803	iansokolskyi	+380664378613	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
804	@xxy15yxx	+380637654173	@xxy15yxx	0	\N	\N	2026-04-22	\N	f	f	f	\N
805	kateryna_shapovalova	+380509683133	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
806	merkuly_	+380665797370	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
807	andrii.khomenko	+380932144015	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
808	@ael_ael	+380637462210	@ael_ael	0	\N	\N	2026-04-22	\N	f	f	f	\N
809	+380985027864	+380985027864	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
810	natali.renska	+380951296885	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
811	lanatremtii	+380685505555	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
812	kit.thirteen	+380955346266	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
813	0507538238 телеграм	+380731877552	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
814	darya_brill	+380962720628	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
815	collapsewave_	+380667269434	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
816	lizajustt	+380637310926	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
817	chris_chuchuk	+380950034494	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
818	daryavinnitskaya		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
819	mukharovskaa		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
820	yanafm	+380671552925	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
821	@Max_Lemeshko	+380955472903	@Max_Lemeshko	0	\N	\N	2026-04-22	\N	f	f	f	\N
822	@Tricheps	+380506521449	@Tricheps	0	\N	\N	2026-04-22	\N	f	f	f	\N
823	kristin_soul	+380681248880	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
824	seredaaa_a	+380990571507	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
825	mr.ter60	+380507800949	\N	0	Тікток	\N	2026-04-22	\N	f	f	f	\N
826	oksanita2	+380663243450	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
827	@Nipponets	+380637203831	@Nipponets	0	\N	\N	2026-04-22	\N	f	f	f	\N
828	vampir4ik_69	+380938351547	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
829	Svitlana(0503821881) телеграм	+380503821881	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
830	@ds_mma	+380665797228	@ds_mma	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
831	@romannnn123	+380971070763	@romannnn123	0	\N	\N	2026-04-22	\N	f	f	f	\N
832	@Marryana	+380964524090	@Marryana	0	\N	\N	2026-04-22	\N	f	f	f	\N
833	@Dobruyfey	+380952716916	@Dobruyfey	0	\N	\N	2026-04-22	\N	f	f	f	\N
834	+380637086841	+380507246635	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
836	+380965151868	+380965151868	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
837	nserhiiiiienko.nn		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
838	bodyasavchuk	+380934911578	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
839	magerramov_vlad	+380681184638	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
840	@sdiachenko	+380984922911	@sdiachenko	0	\N	\N	2026-04-22	\N	f	f	f	\N
841	lo.vl88	+380507188819	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
842	viktoriia.kutsenkooo	+380681342109	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
843	pavlius_t_t_	+380502055267	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
844	+380731692258	+380731692258	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
845	nastasiia_ivashchuk	+380972178188	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
846	_bogdan_bychkov_	+380999509816	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
847	vsv_776	+380999832823	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
848	yanasikovskaya_beauty	+380979713447	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
849	@PikaMax	+380667085333	@PikaMax	0	\N	\N	2026-04-22	\N	f	f	f	\N
850	Nicu Stan	+380500526203	Nicu Stan	0	\N	\N	2026-04-22	\N	f	f	f	\N
851	@kop_name	+380730311171	@kop_name	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
852	chrisfetisova	+380669721684	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
853	Владимир Галабурда	+380639972388	Владимир Галабурда	0	\N	\N	2026-04-22	\N	f	f	f	\N
854	t.a.t.y.a.n.a_s_l	+380731119898	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
855	__k.danya__	+380733241208	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
856	oksana_0k	+380633859748	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
857	barnyi_kotik	+380636576809	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
858	@oleksiyb_ua	+380950927190	@oleksiyb_ua	0	\N	\N	2026-04-22	\N	f	f	f	\N
859	buchmills2	+380681748095	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
860	@irossa_pryakhina	+380962726620	@irossa_pryakhina	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
861	romasapranen	+380971702656	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
862	@Twonster	+380976851567	@Twonster	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
863	drxri._	+380672345839	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
864	alexkryvulko	+380688882184	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
865	@antey718	+380666410123	@antey718	0	\N	\N	2026-04-22	\N	f	f	f	\N
866	@Uliana_Kashchii	+380983155464	@Uliana_Kashchii	0	\N	\N	2026-04-22	\N	f	f	f	\N
867	anton.aleksakha	+380972535682	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
868	olexandra.hairstylist.nl	+380503668800	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
869	kami.l.ie	+380669990846	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
835	+380675030997	+380675030997	\N	10260	\N	\N	2026-04-22	Анна	f	f	t	\N
870	630544346 Ватсап	+380969710365	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
871	Вадим Ротерс (WhatsApp)	+380931323802	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
872	anna.kupchenenko	+380668673766	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
873	bogdana_valigura	+380634611246	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
874	+380505348574	+380952053512	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
875	n.goriachenko		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
876	@danylovmaksym	+380992965387	@danylovmaksym	0	\N	\N	2026-04-22	\N	f	f	f	\N
877	@big_klaus	+380685029006	@big_klaus	0	\N	\N	2026-04-22	\N	f	f	f	\N
878	kuzmenko.ksym	+380967281321	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
879	shklovetss UGS	+380972623939	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
880	@shyrik0001	+380977034923	@shyrik0001	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
881	olmar_04	+380982020202	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
882	Iryna Gorban	+380672359406	Iryna Gorban	0	\N	\N	2026-04-22	\N	f	f	f	\N
883	u.ivasiv	+380934732585	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
884	@dastasia	+380990835787	@dastasia	0	\N	\N	2026-04-22	\N	f	f	f	\N
885	ann_shyika	+380963948225	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
886	zelinskaya.i (блогер)	+380975598595	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
887	k__alla__	+380631287663	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
888	_v.l.a.d.i.s.l.a.v._	+380663890163	\N	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
889	@dar14ka		@dar14ka	0	\N	\N	2026-04-22	\N	f	f	f	\N
890	diadia_cooperation_	+380685044966	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
891	belka__lu	+380674968598	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
892	lilvelichko		\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
893	oliaaa_voloss	+380633920344	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
894	@Bohdancore	+380966856054	@Bohdancore	0	\N	\N	2026-04-22	\N	f	f	f	\N
895	serhiisdrnk	+380987960471	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
896	anthony_paschenko	+380997053376	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
897	630356853 вайбер	+380630356853	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
898	d.horyk	+380974385251	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
899	Evgenia Geresha	+380661081861	Evgenia Geresha	0	\N	\N	2026-04-22	\N	f	f	f	\N
900	ferano_x	+380980492293	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
901	valik_drozdik	+380639527548	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
902	seed!	+380983145264	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
903	avram_chu	+380509959819	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
904	e.bachinskii	+380937625767	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
905	cottoncoffe.kyiv	+380964819288	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
906	anatolyakis	+380505587408	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
907	lukian_halkin	+380669060594	\N	0	розповіли друзі	10	2026-04-22	\N	f	f	f	\N
908	vlysenkoo	+380503465544	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
909	ko7tyantyn	+380631421775	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
910	jekas17305	+380673325214	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
911	_drive_me_blind	+380689841170	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
912	annieanniannana	+380936173017	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
913	limarsvetlana	+380637056536	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
914	yuliya_brunette	+380631547637	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
916	awfultty	+380676301500	\N	0	\N	5	2026-04-22	\N	f	f	f	\N
917	petrivskyi	+380672972656	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
918	ulianakharyna	+380508577799	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
919	sergii.nesmikh	+380967475221	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
920	oleksandr.staruk	+380977634701	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
921	Сергій (вотсап) 093 578	+380503864196	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
922	1 Сергій (вотсап) 093 578	+380675021778	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
923	vadym.bilotskyi	+380953033501	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
924	Korinna_oksana	+380504403500	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
925	alpha.centaurii	+380507414490	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
926	mironenko33	+380934000479	\N	0	розповіли друзі	10	2026-04-22	\N	f	f	f	\N
927	bravo_tres_bien	+380959055356	\N	0	контент інстаграм	10	2026-04-22	\N	f	f	f	\N
928	a.shvetsov91	+380995085929	\N	0	розповіли друзі	5	2026-04-22	\N	f	f	f	\N
929	diana_voronyuk	+380977033717	\N	0	Таргет	5	2026-04-22	\N	f	f	f	\N
930	@NikitaZaets	+380671216260	@NikitaZaets	0	гугл пошук	10	2026-04-22	\N	f	f	f	\N
931	anutellka	+380631528014	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
932	dr.an_shi	+380952046405	\N	0	гугл пошук	5	2026-04-22	\N	f	f	f	\N
933	vladyslavkir	+380981339931	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
934	mantra_soul_	+380660762064	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
935	sokhatska.m	+380966792396	\N	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
936	@Old_sema	+380664428158	@Old_sema	0	розповіли друзі	20	2026-04-22	\N	f	f	f	\N
937	tanya__nadtocheieva	+380975850765	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
938	s_cooper9	+380958271977	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
939	@Vasily_Baranovsky	+380973124469	@Vasily_Baranovsky	0	\N	10	2026-04-22	\N	f	f	f	\N
940	dondiablo.999	+380632018762	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
941	@Kseniia_Krasnopolska	+380669029893	@Kseniia_Krasnopolska	0	\N	10	2026-04-22	\N	f	f	f	\N
942	@dictumfactu	+380508622642	@dictumfactu	0	\N	\N	2026-04-22	\N	f	f	f	\N
943	07dolphin70	+380678550707	\N	0	Тікток	\N	2026-04-22	\N	f	f	f	\N
944	@blackjackmh	+380934262659	@blackjackmh	0	\N	\N	2026-04-22	\N	f	f	f	\N
945	anton_shulyk	+380509621070	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
946	kate.sakhno	+380937356031	\N	0	\N	15	2026-04-22	\N	f	f	f	\N
947	Svitlana (+380 50 544 99 18)	+380952769452	\N	0	побачили офлайн	15	2026-04-22	\N	f	f	f	\N
948	marynarobotko	+380996248457	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
949	tania_kmrntsk	+380985074891	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
950	@sirixy	+380503875956	@sirixy	0	\N	\N	2026-04-22	\N	f	f	f	\N
951	@marcha_ua	+380969423787	@marcha_ua	0	\N	\N	2026-04-22	\N	f	f	f	\N
952	@K3nji91	+380639606938	@K3nji91	0	\N	\N	2026-04-22	\N	f	f	f	\N
953	adastra808	+380501525455	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
954	Ярослав Макійчук	+380980733259	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
955	@OWL_Olena	+380678998979	@OWL_Olena	0	\N	\N	2026-04-22	\N	f	f	f	\N
956	sasha_marchuk1984	+380937163442	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
957	romankushmyruk	+380635269936	\N	0	контент інстаграм	10	2026-04-22	\N	f	f	f	\N
958	userone3088	+380935868251	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
959	@alexandra_m1299	+380939600253	@alexandra_m1299	0	\N	\N	2026-04-22	\N	f	f	f	\N
960	+380976151613	+380969976617	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
961	@levgenLi	+380509422484	@levgenLi	0	\N	\N	2026-04-22	\N	f	f	f	\N
962	Andrey P	+380997974059	Andrey P	0	\N	5	2026-04-22	\N	f	f	f	\N
963	vadym_kyrylov	+380930178353	\N	0	Таргет	10	2026-04-22	\N	f	f	f	\N
964	purple_alcoholic	+380972138899	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
966	@Stanislav_Hus	+380931857939	@Stanislav_Hus	0	розповіли друзі	10	2026-04-22	\N	f	f	f	\N
967	@anna_pylypenko28	+380993728446	@anna_pylypenko28	0	\N	\N	2026-04-22	\N	f	f	f	\N
968	karinafonariovawj	+380734595942	\N	0	\N	10	2026-04-22	\N	f	f	f	\N
969	yakovlev.dmitr7	+380673891519	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
970	aid04ka	+380971058494	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
971	yevtushenko_vladislav	+380956673239	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
972	+380979527245	+380979527244	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
974	+380667814745	+380667814745	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
975	oxanasnezhko	+380967076617	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
976	@Ilsap	+380631715386	@Ilsap	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
977	yura.vataschyk	+380991110078	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
978	ostrov.skyy	+380631040387	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
979	@volodymyrshykun	+380957255980	@volodymyrshykun	0	\N	\N	2026-04-22	\N	f	f	f	\N
980	@tiana_kupetska	+380674630780	@tiana_kupetska	0	\N	\N	2026-04-22	\N	f	f	f	\N
981	trgbchk	+380503706343	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
982	@Konstantin_Popovchenko	+380689170743	@Konstantin_Popovchenko	0	\N	\N	2026-04-22	\N	f	f	f	\N
983	@latyshev_dn	+380953656882	@latyshev_dn	0	\N	\N	2026-04-22	\N	f	f	f	\N
984	0 50 442 57 57	+380636235750	0 50 442 57 57	0	\N	\N	2026-04-22	\N	f	f	f	\N
985	@andrew_light	+380507831054	@andrew_light	0	\N	\N	2026-04-22	\N	f	f	f	\N
986	+380633345654	+380633345654	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
987	pavel_a_kukharenko	+380663138847	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
988	@Vladosta	+380950876846	@Vladosta	0	\N	\N	2026-04-22	\N	f	f	f	\N
989	+380956810351	+380668217997	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
990	+380937678147	+380635821444	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
991	someonenew.vl	+380975314488	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
992	+380632113420	+380660136118	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
993	goshamaksymiak	+380676903863	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
994	@igor11112344	+380674039910	@igor11112344	0	\N	\N	2026-04-22	\N	f	f	f	\N
995	erolag07	+380952943461	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
996	@Slagod	+380934729529	@Slagod	0	контент інстаграм	\N	2026-04-22	\N	f	f	f	\N
997	yuliia_nebesenko	+380939821599	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
998	86boroda86	+380675080419	\N	0	UGC/блогери	\N	2026-04-22	\N	f	f	f	\N
999	@tarasyukhym	+380633579820	@tarasyukhym	0	Таргет	\N	2026-04-22	\N	f	f	f	\N
1000	0507010477	+380507010477	0507010477	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
1001	vitaliyharechko	+380673720032	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
1002	tanushkas2009	+380674489130	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
1003	@daryna_yatsenko28	+380672243986	@daryna_yatsenko28	0	\N	\N	2026-04-22	\N	f	f	f	\N
1004	@jwwtf	+380638908362	@jwwtf	0	\N	\N	2026-04-22	\N	f	f	f	\N
1005	Kate	+380504071653	Kate	0	\N	\N	2026-04-22	\N	f	f	f	\N
1006	@sergii_z	+380501602583	@sergii_z	0	гугл пошук	\N	2026-04-22	\N	f	f	f	\N
973	n0okOne	+380509536315	n0okOne	0	\N	10	2026-04-22	\N	f	f	f	\N
1008	@Bronsboro	+380669003305	@Bronsboro	0	UGC/блогери	\N	2026-04-22	\N	f	f	f	\N
1009	byinnastef	+380954081262	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
1010	@dimalavrishyn	+380936546643	@dimalavrishyn	0	\N	\N	2026-04-22	\N	f	f	f	\N
1011	@q_salllko_p	+380672507615	@q_salllko_p	0	\N	\N	2026-04-22	\N	f	f	f	\N
1012	named.ania	+380689374919	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
1013	@UkotugoroshkoU	+380732145953	@UkotugoroshkoU	0	\N	\N	2026-04-22	\N	f	f	f	\N
1014	@ViktoriiaHarkusha	+380950951649	@ViktoriiaHarkusha	0	UGC/блогери	\N	2026-04-22	\N	f	f	f	\N
1015	+380999855321	+380955793157	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
1016	vania_fomchuk	+380685412887	\N	0	побачили офлайн	\N	2026-04-22	\N	f	f	f	\N
1017	@bohdan_tkachuk	+380972449990	@bohdan_tkachuk	0	\N	\N	2026-04-22	\N	f	f	f	\N
1018	@sargeras8675	+380932107088	@sargeras8675	0	\N	\N	2026-04-22	\N	f	f	f	\N
1019	_l.e.b.e.d	+380634917882	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
1020	yegoriy	+380939853394	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
1021	mchl.kv	+380952023484	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
1022	adaline.pelykh	+380669973616	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
1023	dasha_mannaya_kasha	+380935878272	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
1024	0.antoxa.0	+380979259809	\N	0	гугл пошук	\N	2026-04-22	\N	f	f	f	\N
1025	+380503116161	+380503116161	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
1026	justblin_	+380639537363	\N	0	розповіли друзі	\N	2026-04-22	\N	f	f	f	\N
1007	bogdanzhuc	+380671326366	\N	0	\N	\N	2026-04-22	\N	f	f	f	\N
915	max.ellisen	+380996660001	\N	7920	\N	10	2026-04-22	\N	f	f	f	\N
1027	vladosik9	+380660463825	\N	0	\N	\N	2026-04-23	Владислав	f	f	f	\N
1028	dianapogorelova8	+380508542523	\N	0	\N	\N	2026-04-24	\N	f	f	f	\N
1036	an.2.k	+380099783749	\N	3240	\N	\N	2026-04-25	\N	f	f	f	\N
1029	irinaliebiedieva	+380956275582	\N	3300	\N	\N	2026-04-24	\N	f	f	f	\N
1032	dariiakupriienko	+380936849070	\N	2100	\N	\N	2026-04-24	\N	f	f	f	\N
1030	gudyma_uliana	+380674044114	\N	2200	\N	\N	2026-04-24	\N	f	f	f	\N
1033	\N	+380679365112	\N	0	\N	\N	2026-04-24	\N	f	f	f	\N
1031	orlov.max_	+380000000000	\N	3650	\N	\N	2026-04-24	\N	f	f	f	\N
1034	gogorenje	+380681914418	gogorenje	4000	Контент інстаграм	\N	2026-04-25	Гоша	f	t	f	\N
1035	david_112777	+380636994090	\N	0	\N	\N	2026-04-25	Давід	f	f	f	\N
965	amor.fati_memento.mori	+380679895636	\N	2900	\N	\N	2026-04-22	\N	f	f	f	\N
1037	annamezhuevaa	+380634759391	\N	2700	\N	\N	2026-04-25	Анна	f	t	f	\N
\.


--
-- Data for Name: courier; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.courier (id, name, phone, active, deliveries_count, telegram_chat_id, telegram_username, telegram_registered, telegram_notifications_enabled, last_telegram_activity, is_taxi, communication_channel, nickname, working_days, comment, rating) FROM stdin;
1	Влад тігуан	+380660463825	t	0	321803091	ponomarov_vlad	t	t	2026-04-24 09:45:12.215874	f	telegram	@ponomarov_vlad	mon,tue,wed,thu,fri,sat,sun	Бере тільки лівий берег	5
2	Ірина	+380987136862	t	0	\N	\N	f	t	\N	f	telegram	@IrinaPodobrii	sat,sun	\N	5
5	Владислав	+380504702336	t	0	\N	\N	f	t	\N	f	telegram	Владислав	mon,tue,wed,thu,fri,sat,sun	\N	4
6	Міла	+380982177512	t	0	\N	\N	f	t	\N	f	telegram	@milamih1	mon,tue,wed,thu,fri,sat,sun	\N	4
7	Уклон	\N	t	0	\N	\N	f	t	\N	t	\N	\N	mon,tue,wed,thu,fri,sat,sun	\N	3
8	Віталій	+380639534724	t	0	\N	\N	f	t	\N	f	viber	\N	mon,tue,wed,thu,fri,sat,sun	\N	5
4	Андрій (джун)	+380966536552	t	0	560318138	Konoplastiy	t	t	2026-04-24 17:05:22.789966	f	telegram	@Konoplastiy	sat,sun	Може тільки по вихідних\nпостійно просить доплату за маршрути	4
3	Роман (чоловік Ірини)	+380674000661	t	0	912205296	\N	t	t	2026-04-25 05:52:44.944725	f	telegram	+380674000661	sat,sun	\N	5
\.


--
-- Data for Name: delivery; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.delivery (id, order_id, client_id, delivery_date, status, comment, created_at, updated_at, street, building_number, floor, entrance, is_pickup, time_from, time_to, size, phone, courier_id, delivered_at, status_changed_at, price_at_delivery, preferences, delivery_method, address_comment, bouquet_type, composition_type, florist_status) FROM stdin;
1	1	524	2026-05-17	Очікує	\N	2026-04-22 17:15:50.329313	2026-04-22 17:15:50.329317	Вул. Осокорська 2а	\N	\N	\N	f	\N	\N	M	+380938182166	\N	\N	\N	\N	Весільна підписка №18\nдивитись побажання та розміри згідно табл	courier	2 під’їзд, 4 поверх, 127	\N	\N	\N
2	2	524	2026-06-14	Очікує	\N	2026-04-22 17:15:50.333223	2026-04-22 17:15:50.333227	Вул. Осокорська 2а	\N	\N	\N	f	\N	\N	M	+380938182166	\N	\N	\N	\N	Весільна підписка №18\nдивитись побажання та розміри згідно табл	courier	2 під’їзд, 4 поверх, 127	\N	\N	\N
3	3	524	2026-07-12	Очікує	\N	2026-04-22 17:15:50.335906	2026-04-22 17:15:50.335909	Вул. Осокорська 2а	\N	\N	\N	f	\N	\N	M	+380938182166	\N	\N	\N	\N	Весільна підписка №18\nдивитись побажання та розміри згідно табл	courier	2 під’їзд, 4 поверх, 127	\N	\N	\N
4	4	524	2026-08-09	Очікує	\N	2026-04-22 17:15:50.336912	2026-04-22 17:15:50.336916	Вул. Осокорська 2а	\N	\N	\N	f	\N	\N	M	+380938182166	\N	\N	\N	\N	Весільна підписка №18\nдивитись побажання та розміри згідно табл	courier	2 під’їзд, 4 поверх, 127	\N	\N	\N
5	5	592	2026-05-16	Очікує	\N	2026-04-22 17:15:50.505076	2026-04-22 17:15:50.505079		\N	\N	\N	f	\N	\N	L	+380676125686	\N	\N	\N	\N	@Lisa_Chernikova	courier	\N	\N	\N	\N
6	6	627	2026-05-17	Очікує	\N	2026-04-22 17:15:50.58196	2026-04-22 17:15:50.581963	вулиця Звіринецька 9	\N	\N	\N	f	\N	\N	M	+380682668787	\N	\N	\N	\N	не класти Лілії та сильно пахнущі квіти, алергія	courier	(приватний будинок)	\N	\N	\N
7	7	627	2026-06-14	Очікує	\N	2026-04-22 17:15:50.582887	2026-04-22 17:15:50.58289	вулиця Звіринецька 9	\N	\N	\N	f	\N	\N	M	+380682668787	\N	\N	\N	\N	не класти Лілії та сильно пахнущі квіти, алергія	courier	(приватний будинок)	\N	\N	\N
8	8	716	2026-05-21	Очікує	\N	2026-04-22 17:15:50.791084	2026-04-22 17:15:50.791087	Володимира Івасюка 60	\N	\N	\N	f	\N	\N	XL	+380935641375	\N	\N	\N	\N	@eastwood_dir, адреса може змінюватись	courier	підїзд 5, кв 458	\N	\N	\N
9	9	716	2026-06-18	Очікує	\N	2026-04-22 17:15:50.792869	2026-04-22 17:15:50.792873	Володимира Івасюка 60	\N	\N	\N	f	\N	\N	XL	+380935641375	\N	\N	\N	\N	@eastwood_dir, адреса може змінюватись	courier	підїзд 5, кв 458	\N	\N	\N
10	10	716	2026-07-16	Очікує	\N	2026-04-22 17:15:50.794593	2026-04-22 17:15:50.794596	Володимира Івасюка 60	\N	\N	\N	f	\N	\N	XL	+380935641375	\N	\N	\N	\N	@eastwood_dir, адреса може змінюватись	courier	підїзд 5, кв 458	\N	\N	\N
11	11	716	2026-08-13	Очікує	\N	2026-04-22 17:15:50.795629	2026-04-22 17:15:50.795632	Володимира Івасюка 60	\N	\N	\N	f	\N	\N	XL	+380935641375	\N	\N	\N	\N	@eastwood_dir, адреса може змінюватись	courier	підїзд 5, кв 458	\N	\N	\N
12	12	805	2026-05-21	Очікує	\N	2026-04-22 17:15:51.022906	2026-04-22 17:15:51.02291	вул. Олеся Бердника 1-Д	\N	\N	\N	f	\N	\N	M	+380509683133	\N	\N	\N	\N	\N	courier	1 підʼїзд/секція, 6 поверх, кВ.30. ЖК Нивки-парк.	\N	\N	\N
13	13	805	2026-06-20	Очікує	\N	2026-04-22 17:15:51.02377	2026-04-22 17:15:51.023773	вул. Олеся Бердника 1-Д	\N	\N	\N	f	\N	\N	M	+380509683133	\N	\N	\N	\N	\N	courier	1 підʼїзд/секція, 6 поверх, кВ.30. ЖК Нивки-парк.	\N	\N	\N
14	14	891	2026-05-17	Очікує	\N	2026-04-22 17:15:51.249121	2026-04-22 17:15:51.249125	Котарбінського 17	\N	\N	\N	f	\N	\N	M	+380674968598	\N	\N	\N	\N	\N	courier	1а доставка за адресою Воздвиженьска 41. Офіс Хавас Діджитал.\nінші - Далі доставку буде зручно отримувати на Котарбінського 17 , кв 45.	\N	\N	\N
15	15	891	2026-05-30	Очікує	\N	2026-04-22 17:15:51.251095	2026-04-22 17:15:51.251098	Котарбінського 17	\N	\N	\N	f	\N	\N	M	+380674968598	\N	\N	\N	\N	\N	courier	1а доставка за адресою Воздвиженьска 41. Офіс Хавас Діджитал.\nінші - Далі доставку буде зручно отримувати на Котарбінського 17 , кв 45.	\N	\N	\N
16	16	891	2026-06-06	Очікує	\N	2026-04-22 17:15:51.251951	2026-04-22 17:15:51.251955	Котарбінського 17	\N	\N	\N	f	\N	\N	M	+380674968598	\N	\N	\N	\N	\N	courier	1а доставка за адресою Воздвиженьска 41. Офіс Хавас Діджитал.\nінші - Далі доставку буде зручно отримувати на Котарбінського 17 , кв 45.	\N	\N	\N
239	239	835	2026-06-06	Очікує	\N	2026-04-24 12:05:11.958113	2026-04-25 07:24:15.419794	проспект Соборності 30 	\N	\N	\N	f	\N	\N	XL	+380675030997	\N	\N	\N	\N	\N	courier	 Кв 161 поверх 7	\N	\N	\N
18	18	900	2026-05-09	Очікує	\N	2026-04-22 17:15:51.280237	2026-04-22 17:15:51.28024	Жулянська 2г	\N	\N	\N	f	\N	\N	M	+380980492293	\N	\N	\N	\N	доставка 10-11	courier	ЖК Євромісто, 4 підʼїзд, 5 поверх, кв. 151\nВишневе	\N	\N	\N
19	19	900	2026-05-23	Очікує	\N	2026-04-22 17:15:51.281176	2026-04-22 17:15:51.281179	Жулянська 2г	\N	\N	\N	f	\N	\N	M	+380980492293	\N	\N	\N	\N	доставка 10-11	courier	ЖК Євромісто, 4 підʼїзд, 5 поверх, кв. 151\nВишневе	\N	\N	\N
20	20	623	2026-05-03	Очікує	\N	2026-04-22 17:15:51.28818	2026-04-22 17:15:51.288183	вул. Павлівська 17	\N	\N	\N	f	\N	\N	XL	+380955031164	\N	\N	\N	\N	погоджувати в телеграмі - @mariannaalt	courier	кв. 20, 7й поверх, 1 підʼїзд	\N	\N	\N
21	21	623	2026-05-17	Очікує	\N	2026-04-22 17:15:51.290084	2026-04-22 17:15:51.290087	вул. Павлівська 17	\N	\N	\N	f	\N	\N	XL	+380955031164	\N	\N	\N	\N	погоджувати в телеграмі - @mariannaalt	courier	кв. 20, 7й поверх, 1 підʼїзд	\N	\N	\N
22	22	623	2026-05-31	Очікує	\N	2026-04-22 17:15:51.291052	2026-04-22 17:15:51.291055	вул. Павлівська 17	\N	\N	\N	f	\N	\N	XL	+380955031164	\N	\N	\N	\N	погоджувати в телеграмі - @mariannaalt	courier	кв. 20, 7й поверх, 1 підʼїзд	\N	\N	\N
24	24	901	2026-05-02	Очікує	\N	2026-04-22 17:15:51.299695	2026-04-22 17:15:51.299698	Кахи Бендукідзе 2	\N	\N	\N	f	\N	\N	L	+380639527548	\N	\N	\N	\N	L - XL - L - XL	courier	кв. 235, 7 поверх, 2 підʼїзд	\N	\N	\N
25	25	902	2026-04-30	Очікує	\N	2026-04-22 17:15:51.3059	2026-04-22 17:15:51.305903	Глибочицька 13к2	\N	\N	\N	f	\N	\N	M	+380983145264	\N	\N	\N	\N	не додавати фарбовані рослини будь які + не класти гортензіі	courier	поверх 5, кв. 139	\N	\N	\N
27	27	903	2026-05-24	Очікує	\N	2026-04-22 17:15:51.316125	2026-04-22 17:15:51.316128	пр-т Науки 60а	\N	\N	\N	f	\N	\N	M	+380509959819	\N	\N	\N	\N	\N	courier	кв. 36, 6 поверх, 1 підʼїзд	\N	\N	\N
28	28	903	2026-06-21	Очікує	\N	2026-04-22 17:15:51.316936	2026-04-22 17:15:51.316938	пр-т Науки 60а	\N	\N	\N	f	\N	\N	M	+380509959819	\N	\N	\N	\N	\N	courier	кв. 36, 6 поверх, 1 підʼїзд	\N	\N	\N
238	238	835	2026-05-23	Очікує	\N	2026-04-24 12:05:11.957115	2026-04-24 12:05:11.957119	проспект Соборності 30 	\N	\N	\N	f	\N	\N	XL	+380675030997	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
31	31	907	2026-05-10	Очікує	\N	2026-04-22 17:15:51.338931	2026-04-22 17:15:51.338935	Чорновола 30	\N	\N	\N	f	\N	\N	M	+380669060594	\N	\N	\N	\N	троянди не хоче отримувати.\n+ переконливо попросив НЕ привозити квіти раніше оговореного часу	courier	кв. 113, 16 поверх, 1 підʼїзд	\N	\N	\N
30	30	906	2026-05-03	Очікує	\N	2026-04-22 17:15:51.332725	2026-04-23 15:09:21.137375	53-а Садова	\N	\N	\N	f	\N	\N	L	+380505587408	\N	\N	\N	\N	\N	courier	буд. 14 (Йогасфера)	\N	\N	\N
237	237	835	2026-05-09	Очікує	\N	2026-04-24 12:05:11.954978	2026-04-25 07:25:42.207021	проспект Соборності 30 	\N	\N	\N	f	\N	\N	XL	+380675030997	\N	\N	\N	\N	\N	courier	Кв 161 поверх 7	\N	\N	\N
154	154	1000	2026-04-26	Очікує	\N	2026-04-22 17:15:52.06132	2026-04-25 17:34:05.39855	проспект Дмитра Павличка 3	\N	\N	\N	f	09:00	12:00	M	+380507010477	\N	\N	\N	\N	Oxana Oxana - телеграм	courier	кв 158	\N	\N	\N
32	32	908	2026-05-03	Очікує	\N	2026-04-22 17:15:51.345867	2026-04-22 17:15:51.345871	Євгена Коновальця 26А	\N	\N	\N	f	\N	\N	L	+380503465544	\N	\N	\N	\N	\N	courier	залишать заявку на вхід в комплекс і уточнити більш точну адресу\nнабрати за 10 хвилин	\N	\N	\N
33	33	908	2026-05-17	Очікує	\N	2026-04-22 17:15:51.347104	2026-04-22 17:15:51.347109	Євгена Коновальця 26А	\N	\N	\N	f	\N	\N	L	+380503465544	\N	\N	\N	\N	\N	courier	залишать заявку на вхід в комплекс і уточнити більш точну адресу\nнабрати за 10 хвилин	\N	\N	\N
34	34	909	2026-05-03	Очікує	\N	2026-04-22 17:15:51.355876	2026-04-22 17:15:51.355881	50°33'24.7"N 30°29'23.3"E	\N	\N	\N	f	\N	\N	XL	+380631421775	\N	\N	\N	\N	Дуже уважно з цим клієнтом\nписати в телеграм - @ko7tya\nДоставка раз на 3 тижні\nспецифічна адреса за послианням дивитись	courier	приватний будинок за цим посиланням\n\n50°33'24.7"N 30°29'23.3"E	\N	\N	\N
35	35	909	2026-05-17	Очікує	\N	2026-04-22 17:15:51.356966	2026-04-22 17:15:51.356971	50°33'24.7"N 30°29'23.3"E	\N	\N	\N	f	\N	\N	XL	+380631421775	\N	\N	\N	\N	Дуже уважно з цим клієнтом\nписати в телеграм - @ko7tya\nДоставка раз на 3 тижні\nспецифічна адреса за послианням дивитись	courier	приватний будинок за цим посиланням\n\n50°33'24.7"N 30°29'23.3"E	\N	\N	\N
37	37	910	2026-05-04	Очікує	\N	2026-04-22 17:15:51.367769	2026-04-22 17:15:51.367773	Коперніка 12Д	\N	\N	\N	f	\N	\N	M	+380673325214	\N	\N	\N	\N	по понеділкам на 12 доставка\nінст - yevhen17305	courier	11 поверх, кв. 36	\N	\N	\N
38	38	910	2026-05-11	Очікує	\N	2026-04-22 17:15:51.368661	2026-04-22 17:15:51.368664	Коперніка 12Д	\N	\N	\N	f	\N	\N	M	+380673325214	\N	\N	\N	\N	по понеділкам на 12 доставка\nінст - yevhen17305	courier	11 поверх, кв. 36	\N	\N	\N
39	39	912	2026-05-02	Очікує	\N	2026-04-22 17:15:51.378983	2026-04-22 17:15:51.378986	Верхня 3	\N	\N	\N	f	\N	\N	M	+380936173017	\N	\N	\N	\N	\N	courier	під'їзд 1, поверх 8, кв 91, проїжджати через вул Болбочана	\N	\N	\N
40	40	912	2026-05-16	Очікує	\N	2026-04-22 17:15:51.380602	2026-04-22 17:15:51.380605	Верхня 3	\N	\N	\N	f	\N	\N	M	+380936173017	\N	\N	\N	\N	\N	courier	під'їзд 1, поверх 8, кв 91, проїжджати через вул Болбочана	\N	\N	\N
41	41	912	2026-05-30	Очікує	\N	2026-04-22 17:15:51.381507	2026-04-22 17:15:51.38151	Верхня 3	\N	\N	\N	f	\N	\N	M	+380936173017	\N	\N	\N	\N	\N	courier	під'їзд 1, поверх 8, кв 91, проїжджати через вул Болбочана	\N	\N	\N
42	42	913	2026-05-02	Очікує	\N	2026-04-22 17:15:51.387749	2026-04-22 17:15:51.387753	Левка Лукʼяненка 21	\N	\N	\N	f	\N	\N	M	+380637056536	\N	\N	\N	\N	доставки на 9 ранку	courier	корпус 8, 14 поверх, кв. 45	\N	\N	\N
43	43	919	2026-05-16	Очікує	\N	2026-04-22 17:15:51.411865	2026-04-22 17:15:51.41187	вул. Сімʼї Кульженків 31а	\N	\N	\N	f	\N	\N	L	+380967475221	\N	\N	\N	\N	\N	courier	21 поверх, кв. 187	\N	\N	\N
44	44	920	2026-05-02	Очікує	\N	2026-04-22 17:15:51.417853	2026-04-22 17:15:51.417856	Воскресенська 18а	\N	\N	\N	f	\N	\N	XL	+380977634701	\N	\N	\N	\N	не класти троянди	courier	кв. 120, 21 поверх, 1 секція	\N	\N	\N
45	45	921	2026-05-01	Очікує	\N	2026-04-22 17:15:51.425577	2026-04-22 17:15:51.42558	вул. Юрія Кондратюка 6	\N	\N	\N	f	\N	\N	L	+380503864196	\N	\N	\N	\N	по буднях з 9 до 14\nможна більш екзотичні, і не класти тюльпани	courier	\N	\N	\N	\N
46	46	921	2026-05-08	Очікує	\N	2026-04-22 17:15:51.42732	2026-04-22 17:15:51.427324	вул. Юрія Кондратюка 6	\N	\N	\N	f	\N	\N	L	+380503864196	\N	\N	\N	\N	по буднях з 9 до 14\nможна більш екзотичні, і не класти тюльпани	courier	\N	\N	\N	\N
47	47	921	2026-05-15	Очікує	\N	2026-04-22 17:15:51.428955	2026-04-22 17:15:51.428958	вул. Юрія Кондратюка 6	\N	\N	\N	f	\N	\N	L	+380503864196	\N	\N	\N	\N	по буднях з 9 до 14\nможна більш екзотичні, і не класти тюльпани	courier	\N	\N	\N	\N
48	48	921	2026-05-22	Очікує	\N	2026-04-22 17:15:51.429818	2026-04-22 17:15:51.429821	вул. Юрія Кондратюка 6	\N	\N	\N	f	\N	\N	L	+380503864196	\N	\N	\N	\N	по буднях з 9 до 14\nможна більш екзотичні, і не класти тюльпани	courier	\N	\N	\N	\N
240	240	1028	2026-05-02	Очікує	уточнити всі деталі у отримувача, ще не оплачено	2026-04-24 13:47:32.117186	2026-04-24 13:47:32.117191	треба уточнити	\N	\N	\N	f	\N	\N	M	+380508542523	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
50	50	922	2026-05-02	Очікує	\N	2026-04-22 17:15:51.439276	2026-04-22 17:15:51.439279	Ризька 59	\N	\N	\N	f	\N	\N	L	+380675021778	\N	\N	\N	\N	доставка с 9 до 12\nНам би хотілось меньше екзотики та більше сезонних квітів.  В яскравій кольоровій гаммі. Потрібен об'єм	courier	(приватний будинок)	\N	\N	\N
51	51	922	2026-05-09	Очікує	\N	2026-04-22 17:15:51.440178	2026-04-22 17:15:51.440181	Ризька 59	\N	\N	\N	f	\N	\N	L	+380675021778	\N	\N	\N	\N	доставка с 9 до 12\nНам би хотілось меньше екзотики та більше сезонних квітів.  В яскравій кольоровій гаммі. Потрібен об'єм	courier	(приватний будинок)	\N	\N	\N
52	52	923	2026-05-03	Очікує	\N	2026-04-22 17:15:51.448217	2026-04-22 17:15:51.44822	Академіка Заболотного 15В	\N	\N	\N	f	\N	\N	L	+380953033501	\N	\N	\N	\N	На скільки я знаю всі квіти підходять). Мабуть бажано щось незвичне))\n\nЛистівку кожного разу «Я тебе кохаю»	courier	\N	\N	\N	\N
54	54	702	2026-05-03	Очікує	\N	2026-04-22 17:15:51.461449	2026-04-22 17:15:51.461477	Вул. Бульварно-Кудрявська 36	\N	\N	\N	f	\N	\N	XL	+380672706655	\N	\N	\N	\N	\N	courier	1 підʼїзд, 8 поверх, кв. 34	\N	\N	\N
53	53	702	2026-04-26	Очікує	\N	2026-04-22 17:15:51.460371	2026-04-25 17:34:05.39071	Вул. Бульварно-Кудрявська 36	\N	\N	\N	f	10:00	13:00	XL	+380672706655	4	\N	\N	\N	\N	courier	1 підʼїзд, 8 поверх, кв. 34	\N	\N	\N
56	56	925	2026-05-23	Очікує	\N	2026-04-22 17:15:51.47159	2026-04-22 17:15:51.471593	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N	f	\N	\N	M	+380507414490	\N	\N	\N	\N	Переїхала у інше місто, чекаємо апдейт коли поновлювати доставки і куди, сама напише\nВесільна підписка #2 - дивитись побажання в табл\nбез евкаліпту\nвона сама буде писати коли ій потрібна доставка	nova_poshta	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N
241	241	1028	2026-05-11	Очікує	\N	2026-04-24 13:47:32.120015	2026-04-24 13:47:32.120019	треба уточнити	\N	\N	\N	f	\N	\N	M	+380508542523	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
109	109	968	2026-04-27	Розподілено	\N	2026-04-22 17:15:51.792146	2026-04-24 18:18:44.029419	Охтирський провулок 7	\N	\N	\N	f	11:00	13:00	M	+380734595942	\N	\N	\N	\N	відправляти по 2 збірних букети М	courier	корпус 3а	\N	\N	\N
57	57	925	2026-06-20	Очікує	\N	2026-04-22 17:15:51.473219	2026-04-22 17:15:51.473222	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N	f	\N	\N	M	+380507414490	\N	\N	\N	\N	Переїхала у інше місто, чекаємо апдейт коли поновлювати доставки і куди, сама напише\nВесільна підписка #2 - дивитись побажання в табл\nбез евкаліпту\nвона сама буде писати коли ій потрібна доставка	nova_poshta	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N
58	58	925	2026-07-18	Очікує	\N	2026-04-22 17:15:51.474142	2026-04-22 17:15:51.474145	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N	f	\N	\N	M	+380507414490	\N	\N	\N	\N	Переїхала у інше місто, чекаємо апдейт коли поновлювати доставки і куди, сама напише\nВесільна підписка #2 - дивитись побажання в табл\nбез евкаліпту\nвона сама буде писати коли ій потрібна доставка	nova_poshta	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N
60	60	927	2026-05-09	Очікує	\N	2026-04-22 17:15:51.48641	2026-04-22 17:15:51.486414	Завальна 10г	\N	\N	\N	f	\N	\N	M	+380959055356	\N	\N	\N	\N	телеграм - @kavinskymax	courier	підїзд Г, кв 35, 5 поверх	\N	\N	\N
61	61	927	2026-05-23	Очікує	\N	2026-04-22 17:15:51.487318	2026-04-22 17:15:51.487321	Завальна 10г	\N	\N	\N	f	\N	\N	M	+380959055356	\N	\N	\N	\N	телеграм - @kavinskymax	courier	підїзд Г, кв 35, 5 поверх	\N	\N	\N
63	63	930	2026-05-10	Очікує	\N	2026-04-22 17:15:51.506893	2026-04-22 17:15:51.506897	Нагірна 18\\16	\N	\N	\N	f	\N	\N	M	+380671216260	\N	\N	\N	\N	погоджувати з @yuligrishko	courier	14 поверх, 294 квартира	\N	\N	\N
64	64	930	2026-05-24	Очікує	\N	2026-04-22 17:15:51.507813	2026-04-22 17:15:51.507816	Нагірна 18\\16	\N	\N	\N	f	\N	\N	M	+380671216260	\N	\N	\N	\N	погоджувати з @yuligrishko	courier	14 поверх, 294 квартира	\N	\N	\N
65	65	931	2026-05-16	Очікує	\N	2026-04-22 17:15:51.516157	2026-04-22 17:15:51.516161	вул . Голосіївська 4	\N	\N	\N	f	\N	\N	M	+380631528014	\N	\N	\N	\N	Весільна підписка №17\nне класти гвоздики	courier	кв. 122, поверх 16	\N	\N	\N
66	66	931	2026-06-13	Очікує	\N	2026-04-22 17:15:51.518093	2026-04-22 17:15:51.518096	вул . Голосіївська 4	\N	\N	\N	f	\N	\N	M	+380631528014	\N	\N	\N	\N	Весільна підписка №17\nне класти гвоздики	courier	кв. 122, поверх 16	\N	\N	\N
67	67	931	2026-07-11	Очікує	\N	2026-04-22 17:15:51.519811	2026-04-22 17:15:51.519814	вул . Голосіївська 4	\N	\N	\N	f	\N	\N	M	+380631528014	\N	\N	\N	\N	Весільна підписка №17\nне класти гвоздики	courier	кв. 122, поверх 16	\N	\N	\N
68	68	931	2026-08-08	Очікує	\N	2026-04-22 17:15:51.52096	2026-04-22 17:15:51.520965	вул . Голосіївська 4	\N	\N	\N	f	\N	\N	M	+380631528014	\N	\N	\N	\N	Весільна підписка №17\nне класти гвоздики	courier	кв. 122, поверх 16	\N	\N	\N
75	75	937	2026-05-11	Очікує	\N	2026-04-22 17:15:51.561769	2026-04-24 18:04:38.87916	Волоська 12/4	\N	\N	\N	f	\N	\N	XL	+380975850765	\N	\N	\N	\N	Усього 3 букети, їх не підрізати сильно, залишати більш довгими стебла. \n- 1 композиція в білих кольорах ( розмір М), не додавати панікум та еустоми, без сухлцвітів і декор додатків\n- 2 та 3 букет робити різними, без яскравих поєднаннь кольорів, максимум 2-3 кольри в одній компзиціі , або монокомпозиціі\n\nбез сухлцвітів і декор додатків, щоб не було різкого аромату так як є алергики колеги\nТакож можна використовувати якісь незвичайні екзотичні квітки нехай вона буде дорожче і навколо щось інше\nлюблять поєднання білого і зеленого\n\nДоставка у понеділок 11-13\n\nВідправляти тільки на цей номер: 0975850765-Юлія	courier	Поділ	\N	\N	\N
69	69	932	2026-05-03	Очікує	\N	2026-04-22 17:15:51.528757	2026-04-24 11:45:48.873302		\N	\N	\N	f	\N	\N	XXL	+380952046405	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
62	62	930	2026-04-26	Очікує	\N	2026-04-22 17:15:51.504817	2026-04-25 17:34:05.362396	Нагірна 18\\16	\N	\N	\N	f	12:00	13:00	M	+380671216260	\N	\N	\N	\N	погоджувати з @yuligrishko	courier	14 поверх, 294 квартира	\N	\N	\N
70	70	932	2026-05-10	Очікує	\N	2026-04-22 17:15:51.530325	2026-04-24 11:45:50.401902		\N	\N	\N	f	\N	\N	XXL	+380952046405	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
110	110	968	2026-05-04	Очікує	\N	2026-04-22 17:15:51.793196	2026-04-22 17:15:51.793199	Охтирський провулок 7	\N	\N	\N	f	\N	\N	M	+380734595942	\N	\N	\N	\N	відправляти по 2 збірних букети М	courier	корпус 3а	\N	\N	\N
71	71	932	2026-05-17	Очікує	\N	2026-04-22 17:15:51.531175	2026-04-24 11:45:50.403894		\N	\N	\N	f	\N	\N	XXL	+380952046405	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
73	73	556	2026-05-09	Очікує	\N	2026-04-22 17:15:51.53901	2026-04-24 10:01:25.180027	вул. Кудрявська 24а	\N	\N	\N	f	\N	\N	L	+380962898470	\N	\N	\N	\N	Весільна підписка №8\r\n@Kuleshova_valeriia\r\nкожного разу різні розміри (див. згідно табл весільних підписок)	courier	3 секція, кв. 202 (ЖК Львівська площа)	\N	\N	\N
26	26	903	2026-04-26	Очікує	\N	2026-04-22 17:15:51.314522	2026-04-25 17:34:05.370956	пр-т Науки 60а	\N	\N	\N	f	10:00	13:00	M	+380509959819	3	\N	\N	\N	\N	courier	кв. 36, 6 поверх, 1 підʼїзд	\N	\N	\N
242	242	1028	2026-05-18	Очікує	\N	2026-04-24 13:47:32.12253	2026-04-24 13:47:32.122536	треба уточнити	\N	\N	\N	f	\N	\N	M	+380508542523	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
181	181	1015	2026-04-26	Очікує	\N	2026-04-22 17:15:52.183261	2026-04-25 17:34:05.381067	Соборності 17к2	\N	\N	\N	f	16:00	17:30	M	+380955793157	\N	\N	\N	\N	\N	courier	зателефонувати за декілька хвилин щоб зробили заявку на пропуск	\N	\N	\N
243	243	1028	2026-05-02	Очікує	уточнити всі деталі у отримувача, не оплачено, перша дотсавка на 5.05	2026-04-24 13:47:32.124013	2026-04-24 13:49:00.035913	треба уточнити	\N	\N	\N	f	\N	\N	M	+380508542523	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
76	76	938	2026-04-26	Очікує	\N	2026-04-22 17:15:51.568014	2026-04-25 17:39:19.328083	вул. Богдана Хмельницького 32	\N	\N	\N	f	11:00	13:00	XL	+380958271977	4	\N	\N	\N	доставки зранку 11-13\r\nЩоб у букетах не було троянд (в будь якому разі не більше 2 шт.)	courier	2 підʼїзд, кв. 39	\N	\N	\N
78	78	943	2026-05-10	Очікує	\N	2026-04-22 17:15:51.601194	2026-04-22 17:15:51.601199	провулок Леопольда Ященка 17|25	\N	\N	\N	f	\N	\N	XL	+380678550707	\N	\N	\N	\N	Кидати фото квітів в дірект перед кожною відправкою\nПобажання - дуже важливо БЕЗ фіолетових та жовтих квітів. Квіти потрібно кожен раз інші, може сезонні.	courier	63 кв	\N	\N	\N
79	79	943	2026-06-07	Очікує	\N	2026-04-22 17:15:51.603622	2026-04-22 17:15:51.603626	провулок Леопольда Ященка 17|25	\N	\N	\N	f	\N	\N	XL	+380678550707	\N	\N	\N	\N	Кидати фото квітів в дірект перед кожною відправкою\nПобажання - дуже важливо БЕЗ фіолетових та жовтих квітів. Квіти потрібно кожен раз інші, може сезонні.	courier	63 кв	\N	\N	\N
80	80	943	2026-07-05	Очікує	\N	2026-04-22 17:15:51.604867	2026-04-22 17:15:51.604871	провулок Леопольда Ященка 17|25	\N	\N	\N	f	\N	\N	XL	+380678550707	\N	\N	\N	\N	Кидати фото квітів в дірект перед кожною відправкою\nПобажання - дуже важливо БЕЗ фіолетових та жовтих квітів. Квіти потрібно кожен раз інші, може сезонні.	courier	63 кв	\N	\N	\N
81	81	944	2026-05-10	Очікує	\N	2026-04-22 17:15:51.618615	2026-04-22 17:15:51.618621	Марка Безручка 29	\N	\N	\N	f	\N	\N	L	+380934262659	\N	\N	\N	\N	\N	courier	3 під'їзд, 1 поверх, 59 квартира. Код від дверей - 16	\N	\N	\N
82	82	944	2026-06-07	Очікує	\N	2026-04-22 17:15:51.620739	2026-04-22 17:15:51.620743	Марка Безручка 29	\N	\N	\N	f	\N	\N	L	+380934262659	\N	\N	\N	\N	\N	courier	3 під'їзд, 1 поверх, 59 квартира. Код від дверей - 16	\N	\N	\N
83	83	944	2026-07-05	Очікує	\N	2026-04-22 17:15:51.621598	2026-04-22 17:15:51.621601	Марка Безручка 29	\N	\N	\N	f	\N	\N	L	+380934262659	\N	\N	\N	\N	\N	courier	3 під'їзд, 1 поверх, 59 квартира. Код від дверей - 16	\N	\N	\N
84	84	946	2026-05-02	Очікує	\N	2026-04-22 17:15:51.634028	2026-04-22 17:15:51.634032	вул Жилянська 68	\N	\N	\N	f	\N	\N	L	+380937356031	\N	\N	\N	\N	\N	courier	(Кадорр) - зустріти у холі	\N	\N	\N
87	87	950	2026-05-11	Очікує	\N	2026-04-22 17:15:51.657533	2026-04-22 17:15:51.657536	провулок Шевченка 34	\N	\N	\N	f	\N	\N	L	+380503875956	\N	\N	\N	\N	не хотіла б отримувати лілії або супер ароматні квіти	courier	(Жуляни)	\N	\N	\N
88	88	950	2026-05-25	Очікує	\N	2026-04-22 17:15:51.659387	2026-04-22 17:15:51.65939	провулок Шевченка 34	\N	\N	\N	f	\N	\N	L	+380503875956	\N	\N	\N	\N	не хотіла б отримувати лілії або супер ароматні квіти	courier	(Жуляни)	\N	\N	\N
89	89	950	2026-06-08	Очікує	\N	2026-04-22 17:15:51.660196	2026-04-22 17:15:51.660198	провулок Шевченка 34	\N	\N	\N	f	\N	\N	L	+380503875956	\N	\N	\N	\N	не хотіла б отримувати лілії або супер ароматні квіти	courier	(Жуляни)	\N	\N	\N
90	90	951	2026-05-09	Очікує	\N	2026-04-22 17:15:51.666793	2026-04-22 17:15:51.666796	Донця 2а	\N	\N	\N	f	\N	\N	L	+380969423787	\N	\N	\N	\N	Доставки погоджувати з marchenkobogomaz\n6 доставок на 6 місяців	courier	2 парадне, 9 поверх, 181 кв	\N	\N	\N
91	91	953	2026-05-02	Очікує	\N	2026-04-22 17:15:51.677367	2026-04-22 17:15:51.67737	Андрія Верхогляда 2а	\N	\N	\N	f	\N	\N	M	+380501525455	\N	\N	\N	\N	\N	courier	перший підʼїзд, 2 поверх , квартира 9	\N	\N	\N
92	92	953	2026-05-20	Очікує	\N	2026-04-22 17:15:51.67821	2026-04-22 17:15:51.678213	Андрія Верхогляда 2а	\N	\N	\N	f	\N	\N	M	+380501525455	\N	\N	\N	\N	\N	courier	перший підʼїзд, 2 поверх , квартира 9	\N	\N	\N
93	93	954	2026-05-02	Очікує	\N	2026-04-22 17:15:51.684359	2026-04-22 17:15:51.684362	Михайла Донця 2а	\N	\N	\N	f	\N	\N	M	+380980733259	\N	\N	\N	\N	погоджувати у вотсап	courier	2 підʼїзд, 2 поверх, 147 кв.	\N	\N	\N
94	94	954	2026-05-16	Очікує	\N	2026-04-22 17:15:51.685168	2026-04-22 17:15:51.685171	Михайла Донця 2а	\N	\N	\N	f	\N	\N	M	+380980733259	\N	\N	\N	\N	погоджувати у вотсап	courier	2 підʼїзд, 2 поверх, 147 кв.	\N	\N	\N
95	95	473	2026-05-11	Очікує	\N	2026-04-22 17:15:51.690794	2026-04-22 17:15:51.690799	Чоколівський бульвар 32	\N	\N	\N	f	\N	\N	M	+380933133314	\N	\N	\N	\N	\N	courier	#VALUE!	\N	\N	\N
96	96	473	2026-06-08	Очікує	\N	2026-04-22 17:15:51.691802	2026-04-22 17:15:51.691807	Чоколівський бульвар 32	\N	\N	\N	f	\N	\N	M	+380933133314	\N	\N	\N	\N	\N	courier	#VALUE!	\N	\N	\N
98	98	956	2026-05-07	Очікує	\N	2026-04-22 17:15:51.706999	2026-04-22 17:15:51.707003	вул. Юлії Здановської 71 Д	\N	\N	\N	f	\N	\N	XL	+380937163442	\N	\N	\N	\N	\N	courier	ЖК Сонячна Брама \nвул. Юлії Здановської 71 Д  1 під‘їзд кв.9	\N	\N	\N
99	99	956	2026-05-21	Очікує	\N	2026-04-22 17:15:51.708279	2026-04-22 17:15:51.708283	вул. Юлії Здановської 71 Д	\N	\N	\N	f	\N	\N	XL	+380937163442	\N	\N	\N	\N	\N	courier	ЖК Сонячна Брама \nвул. Юлії Здановської 71 Д  1 під‘їзд кв.9	\N	\N	\N
100	100	957	2026-05-07	Очікує	\N	2026-04-22 17:15:51.715712	2026-04-22 17:15:51.715715	Площа Європейського союзу 80в	\N	\N	\N	f	\N	\N	XL	+380635269936	\N	\N	\N	\N	доставки по середам	courier	кв 191, під'їзд 6, 3 поверх	\N	\N	\N
102	102	959	2026-05-23	Очікує	\N	2026-04-22 17:15:51.72771	2026-04-22 17:15:51.727713	вулиця Вікентія Беретті 12	\N	\N	\N	f	\N	\N	M	+380939600253	\N	\N	\N	\N	\N	courier	4 підʼїзд ,кв 111, 1 поверх\nКиїв, Україна 02222	\N	\N	\N
103	103	960	2026-05-07	Очікує	\N	2026-04-22 17:15:51.735424	2026-04-22 17:15:51.735427	Івано-Франківськ	\N	\N	\N	f	\N	\N	L	+380969976617	\N	\N	\N	\N	\N	courier	Івано-Франківськ, вул. Галицька 169	\N	\N	\N
104	104	962	2026-05-02	Очікує	\N	2026-04-22 17:15:51.748161	2026-04-22 17:15:51.748164	вул Центральна 19	\N	\N	\N	f	\N	\N	XL	+380997974059	\N	\N	\N	\N	Надіслати фото перед відправкою\nне класти лілії та соняшник - алергія	courier	(район Осокорки), корпус 2, кв. 39	\N	\N	\N
105	105	962	2026-05-09	Очікує	\N	2026-04-22 17:15:51.749207	2026-04-22 17:15:51.749211	вул Центральна 19	\N	\N	\N	f	\N	\N	XL	+380997974059	\N	\N	\N	\N	Надіслати фото перед відправкою\nне класти лілії та соняшник - алергія	courier	(район Осокорки), корпус 2, кв. 39	\N	\N	\N
106	106	963	2026-05-16	Очікує	\N	2026-04-22 17:15:51.758817	2026-04-22 17:15:51.75882	вулиця Половецька 12	\N	\N	\N	f	\N	\N	XL	+380930178353	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
107	107	964	2026-05-09	Очікує	\N	2026-04-22 17:15:51.765224	2026-04-22 17:15:51.765228	вулиця Болсуновська  2	\N	\N	\N	f	\N	\N	XL	+380972138899	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
108	108	967	2026-05-09	Очікує	\N	2026-04-22 17:15:51.783408	2026-04-22 17:15:51.783412	вулиця Василя Липківського 38А	\N	\N	\N	f	\N	\N	M	+380993728446	\N	\N	\N	\N	\N	courier	підʼїзд 1.01, кв. 73	\N	\N	\N
86	86	950	2026-04-27	Розподілено	\N	2026-04-22 17:15:51.6557	2026-04-24 18:18:44.026816	провулок Шевченка 34	\N	\N	\N	f	15:00	17:00	L	+380503875956	\N	\N	\N	\N	не хотіла б отримувати лілії або супер ароматні квіти	courier	(Жуляни)	\N	\N	\N
97	97	955	2026-05-02	Очікує	\N	2026-04-22 17:15:51.699124	2026-04-24 09:49:26.481716	просп. Берестейський 67	\N	\N	\N	f	\N	\N	M	+380678998979	\N	\N	\N	\N	з отримувачем в вотцап	courier	ЖК Сан-Франциско, біля входу в "Галя Балувана"	\N	\N	\N
111	111	969	2026-05-16	Очікує	\N	2026-04-22 17:15:51.800007	2026-04-22 17:15:51.80001	вул. Регенераторна 4	\N	\N	\N	f	\N	\N	M	+380673891519	\N	\N	\N	\N	\N	courier	ЖК Комфорт Таунт\nкорп. 9, кв. 21 (5 поверх)	\N	\N	\N
113	113	971	2026-05-02	Очікує	\N	2026-04-22 17:15:51.812049	2026-04-22 17:15:51.812052	б-р Миколи Міхновського 4/6	\N	\N	\N	f	\N	\N	M	+380956673239	\N	\N	\N	\N	\N	courier	Третій під'їзд, домофон не працює. Тому набирати по приїзду	\N	\N	\N
245	245	1009	2026-05-02	Очікує	\N	2026-04-24 14:17:17.711909	2026-04-24 14:17:17.711916	НП, м. Чернівці, поштомат 25392, Стефанець Інна, 0954081262	\N	\N	\N	f	\N	\N	L	+380954081262	\N	\N	\N	\N	"Точно ранунклюс, півонія та еустома(знає що не відправляємо новою поштою півонії і еустоми, можливо щось подібне відправляти). Багато дивної і цікавої зелені. Можна хвою чи лопузи якісь навіть.\r\n\r\nНепотрібні гербери, троянди, лілії та решта із солодким стійким ароматом. \r\n"	nova_poshta	\N	\N	\N	\N
115	115	974	2026-05-09	Очікує	\N	2026-04-22 17:15:51.830827	2026-04-22 17:15:51.83083	вулиця Степана Рудницького 19/14	\N	\N	\N	f	\N	\N	M	+380667814745	\N	\N	\N	\N	ТАК: троянди, тюльпани, іриси, нарциси. ТАК: зелений, фіолетовий в комбінації + яскраві акценти. НІ: ромашки, гербери, альстромерії. НІ: салатовий, оранжевий. Монобукети - ок. Мікс з екзотикою - супер	courier	кв. 523	\N	\N	\N
116	116	974	2026-05-23	Очікує	\N	2026-04-22 17:15:51.832707	2026-04-22 17:15:51.83271	вулиця Степана Рудницького 19/14	\N	\N	\N	f	\N	\N	M	+380667814745	\N	\N	\N	\N	ТАК: троянди, тюльпани, іриси, нарциси. ТАК: зелений, фіолетовий в комбінації + яскраві акценти. НІ: ромашки, гербери, альстромерії. НІ: салатовий, оранжевий. Монобукети - ок. Мікс з екзотикою - супер	courier	кв. 523	\N	\N	\N
117	117	974	2026-06-06	Очікує	\N	2026-04-22 17:15:51.833697	2026-04-22 17:15:51.833701	вулиця Степана Рудницького 19/14	\N	\N	\N	f	\N	\N	M	+380667814745	\N	\N	\N	\N	ТАК: троянди, тюльпани, іриси, нарциси. ТАК: зелений, фіолетовий в комбінації + яскраві акценти. НІ: ромашки, гербери, альстромерії. НІ: салатовий, оранжевий. Монобукети - ок. Мікс з екзотикою - супер	courier	кв. 523	\N	\N	\N
119	119	737	2026-05-10	Очікує	\N	2026-04-22 17:15:51.849545	2026-04-22 17:15:51.849548		\N	\N	\N	f	\N	\N	L	+380633666699	\N	\N	\N	\N	@Mr_L1f3	courier	\N	\N	\N	\N
120	120	976	2026-04-28	Очікує	\N	2026-04-22 17:15:51.861645	2026-04-22 17:15:51.861648	Голосіївський проспект 118б	\N	\N	\N	f	\N	\N	L	+380631715386	\N	\N	\N	\N	Квіти для офісу	courier	\N	\N	\N	\N
121	121	976	2026-05-05	Очікує	\N	2026-04-22 17:15:51.86257	2026-04-22 17:15:51.862573	Голосіївський проспект 118б	\N	\N	\N	f	\N	\N	L	+380631715386	\N	\N	\N	\N	Квіти для офісу	courier	\N	\N	\N	\N
118	118	737	2026-04-26	Очікує	\N	2026-04-22 17:15:51.848614	2026-04-25 17:34:05.370956	яблунева 15/55	\N	\N	\N	f	09:00	12:00	L	+380633666699	\N	\N	\N	\N	@Mr_L1f3	courier	кв4, Софіївська Борщагівка	\N	\N	\N
123	123	977	2026-05-10	Очікує	\N	2026-04-22 17:15:51.870876	2026-04-22 17:15:51.870879	Проспект Академіка Глушкова 9г	\N	\N	\N	f	\N	\N	M	+380991110078	\N	\N	\N	\N	\N	courier	18 поверх квартира 159	\N	\N	\N
124	124	980	2026-05-09	Очікує	\N	2026-04-22 17:15:51.885645	2026-04-22 17:15:51.885648	Оболонський проспект, 26	\N	\N	\N	f	\N	\N	L	+380674630780	\N	\N	\N	\N	@nkotelianska - Без червоних і бордових квітів, Без червоних троянд, Побажання взнала бежева мама \nВсе  ніжне біле  рожеве естетичне	courier	Це Оболонь резіденс \nСекція А, треба залишати номер авто для перепустки	\N	\N	\N
125	125	980	2026-05-24	Очікує	\N	2026-04-22 17:15:51.887655	2026-04-22 17:15:51.887658	Оболонський проспект, 26	\N	\N	\N	f	\N	\N	L	+380674630780	\N	\N	\N	\N	@nkotelianska - Без червоних і бордових квітів, Без червоних троянд, Побажання взнала бежева мама \nВсе  ніжне біле  рожеве естетичне	courier	Це Оболонь резіденс \nСекція А, треба залишати номер авто для перепустки	\N	\N	\N
126	126	980	2026-06-07	Очікує	\N	2026-04-22 17:15:51.889403	2026-04-22 17:15:51.889407	Оболонський проспект, 26	\N	\N	\N	f	\N	\N	L	+380674630780	\N	\N	\N	\N	@nkotelianska - Без червоних і бордових квітів, Без червоних троянд, Побажання взнала бежева мама \nВсе  ніжне біле  рожеве естетичне	courier	Це Оболонь резіденс \nСекція А, треба залишати номер авто для перепустки	\N	\N	\N
127	127	980	2026-06-21	Очікує	\N	2026-04-22 17:15:51.890241	2026-04-22 17:15:51.890244	Оболонський проспект, 26	\N	\N	\N	f	\N	\N	L	+380674630780	\N	\N	\N	\N	@nkotelianska - Без червоних і бордових квітів, Без червоних троянд, Побажання взнала бежева мама \nВсе  ніжне біле  рожеве естетичне	courier	Це Оболонь резіденс \nСекція А, треба залишати номер авто для перепустки	\N	\N	\N
129	129	982	2026-05-03	Очікує	\N	2026-04-22 17:15:51.904339	2026-04-22 17:15:51.904342	вулиця Сергія Данченка 1	\N	\N	\N	f	\N	\N	M	+380689170743	\N	\N	\N	\N	\N	courier	5 корпус, 19 поверх, квартира 94	\N	\N	\N
130	130	982	2026-05-31	Очікує	\N	2026-04-22 17:15:51.905359	2026-04-22 17:15:51.905363	вулиця Сергія Данченка 1	\N	\N	\N	f	\N	\N	M	+380689170743	\N	\N	\N	\N	\N	courier	5 корпус, 19 поверх, квартира 94	\N	\N	\N
128	128	981	2026-04-26	Розподілено	\N	2026-04-22 17:15:51.895821	2026-04-25 17:34:05.386636		\N	\N	\N	f	16:30	17:30	L	+380503706343	\N	\N	\N	\N	Погоджувати tamaraguseinova	courier	\N	\N	\N	\N
132	132	983	2026-05-24	Очікує	\N	2026-04-22 17:15:51.916058	2026-04-22 17:15:51.916062	вул. Митрополита Василя Липківського 15	\N	\N	\N	f	\N	\N	M	+380953656882	\N	\N	\N	\N	Квіти - білі, бежеві та інші не яскраві кольори (не червоні, не жовті, не рожеві та інше; за можливістю).\nчас з отримувачем узгоджувати\nале самовивіз саме із замовником	courier	61 кв.	\N	\N	\N
134	134	986	2026-04-25	Очікує	\N	2026-04-22 17:15:51.942295	2026-04-25 11:16:05.257336	вулиця Авiаконструктора Iгоря Сікорського 4д	\N	\N	\N	f	09:00	12:00	XL	+380633345654	\N	\N	2026-04-25 07:42:12.182375	\N	\N	courier	1 під'їзд, 8 поверх, кв 35	\N	\N	Передано кур'єру
122	122	977	2026-04-27	Розподілено	\N	2026-04-22 17:15:51.870012	2026-04-24 18:18:44.029421	Проспект Академіка Глушкова 9г	\N	\N	\N	f	11:00	13:00	M	+380991110078	\N	\N	\N	\N	\N	courier	18 поверх квартира 159	\N	\N	\N
135	135	986	2026-05-02	Очікує	\N	2026-04-22 17:15:51.944161	2026-04-22 17:15:51.944164	вулиця Авiаконструктора Iгоря Сікорського 4д	\N	\N	\N	f	\N	\N	XL	+380633345654	\N	\N	\N	\N	\N	courier	1 під'їзд, 8 поверх, кв 35	\N	\N	\N
136	136	986	2026-05-09	Очікує	\N	2026-04-22 17:15:51.945147	2026-04-22 17:15:51.94515	вулиця Авiаконструктора Iгоря Сікорського 4д	\N	\N	\N	f	\N	\N	XL	+380633345654	\N	\N	\N	\N	\N	courier	1 під'їзд, 8 поверх, кв 35	\N	\N	\N
137	137	987	2026-05-16	Очікує	\N	2026-04-22 17:15:51.952761	2026-04-22 17:15:51.952764	проспект Володимира Івасюка 27а	\N	\N	\N	f	\N	\N	M	+380663138847	\N	\N	\N	\N	Є дві адреси у отримувача тому краще мабуть уточняти у нього перед доставко	courier	Під'їзд 3\nПоверх 8\nКв. 309	\N	\N	\N
138	138	987	2026-06-14	Очікує	\N	2026-04-22 17:15:51.953837	2026-04-22 17:15:51.953843	проспект Володимира Івасюка 27а	\N	\N	\N	f	\N	\N	M	+380663138847	\N	\N	\N	\N	Є дві адреси у отримувача тому краще мабуть уточняти у нього перед доставко	courier	Під'їзд 3\nПоверх 8\nКв. 309	\N	\N	\N
140	140	990	2026-05-10	Очікує	\N	2026-04-22 17:15:51.980135	2026-04-22 17:15:51.980139	вул. де Бальзака 46а	\N	\N	\N	f	\N	\N	L	+380635821444	\N	\N	\N	\N	\N	courier	7 поверх, 133 квартира	\N	\N	\N
141	141	992	2026-05-02	Очікує	\N	2026-04-22 17:15:51.993496	2026-04-22 17:15:51.9935	Оксамитова 9а	\N	\N	\N	f	\N	\N	L	+380660136118	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
142	142	992	2026-05-16	Очікує	\N	2026-04-22 17:15:51.994643	2026-04-22 17:15:51.994647	Оксамитова 9а	\N	\N	\N	f	\N	\N	L	+380660136118	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
143	143	993	2026-05-12	Очікує	\N	2026-04-22 17:15:52.002604	2026-04-22 17:15:52.002607	Василя Липківського 37в	\N	\N	\N	f	\N	\N	XL	+380676903863	\N	\N	\N	\N	Просив робити наповнення за прикладами які скидав у дірект	courier	під'їзд 5, поверх 3, кв 404	\N	\N	\N
144	144	993	2026-06-09	Очікує	\N	2026-04-22 17:15:52.003568	2026-04-22 17:15:52.003571	Василя Липківського 37в	\N	\N	\N	f	\N	\N	XL	+380676903863	\N	\N	\N	\N	Просив робити наповнення за прикладами які скидав у дірект	courier	під'їзд 5, поверх 3, кв 404	\N	\N	\N
145	145	994	2026-05-10	Очікує	\N	2026-04-22 17:15:52.01131	2026-04-22 17:15:52.011313	Регенераторна 4	\N	\N	\N	f	\N	\N	M	+380674039910	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
146	146	994	2026-06-07	Очікує	\N	2026-04-22 17:15:52.012138	2026-04-22 17:15:52.012141	Регенераторна 4	\N	\N	\N	f	\N	\N	M	+380674039910	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
148	148	995	2026-05-02	Очікує	\N	2026-04-22 17:15:52.021198	2026-04-22 17:15:52.021202	Зарічна 1Г	\N	\N	\N	f	\N	\N	XL	+380952943461	\N	\N	\N	\N	погоджувати доставки в телеграмі - @ShitikovOl	courier	17 поверх, 160 квартира	\N	\N	\N
149	149	995	2026-05-09	Очікує	\N	2026-04-22 17:15:52.022958	2026-04-22 17:15:52.022961	Зарічна 1Г	\N	\N	\N	f	\N	\N	XL	+380952943461	\N	\N	\N	\N	погоджувати доставки в телеграмі - @ShitikovOl	courier	17 поверх, 160 квартира	\N	\N	\N
150	150	996	2026-04-30	Очікує	\N	2026-04-22 17:15:52.031032	2026-04-22 17:15:52.031035	Проспект Оболонський 7-Б	\N	\N	\N	f	\N	\N	XL	+380934729529	\N	\N	\N	\N	\N	courier	кв 83, 3 підʼїзд, 3 поверх	\N	\N	\N
152	152	997	2026-05-10	Очікує	\N	2026-04-22 17:15:52.038728	2026-04-22 17:15:52.038731	Віктора Некрасова 8	\N	\N	\N	f	\N	\N	L	+380939821599	\N	\N	\N	\N	\N	courier	поверх 15, кв А122	\N	\N	\N
153	153	998	2026-05-03	Очікує	\N	2026-04-22 17:15:52.045593	2026-04-22 17:15:52.045597	поштомат номер 46346, якщо не влазить - Відділення НП номер 1 м.Дубно Рівненської обл.	\N	\N	\N	f	\N	\N	L	+380675080419	\N	\N	\N	\N	\N	nova_poshta	поштомат номер 46346, якщо не влазить - Відділення НП номер 1 м.Дубно Рівненської обл.	\N	\N	\N
139	139	989	2026-04-26	Розподілено	\N	2026-04-22 17:15:51.971635	2026-04-25 17:34:05.358206	провулок Лобачевського  7	\N	\N	\N	f	09:12	12:00	L	+380668217997	\N	\N	\N	\N	\N	courier	3 секція, квартира 225	\N	\N	\N
155	155	1000	2026-05-10	Очікує	\N	2026-04-22 17:15:52.06226	2026-04-22 17:15:52.062263	проспект Дмитра Павличка 3	\N	\N	\N	f	\N	\N	M	+380507010477	\N	\N	\N	\N	Oxana Oxana - телеграм	courier	кв 158	\N	\N	\N
74	74	937	2026-05-04	Очікує	\N	2026-04-22 17:15:51.560879	2026-04-24 18:04:30.358094	Волоська 12/4	\N	\N	\N	f	\N	\N	XL	+380975850765	\N	\N	\N	\N	Усього 3 букети, їх не підрізати сильно, залишати більш довгими стебла. \n- 1 композиція в білих кольорах ( розмір М), не додавати панікум та еустоми, без сухлцвітів і декор додатків\n- 2 та 3 букет робити різними, без яскравих поєднаннь кольорів, максимум 2-3 кольри в одній компзиціі , або монокомпозиціі\n\nбез сухлцвітів і декор додатків, щоб не було різкого аромату так як є алергики колеги\nТакож можна використовувати якісь незвичайні екзотичні квітки нехай вона буде дорожче і навколо щось інше\nлюблять поєднання білого і зеленого\n\nДоставка у понеділок 11-13\n\nВідправляти тільки на цей номер: 0975850765-Юлія	courier	Поділ	\N	\N	\N
151	151	997	2026-04-26	Очікує	\N	2026-04-22 17:15:52.037645	2026-04-25 17:34:05.39855	Віктора Некрасова 8	\N	\N	\N	f	09:00	12:00	L	+380939821599	\N	\N	\N	\N	\N	courier	поверх 15, кв А122	\N	\N	\N
178	178	1013	2026-05-02	Очікує	\N	2026-04-22 17:15:52.166465	2026-04-22 17:15:52.166468	Проспект Голосіївський 68	\N	\N	\N	f	\N	\N	M	+380732145953	\N	\N	\N	\N	\N	courier	3 під’їзд, 146 квартира	\N	\N	\N
179	179	1013	2026-05-09	Очікує	\N	2026-04-22 17:15:52.167277	2026-04-22 17:15:52.16728	Проспект Голосіївський 68	\N	\N	\N	f	\N	\N	M	+380732145953	\N	\N	\N	\N	\N	courier	3 під’їзд, 146 квартира	\N	\N	\N
212	212	939	2026-04-25	Очікує	\N	2026-04-23 11:57:11.417447	2026-04-25 11:16:05.257336	Котельникова 17	\N	\N	\N	f	09:00	12:00	L	+380973124469	\N	\N	2026-04-25 07:42:12.182375	\N	доставки узгоджувати із замовником, писати в телеграм	courier	12 поверх, кв. 55	\N	\N	Передано кур'єру
224	224	1027	2026-06-20	Очікує	\N	2026-04-23 19:07:40.991042	2026-04-23 19:13:42.291192	Каземира Малевича 48	\N	\N	\N	f	\N	\N	XL	+380506819961	\N	\N	\N	\N	не класти троянди	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	\N	\N	\N
225	225	1027	2026-06-27	Очікує	\N	2026-04-23 19:07:40.992074	2026-04-23 19:13:46.620258	Каземира Малевича 48	\N	\N	\N	f	\N	\N	XL	+380506819961	\N	\N	\N	\N	не класти троянди	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	\N	\N	\N
156	156	1002	2026-05-02	Очікує	\N	2026-04-22 17:15:52.071074	2026-04-24 08:27:50.719414	Проспект Володимира Івасюка 6ак2	\N	\N	\N	f	\N	\N	M	+380674489130	\N	\N	\N	\N	\N	courier	22 поверх, 240 квартира	\N	\N	\N
180	180	1014	2026-05-02	Очікує	\N	2026-04-22 17:15:52.176293	2026-04-24 11:43:14.689605	Причальна 14	\N	\N	\N	f	\N	\N	M	+380950951649	\N	\N	\N	\N	Марія Горобець(телеграм)	courier	кв 71, 6 поверх	\N	\N	\N
158	158	1003	2026-05-02	Очікує	\N	2026-04-22 17:15:52.081863	2026-04-22 17:15:52.081866	вул. Ярославська, 32-А	\N	\N	\N	f	\N	\N	L	+380672243986	\N	\N	\N	\N	@LudmilaIvanets, сама будет писать когда отправлять букеты, \nПрошу більше не кидати в коробку яку везуть мені конфеті \n1. Курʼєр не має дзвонити в двері. Ні в домофон, ні в двері квартири. В мене маленька дитина.\nПо квітам \nЯ люблю кольорові букети «а-ля з бабусиного саду» \nВ цілому такі як ц вас в референсі на сайті же замовлення підписки \n\n Екзотика для мене це якісь не стандартні квітки. Типу волохаті всякі \nБутони великі як фрукт \nМене вони трохи лякають 😂\nТипу такі як на фото \nІ схожі \nЯкісь типу чорні чи темні теж не подобаються \nЩе не подобаються типу сухі. Не знаю як пояснити \nЯк шишки \nЦе все не кладіть будь ласка	courier	Поділ \nу двір заходити НЕ ТРЕБА \n1 підʼїзд з вулиці \n\nОрієнтир: \nРесторан Pan Chang \nЯкщо на нього дивитись, то другі двері справа \nПід вивіскою, 32-А \n\nКод: 5 \nПоверх: 3 \nКвартира: 5	\N	\N	\N
159	159	1003	2026-05-09	Очікує	\N	2026-04-22 17:15:52.08276	2026-04-22 17:15:52.082763	вул. Ярославська, 32-А	\N	\N	\N	f	\N	\N	L	+380672243986	\N	\N	\N	\N	@LudmilaIvanets, сама будет писать когда отправлять букеты, \nПрошу більше не кидати в коробку яку везуть мені конфеті \n1. Курʼєр не має дзвонити в двері. Ні в домофон, ні в двері квартири. В мене маленька дитина.\nПо квітам \nЯ люблю кольорові букети «а-ля з бабусиного саду» \nВ цілому такі як ц вас в референсі на сайті же замовлення підписки \n\n Екзотика для мене це якісь не стандартні квітки. Типу волохаті всякі \nБутони великі як фрукт \nМене вони трохи лякають 😂\nТипу такі як на фото \nІ схожі \nЯкісь типу чорні чи темні теж не подобаються \nЩе не подобаються типу сухі. Не знаю як пояснити \nЯк шишки \nЦе все не кладіть будь ласка	courier	Поділ \nу двір заходити НЕ ТРЕБА \n1 підʼїзд з вулиці \n\nОрієнтир: \nРесторан Pan Chang \nЯкщо на нього дивитись, то другі двері справа \nПід вивіскою, 32-А \n\nКод: 5 \nПоверх: 3 \nКвартира: 5	\N	\N	\N
161	161	1005	2026-05-09	Очікує	\N	2026-04-22 17:15:52.094266	2026-04-22 17:15:52.094269	вул Олега Мудрака 66	\N	\N	\N	f	\N	\N	L	+380504071653	\N	\N	\N	\N	яскраві букети, екзотика	courier	кв 12	\N	\N	\N
166	166	1008	2026-05-05	Очікує	\N	2026-04-22 17:15:52.118044	2026-04-22 17:15:52.118048	Фортечний Тупик 6/8	\N	\N	\N	f	\N	\N	XL	+380669003305	\N	\N	\N	\N	Якщо доставка до 14 години\nто отримувач я\nДмитро 0669003305\nякщо після то Катерина 0994377946\nвсі квіти підходять\nЯкщо у вас є листівки з Днем Народження, то я б хотів якісь різні в обидва букети\nце на день народження мамі та бабусі	courier	під'їзд 6, поверх 4, кв 122	\N	\N	\N
167	167	1009	2026-05-01	Очікує	\N	2026-04-22 17:15:52.126837	2026-04-22 17:15:52.12684	Чернівці	\N	\N	\N	f	\N	\N	M	+380505734831	\N	\N	\N	\N	"Весняні любі квіти\nХоч польові 🤣\nЧим простіші тим краще"\nЛистівка потрібна.\nПисати щоразу "Ти варта найкращого"	courier	м. Чернівці, Фотокакіс Яніна Костянтинівна. Поштомат 56232, відділення 17 Чернівці	\N	\N	\N
168	168	1009	2026-05-29	Очікує	\N	2026-04-22 17:15:52.128649	2026-04-22 17:15:52.128652	Чернівці	\N	\N	\N	f	\N	\N	M	+380505734831	\N	\N	\N	\N	"Весняні любі квіти\nХоч польові 🤣\nЧим простіші тим краще"\nЛистівка потрібна.\nПисати щоразу "Ти варта найкращого"	courier	м. Чернівці, Фотокакіс Яніна Костянтинівна. Поштомат 56232, відділення 17 Чернівці	\N	\N	\N
169	169	1009	2026-06-26	Очікує	\N	2026-04-22 17:15:52.12949	2026-04-22 17:15:52.129493	Чернівці	\N	\N	\N	f	\N	\N	M	+380505734831	\N	\N	\N	\N	"Весняні любі квіти\nХоч польові 🤣\nЧим простіші тим краще"\nЛистівка потрібна.\nПисати щоразу "Ти варта найкращого"	courier	м. Чернівці, Фотокакіс Яніна Костянтинівна. Поштомат 56232, відділення 17 Чернівці	\N	\N	\N
170	170	1010	2026-04-29	Очікує	\N	2026-04-22 17:15:52.137365	2026-04-22 17:15:52.137368	Львів	\N	\N	\N	f	\N	\N	L	+380936546643	\N	\N	\N	\N	\N	courier	.Львів, 52 відділення\n+380936546643\nЛаврішин Дмитро	\N	\N	\N
171	171	1010	2026-05-27	Очікує	\N	2026-04-22 17:15:52.138946	2026-04-22 17:15:52.138949	Львів	\N	\N	\N	f	\N	\N	L	+380936546643	\N	\N	\N	\N	\N	courier	.Львів, 52 відділення\n+380936546643\nЛаврішин Дмитро	\N	\N	\N
172	172	1010	2026-06-24	Очікує	\N	2026-04-22 17:15:52.139814	2026-04-22 17:15:52.139817	Львів	\N	\N	\N	f	\N	\N	L	+380936546643	\N	\N	\N	\N	\N	courier	.Львів, 52 відділення\n+380936546643\nЛаврішин Дмитро	\N	\N	\N
174	174	1012	2026-05-02	Очікує	\N	2026-04-22 17:15:52.151751	2026-04-22 17:15:52.151755	Відродження 316а	\N	\N	\N	f	\N	\N	L	+380689374919	\N	\N	\N	\N	annanetrebskaia	courier	Крюківщина, Відродження 316а КМ «Беверлі Хілз»	\N	\N	\N
175	175	1012	2026-05-09	Очікує	\N	2026-04-22 17:15:52.153684	2026-04-22 17:15:52.153688	Відродження 316а	\N	\N	\N	f	\N	\N	L	+380689374919	\N	\N	\N	\N	annanetrebskaia	courier	Крюківщина, Відродження 316а КМ «Беверлі Хілз»	\N	\N	\N
176	176	1012	2026-05-16	Очікує	\N	2026-04-22 17:15:52.154837	2026-04-22 17:15:52.154842	Відродження 316а	\N	\N	\N	f	\N	\N	L	+380689374919	\N	\N	\N	\N	annanetrebskaia	courier	Крюківщина, Відродження 316а КМ «Беверлі Хілз»	\N	\N	\N
36	36	910	2026-04-27	Розподілено	\N	2026-04-22 17:15:51.366023	2026-04-24 18:18:44.029415	Коперніка 12Д	\N	\N	\N	f	11:00	13:00	M	+380673325214	\N	\N	\N	\N	по понеділкам на 12 доставка\nінст - yevhen17305	courier	11 поверх, кв. 36	\N	\N	\N
162	162	1006	2026-05-02	Очікує	\N	2026-04-22 17:15:52.101943	2026-04-24 11:41:38.091921	Берестейський проспект 37/2	\N	\N	\N	f	\N	\N	M	+380501602583	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
163	163	1006	2026-05-16	Очікує	\N	2026-04-22 17:15:52.103573	2026-04-24 11:41:43.640989	Берестейський проспект 37/2	\N	\N	\N	f	\N	\N	M	+380501602583	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
164	164	1006	2026-05-30	Очікує	\N	2026-04-22 17:15:52.104347	2026-04-24 11:41:43.643234	Берестейський проспект 37/2	\N	\N	\N	f	\N	\N	M	+380501602583	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
182	182	1016	2026-05-06	Очікує	\N	2026-04-22 17:15:52.190097	2026-04-22 17:15:52.1901	Місто Запоріжжя нова пошта 68	\N	\N	\N	f	\N	\N	XL	+380685412887	\N	\N	\N	\N	Попросив відправляти так: Місто Запоріжжя нова пошта 68 .\nІм'я відправника: Фомчук Іван \n0673260403\nІм'я отримувача : Качмарик Марія\n0685412887\nЗа доставку платять вони в додатку\nКвіти які не бажані до відправлення троянда\nКвіти які обожнює гортензія , півонії , ромашки ,  тюльпани ранункулюс	nova_poshta	Місто Запоріжжя нова пошта 68	\N	\N	\N
183	183	1016	2026-05-20	Очікує	\N	2026-04-22 17:15:52.190948	2026-04-22 17:15:52.190951	Місто Запоріжжя нова пошта 68	\N	\N	\N	f	\N	\N	XL	+380685412887	\N	\N	\N	\N	Попросив відправляти так: Місто Запоріжжя нова пошта 68 .\nІм'я відправника: Фомчук Іван \n0673260403\nІм'я отримувача : Качмарик Марія\n0685412887\nЗа доставку платять вони в додатку\nКвіти які не бажані до відправлення троянда\nКвіти які обожнює гортензія , півонії , ромашки ,  тюльпани ранункулюс	nova_poshta	Місто Запоріжжя нова пошта 68	\N	\N	\N
188	188	1018	2026-05-09	Очікує	\N	2026-04-22 17:15:52.210256	2026-04-22 17:15:52.210259	вулиця Василя Липківського  37Б	\N	\N	\N	f	\N	\N	M	+380932107088	\N	\N	\N	\N	@o_karbovs	courier	підʼїзд 4, поверх 20, кв 348\nКиїв, Україна 03035	\N	\N	\N
189	189	1018	2026-05-23	Очікує	\N	2026-04-22 17:15:52.211038	2026-04-22 17:15:52.21104	вулиця Василя Липківського  37Б	\N	\N	\N	f	\N	\N	M	+380932107088	\N	\N	\N	\N	@o_karbovs	courier	підʼїзд 4, поверх 20, кв 348\nКиїв, Україна 03035	\N	\N	\N
190	190	1019	2026-04-29	Очікує	\N	2026-04-22 17:15:52.216384	2026-04-22 17:15:52.216387	вул.Аболмасова 6	\N	\N	\N	f	\N	\N	M	+380634917882	\N	\N	\N	\N	\N	courier	Там один будинок, тобто 1 підʼїзд, 15 поверх, 82 квартира, ліфт завжди працює, Є дзвіночок до консьєржа на воротах	\N	\N	\N
191	191	1020	2026-04-26	Розподілено	\N	2026-04-22 17:15:52.222524	2026-04-25 17:34:05.358212	вул. Воскресенська 2в	\N	\N	\N	f	09:00	10:00	M	+380939853394	\N	\N	\N	\N	@mrrbanana	courier	1 секція, 10 поверх, 75	\N	\N	\N
192	192	1020	2026-05-10	Очікує	\N	2026-04-22 17:15:52.224035	2026-04-22 17:15:52.224038	вул. Воскресенська 2в	\N	\N	\N	f	\N	\N	M	+380939853394	\N	\N	\N	\N	@mrrbanana	courier	1 секція, 10 поверх, 75	\N	\N	\N
193	193	1020	2026-05-24	Очікує	\N	2026-04-22 17:15:52.224803	2026-04-22 17:15:52.224806	вул. Воскресенська 2в	\N	\N	\N	f	\N	\N	M	+380939853394	\N	\N	\N	\N	@mrrbanana	courier	1 секція, 10 поверх, 75	\N	\N	\N
206	206	1025	2026-04-26	Очікує	\N	2026-04-22 17:15:52.288479	2026-04-25 17:34:05.39071	вул Паркова 22	\N	\N	\N	f	13:00	16:00	XL	+380503116161	4	\N	\N	\N	\N	courier	\N	\N	\N	\N
195	195	1021	2026-05-03	Очікує	\N	2026-04-22 17:15:52.235033	2026-04-22 17:15:52.235037	Андрія Верхогляда, 19б	\N	\N	\N	f	\N	\N	L	+380952023484	\N	\N	\N	\N	час узгодити з отримувачем - @morozoovvva	courier	поверх 10, кв 53	\N	\N	\N
196	196	1021	2026-05-10	Очікує	\N	2026-04-22 17:15:52.236468	2026-04-22 17:15:52.236472	Андрія Верхогляда, 19б	\N	\N	\N	f	\N	\N	L	+380952023484	\N	\N	\N	\N	час узгодити з отримувачем - @morozoovvva	courier	поверх 10, кв 53	\N	\N	\N
197	197	1022	2026-05-05	Очікує	\N	2026-04-22 17:15:52.245602	2026-04-22 17:15:52.245605	Василя Липківського 33А	\N	\N	\N	f	\N	\N	M	+380669973616	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
198	198	1022	2026-05-19	Очікує	\N	2026-04-22 17:15:52.248084	2026-04-22 17:15:52.248087	Василя Липківського 33А	\N	\N	\N	f	\N	\N	M	+380669973616	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
199	199	1022	2026-06-02	Очікує	\N	2026-04-22 17:15:52.249254	2026-04-22 17:15:52.249257	Василя Липківського 33А	\N	\N	\N	f	\N	\N	M	+380669973616	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
200	200	1023	2026-05-03	Очікує	\N	2026-04-22 17:15:52.257652	2026-04-22 17:15:52.257655	Набережно-Лугова 3а	\N	\N	\N	f	\N	\N	M	+380935878272	\N	\N	\N	\N	@ryasna\nПерша доставка - 19.04 \nДалі : \n03.05 \n17.05 \n07.06	courier	кв 53. Підʼїзд 3, поверх 4. Домофон 53	\N	\N	\N
201	201	1023	2026-05-17	Очікує	\N	2026-04-22 17:15:52.259854	2026-04-22 17:15:52.259858	Набережно-Лугова 3а	\N	\N	\N	f	\N	\N	M	+380935878272	\N	\N	\N	\N	@ryasna\nПерша доставка - 19.04 \nДалі : \n03.05 \n17.05 \n07.06	courier	кв 53. Підʼїзд 3, поверх 4. Домофон 53	\N	\N	\N
202	202	1023	2026-05-31	Очікує	\N	2026-04-22 17:15:52.26089	2026-04-22 17:15:52.260894	Набережно-Лугова 3а	\N	\N	\N	f	\N	\N	M	+380935878272	\N	\N	\N	\N	@ryasna\nПерша доставка - 19.04 \nДалі : \n03.05 \n17.05 \n07.06	courier	кв 53. Підʼїзд 3, поверх 4. Домофон 53	\N	\N	\N
203	203	1024	2026-05-04	Очікує	\N	2026-04-22 17:15:52.26993	2026-04-22 17:15:52.269934	вул Райдужна 88	\N	\N	\N	f	\N	\N	L	+380979259809	\N	\N	\N	\N	не хотіли б жовті троянди, узгоджувати з отримувачем, краще писати, не телефонувати бо маленька дитина	courier	кв 80, поверх 4	\N	\N	\N
204	204	1024	2026-05-18	Очікує	\N	2026-04-22 17:15:52.272796	2026-04-22 17:15:52.272801	вул Райдужна 88	\N	\N	\N	f	\N	\N	L	+380979259809	\N	\N	\N	\N	не хотіли б жовті троянди, узгоджувати з отримувачем, краще писати, не телефонувати бо маленька дитина	courier	кв 80, поверх 4	\N	\N	\N
205	205	1024	2026-06-01	Очікує	\N	2026-04-22 17:15:52.27452	2026-04-22 17:15:52.274527	вул Райдужна 88	\N	\N	\N	f	\N	\N	L	+380979259809	\N	\N	\N	\N	не хотіли б жовті троянди, узгоджувати з отримувачем, краще писати, не телефонувати бо маленька дитина	courier	кв 80, поверх 4	\N	\N	\N
207	207	1025	2026-05-03	Очікує	\N	2026-04-22 17:15:52.291482	2026-04-22 17:15:52.291488	вул Паркова 22	\N	\N	\N	f	\N	\N	XL	+380503116161	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
208	208	1025	2026-05-10	Очікує	\N	2026-04-22 17:15:52.29286	2026-04-22 17:15:52.292867	вул Паркова 22	\N	\N	\N	f	\N	\N	XL	+380503116161	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
209	209	1026	2026-05-03	Очікує	\N	2026-04-22 17:15:52.305742	2026-04-22 17:15:52.305747	Столичне шосе 103	\N	\N	\N	f	\N	\N	M	+380639537363	\N	\N	\N	\N	буде писати за декілька днів до замовлення	courier	(Голосіївський район)	\N	\N	\N
210	210	1026	2026-05-17	Очікує	\N	2026-04-22 17:15:52.308247	2026-04-22 17:15:52.30825	Столичне шосе 103	\N	\N	\N	f	\N	\N	M	+380639537363	\N	\N	\N	\N	буде писати за декілька днів до замовлення	courier	(Голосіївський район)	\N	\N	\N
211	211	1026	2026-05-31	Очікує	\N	2026-04-22 17:15:52.30916	2026-04-22 17:15:52.309163	Столичне шосе 103	\N	\N	\N	f	\N	\N	M	+380639537363	\N	\N	\N	\N	буде писати за декілька днів до замовлення	courier	(Голосіївський район)	\N	\N	\N
184	184	1017	2026-05-02	Очікує	\N	2026-04-22 17:15:52.198374	2026-04-24 11:45:09.622547	вулиця Олени Теліги 7	\N	\N	\N	f	\N	\N	M	+380972449990	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
185	185	1017	2026-05-16	Очікує	\N	2026-04-22 17:15:52.200343	2026-04-24 11:45:10.952029	вулиця Олени Теліги 7	\N	\N	\N	f	\N	\N	M	+380972449990	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
186	186	1017	2026-05-30	Очікує	\N	2026-04-22 17:15:52.20115	2026-04-24 11:45:10.954194	вулиця Олени Теліги 7	\N	\N	\N	f	\N	\N	M	+380972449990	\N	\N	\N	\N	\N	courier	\N	\N	\N	\N
157	157	1003	2026-04-23	Очікує	\N	2026-04-22 17:15:52.080158	2026-04-23 11:44:20.63415	вул. Ярославська, 32-А	\N	\N	\N	f	\N	\N	L	+380672243986	\N	\N	\N	\N	@LudmilaIvanets, сама будет писать когда отправлять букеты, \nПрошу більше не кидати в коробку яку везуть мені конфеті \n1. Курʼєр не має дзвонити в двері. Ні в домофон, ні в двері квартири. В мене маленька дитина.\nПо квітам \nЯ люблю кольорові букети «а-ля з бабусиного саду» \nВ цілому такі як ц вас в референсі на сайті же замовлення підписки \n\n Екзотика для мене це якісь не стандартні квітки. Типу волохаті всякі \nБутони великі як фрукт \nМене вони трохи лякають 😂\nТипу такі як на фото \nІ схожі \nЯкісь типу чорні чи темні теж не подобаються \nЩе не подобаються типу сухі. Не знаю як пояснити \nЯк шишки \nЦе все не кладіть будь ласка	courier	Поділ \nу двір заходити НЕ ТРЕБА \n1 підʼїзд з вулиці \n\nОрієнтир: \nРесторан Pan Chang \nЯкщо на нього дивитись, то другі двері справа \nПід вивіскою, 32-А \n\nКод: 5 \nПоверх: 3 \nКвартира: 5	\N	\N	\N
55	55	925	2026-05-16	Очікує	\N	2026-04-22 17:15:51.469912	2026-04-24 14:27:03.434825	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N	f	\N	\N	M	+380507414490	\N	\N	\N	\N	Переїхала у інше місто, чекаємо апдейт коли поновлювати доставки і куди, сама напише\nВесільна підписка #2 - дивитись побажання в табл\nбез евкаліпту\nвона сама буде писати коли ій потрібна доставка	nova_poshta	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N
213	213	939	2026-05-09	Очікує	\N	2026-04-23 11:57:11.420144	2026-04-23 11:57:11.420147	Котельникова 17	\N	\N	\N	f	\N	\N	L	+380973124469	\N	\N	\N	\N	доставки узгоджувати із замовником, писати в телеграм	courier	12 поверх, кв. 55	\N	\N	\N
214	214	939	2026-05-23	Очікує	\N	2026-04-23 11:57:11.422276	2026-04-23 11:57:11.42228	Котельникова 17	\N	\N	\N	f	\N	\N	L	+380973124469	\N	\N	\N	\N	доставки узгоджувати із замовником, писати в телеграм	courier	12 поверх, кв. 55	\N	\N	\N
215	215	939	2026-06-06	Очікує	\N	2026-04-23 11:57:11.423333	2026-04-23 11:57:11.423337	Котельникова 17	\N	\N	\N	f	\N	\N	L	+380973124469	\N	\N	\N	\N	доставки узгоджувати із замовником, писати в телеграм	courier	12 поверх, кв. 55	\N	\N	\N
220	220	1027	2026-05-01	Очікує	ваза+ножиці\r\nЛистівка: "Кохаю тебе"	2026-04-23 19:07:40.982311	2026-04-23 19:07:40.982316	Каземира Малевича 48	\N	\N	\N	f	\N	\N	XL	+380506819961	\N	\N	\N	\N	не класти троянди	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	\N	\N	\N
194	194	1021	2026-04-26	Очікує	\N	2026-04-22 17:15:52.232285	2026-04-25 17:34:05.370956	Андрія Верхогляда, 19б	\N	\N	\N	f	10:00	13:00	L	+380952023484	3	\N	\N	\N	час узгодити з отримувачем - @morozoovvva	courier	поверх 10, кв 53	\N	\N	\N
227	227	729	2026-04-27	Очікує	\N	2026-04-24 08:53:53.612849	2026-04-24 18:09:51.839615	\N	\N	\N	\N	t	\N	\N	XL	+380633689697	\N	\N	\N	\N	\N	courier	 (Офіс, зателефонувати отримувачу перед шлакбаумом)	\N	\N	\N
59	59	927	2026-04-25	Очікує	залишити у консьєржа	2026-04-22 17:15:51.484578	2026-04-25 11:16:05.291542	Завальна 10г	\N	\N	\N	f	10:00	13:00	M	+380959055356	3	\N	2026-04-25 05:32:54.454971	\N	телеграм - @kavinskymax	courier	підїзд Г, кв 35, 5 поверх	\N	\N	Передано кур'єру
216	216	915	2026-05-02	Очікує	\N	2026-04-23 15:35:04.880816	2026-04-23 15:35:04.880821	ул. Ентузіастов 11	\N	\N	\N	f	\N	\N	L	+380996660001	\N	\N	\N	\N	\N	courier	3й під'їзд (навпроти трансформаторної будки), 2 поверх, кв. 67	\N	\N	\N
217	217	915	2026-05-16	Очікує	\N	2026-04-23 15:35:04.88326	2026-04-23 15:35:04.883263	ул. Ентузіастов 11	\N	\N	\N	f	\N	\N	L	+380996660001	\N	\N	\N	\N	\N	courier	3й під'їзд (навпроти трансформаторної будки), 2 поверх, кв. 67	\N	\N	\N
218	218	915	2026-05-30	Очікує	\N	2026-04-23 15:35:04.885326	2026-04-23 15:35:04.885331	ул. Ентузіастов 11	\N	\N	\N	f	\N	\N	L	+380996660001	\N	\N	\N	\N	\N	courier	3й під'їзд (навпроти трансформаторної будки), 2 поверх, кв. 67	\N	\N	\N
219	219	915	2026-06-13	Очікує	\N	2026-04-23 15:35:04.886559	2026-04-23 15:35:04.886563	ул. Ентузіастов 11	\N	\N	\N	f	\N	\N	L	+380996660001	\N	\N	\N	\N	\N	courier	3й під'їзд (навпроти трансформаторної будки), 2 поверх, кв. 67	\N	\N	\N
221	221	1027	2026-05-16	Очікує	\N	2026-04-23 19:07:40.984717	2026-04-23 19:12:37.278788	Каземира Малевича 48	\N	\N	\N	f	\N	\N	XL	+380506819961	\N	\N	\N	\N	не класти троянди	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	\N	\N	\N
222	222	1027	2026-05-23	Очікує	\N	2026-04-23 19:07:40.986843	2026-04-23 19:12:59.646569	Каземира Малевича 48	\N	\N	\N	f	\N	\N	XL	+380506819961	\N	\N	\N	\N	не класти троянди	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	\N	\N	\N
223	223	1027	2026-05-30	Очікує	\N	2026-04-23 19:07:40.988922	2026-04-23 19:12:59.650816	Каземира Малевича 48	\N	\N	\N	f	\N	\N	XL	+380506819961	\N	\N	\N	\N	не класти троянди	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	\N	\N	\N
226	226	914	2026-05-02	Очікує	\N	2026-04-24 08:24:43.938959	2026-04-24 08:24:43.938966	Юрія Шумського 5	\N	\N	\N	f	\N	\N	M	+380631547637	\N	\N	\N	\N	не класти гвоздіку,  не класти у наступні замовлення підписки піон і бузок (повʼязано з алергією	courier	2 підʼїзд, 24 поверх, 254 кв.	\N	\N	\N
229	229	973	2026-05-02	Очікує	\N	2026-04-24 10:52:22.179328	2026-04-24 10:52:22.179334	Монтажників 107	\N	\N	\N	f	\N	\N	L	+380509536315	\N	\N	\N	\N	сюди дві коробки М та Л, треба щоб було різне наповнення	courier	 (приватний будинок)	\N	\N	\N
230	230	973	2026-05-09	Очікує	\N	2026-04-24 10:52:22.182387	2026-04-24 10:52:22.182393	Монтажників 107	\N	\N	\N	f	\N	\N	L	+380509536315	\N	\N	\N	\N	сюди дві коробки М та Л, треба щоб було різне наповнення	courier	 (приватний будинок)	\N	\N	\N
231	231	973	2026-05-16	Очікує	\N	2026-04-24 10:52:22.183899	2026-04-24 10:52:22.183904	Монтажників 107	\N	\N	\N	f	\N	\N	L	+380509536315	\N	\N	\N	\N	сюди дві коробки М та Л, треба щоб було різне наповнення	courier	 (приватний будинок)	\N	\N	\N
17	17	900	2026-04-25	Очікує	\N	2026-04-22 17:15:51.278286	2026-04-25 11:16:05.236245	Жулянська 2г	\N	\N	\N	f	09:00	12:00	M	+380980492293	4	\N	2026-04-25 05:56:29.095613	\N	доставка 10-11 	courier	ЖК Євромісто, 4 підʼїзд, 5 поверх, кв. 151Вишневе	\N	\N	Передано кур'єру
29	29	905	2026-04-25	Очікує	\N	2026-04-22 17:15:51.326922	2026-04-25 11:16:05.236245	просп. Повітряних сил 52	\N	\N	\N	f	∞	\N	M	+380964819288	4	\N	2026-04-25 05:56:29.095613	\N	\N	courier	(кавʼярня Cotton Coffee)\nвхід з вул. Сімʼї Ідзиковських (навпроти Добробуту)	\N	\N	Передано кур'єру
173	173	1012	2026-04-25	Очікує	\N	2026-04-22 17:15:52.150187	2026-04-25 11:16:05.236245	Відродження 316а	\N	\N	\N	f	09:00	12:00	L	+380689374919	4	\N	2026-04-25 05:56:29.095613	\N	annanetrebskaia	courier	Крюківщина, Відродження 316а КМ «Беверлі Хілз»	\N	\N	Передано кур'єру
255	255	585	2026-04-25	Очікує	Додати листівку: нажаль все мить як і ці чудові квіти - на щастя все мить як і наша відстань	2026-04-25 08:00:49.564244	2026-04-25 11:16:05.263836	Богдана Хмельницького 58а	\N	\N	\N	f	11:00	13:00	XL	+380992945852	\N	\N	2026-04-25 08:19:45.358534	\N	\N	courier	Спортивний клуб Вокршоп, залишити на рецепції 	\N	\N	Передано кур'єру
244	244	1029	2026-04-25	Очікує	уточнити адресу, спитати коли зручно отримати, З любовʼю “Na Golovy”, приклад який робили за 2400, ваза и ножиці	2026-04-24 14:03:23.209111	2026-04-25 11:16:05.275836	Івана Виговського 42	\N	\N	\N	f	12:00	14:00	L	+380956275582	\N	\N	2026-04-25 08:27:28.910032	\N	\N	courier	\N	\N	\N	Передано кур'єру
233	233	814	2026-05-09	Очікує	\N	2026-04-24 11:36:27.469776	2026-04-24 11:36:27.4698	Анни Ахматової 18	\N	\N	\N	f	\N	\N	M	+380676012283	\N	\N	\N	\N	\N	courier	12 поверх, 55 квартира 	\N	\N	\N
234	234	814	2026-05-23	Очікує	\N	2026-04-24 11:36:27.472693	2026-04-24 11:36:27.472698	Анни Ахматової 18	\N	\N	\N	f	\N	\N	M	+380676012283	\N	\N	\N	\N	\N	courier	12 поверх, 55 квартира 	\N	\N	\N
235	235	814	2026-06-06	Очікує	\N	2026-04-24 11:36:27.473764	2026-04-24 11:36:27.473768	Анни Ахматової 18	\N	\N	\N	f	\N	\N	M	+380676012283	\N	\N	\N	\N	\N	courier	12 поверх, 55 квартира 	\N	\N	\N
114	114	974	2026-04-25	Очікує	залишити у консьєржа	2026-04-22 17:15:51.828818	2026-04-25 11:16:05.236245	вулиця Степана Рудницького 19/14	\N	\N	\N	f	10:00	13:00	M	+380667814745	4	\N	2026-04-25 05:56:29.095613	\N	ТАК: троянди, тюльпани, іриси, нарциси. ТАК: зелений, фіолетовий в комбінації + яскраві акценти. НІ: ромашки, гербери, альстромерії. НІ: салатовий, оранжевий. Монобукети - ок. Мікс з екзотикою - супер	courier	кв. 523	\N	\N	Передано кур'єру
177	177	1013	2026-04-25	Очікує	\N	2026-04-22 17:15:52.16477	2026-04-25 11:16:05.236245	Проспект Голосіївський 68	\N	\N	\N	f	09:00	12:00	M	+380732145953	4	\N	2026-04-25 05:56:29.095613	\N	\N	courier	3 під’їзд, 146 квартира	\N	\N	Передано кур'єру
187	187	1018	2026-04-25	Очікує	\N	2026-04-22 17:15:52.208565	2026-04-25 11:16:05.236245	вулиця Василя Липківського  37Б	\N	\N	\N	f	09:00	12:00	M	+380932107088	4	\N	2026-04-25 05:56:29.095613	\N	@o_karbovs	courier	підʼїзд 4, поверх 20, кв 348\nКиїв, Україна 03035	\N	\N	Передано кур'єру
228	228	973	2026-04-25	Очікує	\N	2026-04-24 10:52:22.175247	2026-04-25 11:16:05.236245	Монтажників 107	\N	\N	\N	f	09:00	12:00	L	+380509536315	4	\N	2026-04-25 05:56:29.095613	\N	сюди дві коробки М та Л, треба щоб було різне наповнення	courier	 (приватний будинок)	\N	\N	Передано кур'єру
101	101	959	2026-04-25	Очікує	\N	2026-04-22 17:15:51.726805	2026-04-25 11:16:05.269364	Йорданська, 26 	\N	\N	\N	f	12:40	15:00	M	+380939600253	\N	\N	2026-04-25 08:03:30.727003	\N	\N	courier	( метро Оболонь) 7 поверх, 702 кабінет	\N	\N	Передано кур'єру
165	165	1007	2026-04-25	Очікує	\N	2026-04-22 17:15:52.110383	2026-04-25 11:16:05.269364	Вул. Байди-Вишневецького буд. 9	\N	\N	\N	f	09:00	12:00	XL	+380671326366	1	\N	2026-04-25 08:03:30.727003	\N	\N	courier	поверх 9, кв 25	\N	\N	Передано кур'єру
23	23	901	2026-04-25	Очікує	\N	2026-04-22 17:15:51.298816	2026-04-25 11:16:05.291542	Кахи Бендукідзе 2	\N	\N	\N	f	10:00	13:00	L	+380639527548	3	\N	2026-04-25 05:32:54.454971	\N	L - XL - L - XL	courier	кв. 235, 7 поверх, 2 підʼїзд	\N	\N	Передано кур'єру
72	72	556	2026-04-25	Очікує	9а, весільна - від Сергія Тумасова	2026-04-22 17:15:51.537337	2026-04-25 11:16:05.291542	вул. Кудрявська 24а	\N	\N	\N	f	09:00	12:00	L	+380962898470	3	\N	2026-04-25 05:32:54.454971	\N	Весільна підписка №8\r\n@Kuleshova_valeriia\r\nкожного разу різні розміри (див. згідно табл весільних підписок)	courier	3 секція, кв. 202 (ЖК Львівська площа)	\N	\N	Передано кур'єру
256	256	1035	2026-04-28	Очікує	Додати листівку: Привітання з днем весілля	2026-04-25 09:28:01.567809	2026-04-25 09:28:01.567814	Європейського союзу 41Г	\N	\N	\N	f	\N	\N	M	+380636994090	\N	\N	\N	\N	\N	courier	кв 110	\N	\N	\N
257	257	1035	2026-05-26	Очікує	\N	2026-04-25 09:28:01.569728	2026-04-25 09:28:01.569732	Європейського союзу 41Г	\N	\N	\N	f	\N	\N	M	+380636994090	\N	\N	\N	\N	\N	courier	кв 110	\N	\N	\N
258	258	1035	2026-06-23	Очікує	\N	2026-04-25 09:28:01.571849	2026-04-25 09:28:01.571855	Європейського союзу 41Г	\N	\N	\N	f	\N	\N	M	+380636994090	\N	\N	\N	\N	\N	courier	кв 110	\N	\N	\N
259	259	1035	2026-07-21	Очікує	\N	2026-04-25 09:28:01.573065	2026-04-25 09:28:01.573069	Європейського союзу 41Г	\N	\N	\N	f	\N	\N	M	+380636994090	\N	\N	\N	\N	\N	courier	кв 110	\N	\N	\N
260	260	1036	2026-04-25	Доставлено	приклад на 3000 грн з піонами	2026-04-25 09:49:00.709469	2026-04-25 13:25:54.004386	Вадима Гетьмана 30	\N	\N	\N	f	13:30	14:30	L	+380997837494	\N	\N	\N	\N	\N	courier	4-й під'їзд	\N	\N	\N
246	246	1030	2026-04-25	Розподілено	треба в суботу уточнити у отримувача коли зручно отримати, приклад який Наталя робила за 1500грн	2026-04-24 15:10:17.74485	2026-04-25 13:28:33.23285	Вул.Ревуцького, 9	\N	\N	\N	f	16:00	17:00	M	+380676860822	\N	\N	2026-04-25 13:28:33.231967	\N	\N	courier	Секція А, поверх 23, кв 418	\N	\N	Передано кур'єру
248	248	916	2026-05-03	Очікує	\N	2026-04-24 15:17:24.34703	2026-04-24 15:17:24.347035	бульвар Миколи Міхновського, 14-16	\N	\N	\N	f	\N	\N	L	+380676301500	\N	\N	\N	\N	Останній раз писала з інсти: karlustemi	courier	 1 секція, забирають внизу	\N	\N	\N
249	249	916	2026-05-10	Очікує	\N	2026-04-24 15:17:24.349178	2026-04-24 15:17:24.349184	бульвар Миколи Міхновського, 14-16	\N	\N	\N	f	\N	\N	L	+380676301500	\N	\N	\N	\N	Останній раз писала з інсти: karlustemi	courier	 1 секція, забирають внизу	\N	\N	\N
250	250	916	2026-05-17	Очікує	\N	2026-04-24 15:17:24.350282	2026-04-24 15:17:24.350287	бульвар Миколи Міхновського, 14-16	\N	\N	\N	f	\N	\N	L	+380676301500	\N	\N	\N	\N	Останній раз писала з інсти: karlustemi	courier	 1 секція, забирають внизу	\N	\N	\N
251	251	840	2026-04-24	Очікує	Приклад на 2000 тис\r\nДодати листівку: For someone special	2026-04-24 15:55:06.017624	2026-04-24 15:57:53.693838	Проспект Володимира Івасюка 28	\N	\N	\N	f	18:54	20:00	M	+380984922911	\N	\N	\N	\N	\N	courier	Під'їзд 3 Поверх 8 Кв. 102	\N	\N	\N
254	254	1033	2026-04-25	Розподілено	ще не оплатив, уточнити час доставки,  по можливості додайте будь ласка ранункулюсів	2026-04-24 18:32:18.244099	2026-04-25 13:28:33.232851	вулиця Казимира Малевича, 83	\N	\N	\N	f	16:00	17:00	L	+380660167066	\N	\N	2026-04-25 13:28:33.231967	\N	\N	courier	\N	\N	\N	Передано кур'єру
247	247	916	2026-04-26	Очікує	1а, треба взяти готівку 7920 за підписку, потрібен наш кур'єр	2026-04-24 15:17:24.34396	2026-04-25 17:34:05.370956	бульвар Миколи Міхновського, 14-16	\N	\N	\N	f	09:00	12:00	L	+380676301500	3	\N	\N	\N	Останній раз писала з інсти: karlustemi	courier	 1 секція, забирають внизу	\N	\N	\N
85	85	947	2026-04-25	Розподілено	\N	2026-04-22 17:15:51.640107	2026-04-25 13:28:33.232843	Вул.Херсонська 4/2	\N	\N	\N	f	13:00	16:00	L	+380952769452	\N	\N	2026-04-25 13:28:33.231967	\N	@Olga_vkt	courier	Вул.Херсонська 4/2\nБудинок \nhttps://maps.app.goo.gl/v2KD77zFmzv6P2297?g_st=com.google.maps.preview.copy\nСертифікат 013	\N	\N	Передано кур'єру
160	160	1005	2026-04-25	Розподілено	\N	2026-04-22 17:15:52.093428	2026-04-25 13:28:33.232848	вул Олега Мудрака 66	\N	\N	\N	f	16:00	17:30	L	+380504071653	\N	\N	2026-04-25 13:28:33.231967	\N	яскраві букети, екзотика	courier	кв 12	\N	\N	Передано кур'єру
131	131	983	2026-04-26	Очікує	Квіти - білі, бежеві та інші не яскраві кольори (не червоні, не жовті, не рожеві та інше; за можливістю).\r\nчас з отримувачем узгоджувати\r\nале самовивіз саме із замовником	2026-04-22 17:15:51.914924	2026-04-25 17:34:05.370956	вул. Митрополита Василя Липківського 15	\N	\N	\N	f	09:00	12:00	M	+380953656882	3	\N	\N	\N	додати ножиці м'ятні, а свої хай кур'єру віддасть, завезе потім як зручно буде	courier	61 кв.	\N	\N	\N
49	49	922	2026-04-25	Очікує	\N	2026-04-22 17:15:51.437448	2026-04-25 11:16:05.257336	Ризька 59	\N	\N	\N	f	09:00	12:00	L	+380675021778	\N	\N	2026-04-25 07:42:12.182375	\N	доставка с 9 до 12\nНам би хотілось меньше екзотики та більше сезонних квітів.  В яскравій кольоровій гаммі. Потрібен об'єм	courier	(приватний будинок)	\N	\N	Передано кур'єру
77	77	940	2026-04-25	Очікує	\N	2026-04-22 17:15:51.578572	2026-04-25 11:16:05.269364	вулиця Митрополита Володимира Сабодана 21	\N	\N	\N	f	10:00	13:00	M	+380632018762	1	\N	2026-04-25 08:03:30.727003	\N	Доставку узгоджуємо з отримувачем - @daisygun\nподобається кущова троянда та евкаліпт	courier	\N	\N	\N	Передано кур'єру
253	253	1031	2026-04-25	Очікує	треба переробити приклад для нього, на уточнити деталі доставки окрім доставки	2026-04-24 17:58:57.317995	2026-04-25 11:16:05.269364	Вул. Вітряні гори 10Г	\N	\N	\N	f	13:00	15:00	XL	+380932957487	\N	\N	2026-04-25 08:03:30.727003	\N	\N	courier	\N	\N	\N	Передано кур'єру
112	112	971	2026-04-25	Очікує	\N	2026-04-22 17:15:51.811161	2026-04-25 11:16:05.291542	б-р Миколи Міхновського 4/6	\N	\N	\N	f	09:00	12:00	M	+380956673239	3	\N	2026-04-25 05:32:54.454971	\N	\N	courier	Третій під'їзд, домофон не працює. Тому набирати по приїзду	\N	\N	Передано кур'єру
133	133	984	2026-04-25	Очікує	\N	2026-04-22 17:15:51.925522	2026-04-25 11:16:05.291542	вулиця Іоанна Павла II, 6/1	\N	\N	\N	f	09:00	12:00	L	+380636235750	3	\N	2026-04-25 05:32:54.454971	\N	\N	courier	\N	\N	\N	Передано кур'єру
147	147	995	2026-04-25	Очікує	\N	2026-04-22 17:15:52.018944	2026-04-25 11:16:05.291542	Зарічна 1Г	\N	\N	\N	f	09:00	12:00	XL	+380952943461	3	\N	2026-04-25 05:32:54.454971	\N	Доставки завжди 9-12\r\nпогоджувати доставки в телеграмі - @ShitikovOl	courier	17 поверх, 160 квартира	\N	\N	Передано кур'єру
232	232	814	2026-04-25	Очікує	доставки узгоджувати з отримувачем у вотсап - залишати у консьєржа	2026-04-24 11:36:27.467229	2026-04-25 11:16:05.291542	Анни Ахматової 18	\N	\N	\N	f	10:00	13:00	M	+380676012283	3	\N	2026-04-25 05:32:54.454971	\N	\N	courier	12 поверх, 55 квартира 	\N	\N	Передано кур'єру
236	236	835	2026-04-25	Очікує	\N	2026-04-24 12:05:11.952461	2026-04-25 11:16:05.291542	проспект Соборності 30 	\N	\N	\N	f	09:00	22:30	XL	+380675030997	3	\N	2026-04-25 05:32:54.454971	\N	\N	courier	 Кв 161 поверх 7	\N	\N	Передано кур'єру
252	252	965	2026-04-25	Доставлено	приклад того, що хоче кидала у дірект, потрібно відправити після оплати, вона відпише скоріше за все у продовж дня, якщо ні - нагадати \r\n«Дякую за найкращу дружину!»	2026-04-24 17:50:51.142671	2026-04-25 11:58:24.983843	село Іванковичі, вул Акрадівська,1  Інна Сірак  +380 (67) 989 56 36	\N	\N	\N	f	∞	\N	XL	+380679895636	\N	2026-04-25 11:58:24.982994	2026-04-25 11:58:24.982994	\N	\N	nova_poshta	\N	\N	\N	Доставлено
\.


--
-- Data for Name: delivery_routes; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.delivery_routes (id, courier_id, route_date, status, delivery_price, deliveries_count, total_distance_km, estimated_duration_min, telegram_message_id, sent_at, accepted_at, rejected_at, created_at, updated_at, cached_result_json, cached_at, start_time) FROM stdin;
28	7	2026-04-25	accepted	\N	2	20.29	33	\N	\N	\N	\N	2026-04-25 08:54:15.412319	2026-04-25 11:16:05.24782	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 10, "totalDeliveries": 29, "totalDistanceKm": 178.72, "totalDriveMin": 301}, "_selectedDate": "2026-04-25", "_fromDistribute": true, "routes": [{"courierId": "route_28", "courierName": "\\u0423\\u043a\\u043b\\u043e\\u043d", "departureAdjusted": true, "departureTime": "16:00", "geometry": [[50.473297, 30.482599], [50.47286, 30.48312], [50.472523, 30.483521], [50.471796, 30.484387], [50.471599, 30.484617], [50.4715, 30.484745], [50.471425, 30.484739], [50.471143, 30.48472], [50.470095, 30.484633], [50.470035, 30.48463], [50.469514, 30.484576], [50.46943, 30.484566], [50.46933, 30.484554], [50.469287, 30.484549], [50.468778, 30.484485], [50.46855, 30.484456], [50.467979, 30.484417], [50.46755, 30.484372], [50.466593, 30.484306], [50.46638, 30.4843], [50.465773, 30.484204], [50.465128, 30.484187], [50.465087, 30.484195], [50.465053, 30.485097], [50.465015, 30.486084], [50.465013, 30.486138], [50.464733, 30.486146], [50.464583, 30.486157], [50.464277, 30.486229], [50.463933, 30.486322], [50.463888, 30.486335], [50.463701, 30.486417], [50.463622, 30.486451], [50.463419, 30.486543], [50.462957, 30.486742], [50.462463, 30.486928], [50.462405, 30.486941], [50.462109, 30.486979], [50.462068, 30.486981], [50.461003, 30.486739], [50.460935, 30.486724], [50.46093, 30.48667], [50.460916, 30.486612], [50.460894, 30.486551], [50.460585, 30.48576], [50.46039, 30.485273], [50.460294, 30.485034], [50.460268, 30.484984], [50.460224, 30.484934], [50.460201, 30.484908], [50.460192, 30.484918], [50.46011, 30.485007], [50.459865, 30.485272], [50.459674, 30.48547], [50.459117, 30.486047], [50.459081, 30.486086], [50.458822, 30.486347], [50.458756, 30.486409], [50.458642, 30.48651], [50.45858, 30.48657], [50.45833, 30.486817], [50.457941, 30.487201], [50.45786, 30.487285], [50.457583, 30.487584], [50.457533, 30.48764], [50.457402, 30.487841], [50.45724, 30.488133], [50.457151, 30.488331], [50.45711, 30.488411], [50.456947, 30.488731], [50.456887, 30.488849], [50.456785, 30.48886], [50.456721, 30.48889], [50.456443, 30.489022], [50.455913, 30.489284], [50.455881, 30.489307], [50.455811, 30.489341], [50.45498, 30.489732], [50.454439, 30.489986], [50.453903, 30.490252], [50.453317, 30.490524], [50.452846, 30.490762], [50.452791, 30.490785], [50.452742, 30.490801], [50.452673, 30.490832], [50.452546, 30.490889], [50.452487, 30.490916], [50.452284, 30.491018], [50.452192, 30.49107], [50.452054, 30.491142], [50.452033, 30.491157], [50.451854, 30.491333], [50.451745, 30.491463], [50.45153, 30.491714], [50.451395, 30.491887], [50.451184, 30.492138], [50.451169, 30.492156], [50.450858, 30.492526], [50.450754, 30.492648], [50.45065, 30.49277], [50.450424, 30.493038], [50.450347, 30.493129], [50.450301, 30.493183], [50.450249, 30.493245], [50.45006, 30.49347], [50.449842, 30.493728], [50.44979, 30.49379], [50.449421, 30.494227], [50.449343, 30.494313], [50.449309, 30.494258], [50.449034, 30.493796], [50.449, 30.49374], [50.448889, 30.493543], [50.448587, 30.492956], [50.448547, 30.492849], [50.448509, 30.492745], [50.448371, 30.492867], [50.44776, 30.493464], [50.447729, 30.493494], [50.447562, 30.493658], [50.447267, 30.493948], [50.447194, 30.493922], [50.446736, 30.494051], [50.446419, 30.49413], [50.446278, 30.494135], [50.446176, 30.494118], [50.446112, 30.494097], [50.44596, 30.494033], [50.445855, 30.493973], [50.445791, 30.493924], [50.445726, 30.493786], [50.445624, 30.493558], [50.445592, 30.493487], [50.445561, 30.493413], [50.445441, 30.493146], [50.445317, 30.492866], [50.445272, 30.492764], [50.445208, 30.492597], [50.445084, 30.492713], [50.444937, 30.492864], [50.444517, 30.493296], [50.443965, 30.493864], [50.44378, 30.494064], [50.443638, 30.494217], [50.443379, 30.494499], [50.443036, 30.494865], [50.442874, 30.495047], [50.442768, 30.495157], [50.442749, 30.495177], [50.442382, 30.495547], [50.442177, 30.495766], [50.442164, 30.49578], [50.44196, 30.495989], [50.44188, 30.496075], [50.44174, 30.496225], [50.44168, 30.496289], [50.44152, 30.496457], [50.441418, 30.496566], [50.441359, 30.496631], [50.441108, 30.496892], [50.440791, 30.497227], [50.440496, 30.497529], [50.440428, 30.497598], [50.440307, 30.497737], [50.440182, 30.497873], [50.439946, 30.49817], [50.439696, 30.498484], [50.439181, 30.49916], [50.438629, 30.499874], [50.438371, 30.500209], [50.437994, 30.500697], [50.437951, 30.500753], [50.437911, 30.500804], [50.437813, 30.500931], [50.437516, 30.501316], [50.437297, 30.5016], [50.437035, 30.501939], [50.436549, 30.502567], [50.436475, 30.502664], [50.43635, 30.502825], [50.436066, 30.503196], [50.435645, 30.503733], [50.435555, 30.503845], [50.435499, 30.503919], [50.435448, 30.503986], [50.435335, 30.504132], [50.435168, 30.504351], [50.43502, 30.50454], [50.434732, 30.504974], [50.434634, 30.505054], [50.434172, 30.505435], [50.434111, 30.505487], [50.433994, 30.505572], [50.433882, 30.50571], [50.433772, 30.505902], [50.433709, 30.506014], [50.433605, 30.506191], [50.433242, 30.506802], [50.432847, 30.507487], [50.432722, 30.5077], [50.432614, 30.507882], [50.432569, 30.507951], [50.432409, 30.508193], [50.432306, 30.508333], [50.432194, 30.508464], [50.432079, 30.508584], [50.431991, 30.508675], [50.431881, 30.508765], [50.431515, 30.509008], [50.431233, 30.509165], [50.431124, 30.509226], [50.430039, 30.509829], [50.429964, 30.509871], [50.429879, 30.509918], [50.42977, 30.509977], [50.428789, 30.510611], [50.428628, 30.510718], [50.428557, 30.510766], [50.42829, 30.510945], [50.42806, 30.511098], [50.427944, 30.511176], [50.427864, 30.511228], [50.426561, 30.512043], [50.425342, 30.512827], [50.425205, 30.512915], [50.424157, 30.513586], [50.424052, 30.513654], [50.423965, 30.513708], [50.423192, 30.514192], [50.423086, 30.514258], [50.421913, 30.514999], [50.42186, 30.515035], [50.421785, 30.515083], [50.421705, 30.515135], [50.421641, 30.515174], [50.421437, 30.515304], [50.42128, 30.515405], [50.421107, 30.515515], [50.420406, 30.51596], [50.420097, 30.516157], [50.420043, 30.516191], [50.41999, 30.516225], [50.419374, 30.516617], [50.419107, 30.516785], [50.419022, 30.51684], [50.418903, 30.516916], [50.418731, 30.517025], [50.418666, 30.516805], [50.418533, 30.516471], [50.418392, 30.516093], [50.418205, 30.515645], [50.418197, 30.515621], [50.418158, 30.515526], [50.418049, 30.515257], [50.418044, 30.515243], [50.417954, 30.515038], [50.417952, 30.514977], [50.41779, 30.514565], [50.417757, 30.514552], [50.417725, 30.5145], [50.417615, 30.514325], [50.417468, 30.51447], [50.417307, 30.514627], [50.417074, 30.514862], [50.416792, 30.515154], [50.415981, 30.516039], [50.415478, 30.51662], [50.414951, 30.517199], [50.414472, 30.517666], [50.414227, 30.517886], [50.414046, 30.518056], [50.41336, 30.518654], [50.413137, 30.518843], [50.41254, 30.519362], [50.41176, 30.520012], [50.411752, 30.520018], [50.4117, 30.520061], [50.411597, 30.520147], [50.410631, 30.520954], [50.410493, 30.521069], [50.409571, 30.52185], [50.409313, 30.522139], [50.408787, 30.522739], [50.408387, 30.523217], [50.408172, 30.523455], [50.407976, 30.523671], [50.407772, 30.523899], [50.407674, 30.524007], [50.407265, 30.524562], [50.407131, 30.524794], [50.406977, 30.525058], [50.406802, 30.52536], [50.406417, 30.526088], [50.405957, 30.527052], [50.405701, 30.52776], [50.405675, 30.527845], [50.405511, 30.528347], [50.405277, 30.528931], [50.405118, 30.529302], [50.405009, 30.529534], [50.404953, 30.529662], [50.404859, 30.529877], [50.404791, 30.530009], [50.404689, 30.530176], [50.404649, 30.530561], [50.404575, 30.531075], [50.404515, 30.531502], [50.404451, 30.531888], [50.404358, 30.532378], [50.404249, 30.532894], [50.404057, 30.53359], [50.40353, 30.535255], [50.403267, 30.536157], [50.403139, 30.536626], [50.40302, 30.537095], [50.402898, 30.53757], [50.402793, 30.538017], [50.402714, 30.538371], [50.402598, 30.539017], [50.402486, 30.539745], [50.402395, 30.540391], [50.402336, 30.540911], [50.402284, 30.54148], [50.402231, 30.542236], [50.402172, 30.543224], [50.402114, 30.543942], [50.40203, 30.544815], [50.401936, 30.545606], [50.401733, 30.547181], [50.40165, 30.547845], [50.40149, 30.549016], [50.401164, 30.551586], [50.401083, 30.552406], [50.40091, 30.553927], [50.400851, 30.55456], [50.400843, 30.554656], [50.400837, 30.554754], [50.400822, 30.555001], [50.400798, 30.555535], [50.400771, 30.55641], [50.400753, 30.55694], [50.400745, 30.557291], [50.400743, 30.557398], [50.400721, 30.557989], [50.400692, 30.558858], [50.400686, 30.558996], [50.400675, 30.559284], [50.400669, 30.559401], [50.400652, 30.559669], [50.40063, 30.559976], [50.400608, 30.560176], [50.400588, 30.560363], [50.40055, 30.560601], [50.40049, 30.560991], [50.400436, 30.561238], [50.400383, 30.5615], [50.400344, 30.56167], [50.400272, 30.561949], [50.400231, 30.562094], [50.40017, 30.562296], [50.400084, 30.562579], [50.400033, 30.562741], [50.399977, 30.562903], [50.399837, 30.563294], [50.399453, 30.564229], [50.398306, 30.567231], [50.397152, 30.570278], [50.3961, 30.573059], [50.39601, 30.573333], [50.395924, 30.573614], [50.395789, 30.574148], [50.395702, 30.574551], [50.395614, 30.574957], [50.395544, 30.575424], [50.395502, 30.575848], [50.395461, 30.576331], [50.395278, 30.579566], [50.395227, 30.580369], [50.394908, 30.586643], [50.394831, 30.588126], [50.394678, 30.591192], [50.394676, 30.591242], [50.394511, 30.594614], [50.394442, 30.595976], [50.394421, 30.596399], [50.39437, 30.597456], [50.394346, 30.597957], [50.394316, 30.598845], [50.394284, 30.599576], [50.394264, 30.600075], [50.394251, 30.600316], [50.394211, 30.601192], [50.39413, 30.603731], [50.394131, 30.604173], [50.394142, 30.604638], [50.394153, 30.605114], [50.394159, 30.605263], [50.394174, 30.605643], [50.394192, 30.6061], [50.394197, 30.606235], [50.394203, 30.606353], [50.39425, 30.607103], [50.394289, 30.607571], [50.394356, 30.608308], [50.394487, 30.609475], [50.394526, 30.609785], [50.394557, 30.610023], [50.394607, 30.610364], [50.394801, 30.611558], [50.394839, 30.611788], [50.394908, 30.612218], [50.394973, 30.612625], [50.394991, 30.612738], [50.395019, 30.612922], [50.395321, 30.614878], [50.395465, 30.615828], [50.395726, 30.617483], [50.395698, 30.617649], [50.395669, 30.617767], [50.395616, 30.617867], [50.395561, 30.617954], [50.395508, 30.618011], [50.395441, 30.618056], [50.395375, 30.618072], [50.395307, 30.61808], [50.39523, 30.618071], [50.395158, 30.618044], [50.395082, 30.617983], [50.394639, 30.617503], [50.394571, 30.617421], [50.394509, 30.617315], [50.394474, 30.617223], [50.394459, 30.617112], [50.39447, 30.617007], [50.394503, 30.616905], [50.394556, 30.616805], [50.394653, 30.616681], [50.394808, 30.616632], [50.396133, 30.616151], [50.396522, 30.616023], [50.397204, 30.615842], [50.397531, 30.615776], [50.397873, 30.615712], [50.398323, 30.615676], [50.398586, 30.615656], [50.398634, 30.615652], [50.399986, 30.615555], [50.400035, 30.61555], [50.401202, 30.615448], [50.401376, 30.615431], [50.401558, 30.615413], [50.402619, 30.615293], [50.403099, 30.615201], [50.40334, 30.615131], [50.403521, 30.615068], [50.403771, 30.614969], [50.403854, 30.614931], [50.403921, 30.614894], [50.404183, 30.614748], [50.4044, 30.614597], [50.404767, 30.614284], [50.404878, 30.614166], [50.404929, 30.614344], [50.405236, 30.615498], [50.405386, 30.616086], [50.405411, 30.616182], [50.405434, 30.616271], [50.405584, 30.616857], [50.40561, 30.616958], [50.405625, 30.617018], [50.405658, 30.617147], [50.405702, 30.617316], [50.405919, 30.618161], [50.405938, 30.618238], [50.405984, 30.618418], [50.406191, 30.619226], [50.406238, 30.619406], [50.40655, 30.620703], [50.40661, 30.620936], [50.406669, 30.621167], [50.406751, 30.621483], [50.406811, 30.621715], [50.406874, 30.621958], [50.407187, 30.62317], [50.407508, 30.624414], [50.407513, 30.624433], [50.408298, 30.627475], [50.408311, 30.627524], [50.408355, 30.627702], [50.408727, 30.629091], [50.408759, 30.629217], [50.408797, 30.629305], [50.408803, 30.62932], [50.40888, 30.629635], [50.408944, 30.629877], [50.409774, 30.632989], [50.40989, 30.633449], [50.409922, 30.633575], [50.410288, 30.634977], [50.41049, 30.635778], [50.410657, 30.636467], [50.410818, 30.637176], [50.41102, 30.638], [50.411062, 30.638165], [50.411197, 30.638652], [50.411595, 30.640098], [50.412047, 30.641847], [50.412265, 30.642707], [50.412369, 30.64313], [50.412451, 30.643497], [50.412575, 30.643978], [50.412708, 30.644506], [50.412725, 30.644654], [50.412728, 30.644801], [50.412702, 30.645096], [50.412684, 30.645153], [50.412668, 30.645213], [50.412665, 30.645231], [50.412644, 30.645399], [50.412651, 30.64557], [50.412683, 30.645733], [50.41274, 30.645879], [50.412817, 30.646], [50.412911, 30.646087], [50.41302, 30.646138], [50.413134, 30.646144], [50.413251, 30.646101], [50.413357, 30.646012], [50.413381, 30.645982], [50.41344, 30.645887], [50.413486, 30.645778], [50.413505, 30.645716], [50.413584, 30.645589], [50.413651, 30.6455], [50.413727, 30.645414], [50.414019, 30.645232], [50.414912, 30.644687], [50.415099, 30.644567], [50.415155, 30.644532], [50.415505, 30.644327], [50.416022, 30.644016], [50.416236, 30.643888], [50.416832, 30.64352], [50.41711, 30.643345], [50.417802, 30.642957], [50.418537, 30.642533], [50.418656, 30.642464], [50.418991, 30.642254]], "routeDbId": 28, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0432\\u0443\\u043b\\u0438\\u0446\\u044f \\u041a\\u0430\\u0437\\u0438\\u043c\\u0438\\u0440\\u0430 \\u041c\\u0430\\u043b\\u0435\\u0432\\u0438\\u0447\\u0430, 83 ", "delivery_window_end": "17:00", "delivery_window_start": "16:00", "driveMin": 12, "eta": "16:12", "id": 254, "lat": 50.4205083, "lng": 30.5163539, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0412\\u0443\\u043b.\\u0420\\u0435\\u0432\\u0443\\u0446\\u044c\\u043a\\u043e\\u0433\\u043e, 9 ", "delivery_window_end": "17:00", "delivery_window_start": "16:00", "driveMin": 21, "eta": "16:48", "id": 246, "lat": 50.4190018, "lng": 30.642299, "serviceMin": 15, "stopOrder": 2, "waitMin": 0}], "totalDistanceKm": 20.29, "totalDriveMin": 33}]}	2026-04-25 11:16:05.247466	16:00:00
40	3	2026-04-26	sent	\N	5	25.34	48	340	2026-04-25 13:10:15.984536	\N	\N	2026-04-25 13:09:30.65864	2026-04-25 17:34:05.373308	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 6, "totalDeliveries": 15, "totalDistanceKm": 106.93, "totalDriveMin": 188}, "_selectedDate": "2026-04-26", "_fromDistribute": true, "routes": [{"courierId": "route_40", "courierName": "\\u0420\\u043e\\u043c\\u0430\\u043d (\\u0447\\u043e\\u043b\\u043e\\u0432\\u0456\\u043a \\u0406\\u0440\\u0438\\u043d\\u0438)", "departureAdjusted": false, "departureTime": "08:58", "geometry": [[50.473297, 30.482599], [50.47286, 30.48312], [50.472523, 30.483521], [50.471796, 30.484387], [50.471599, 30.484617], [50.4715, 30.484745], [50.471425, 30.484739], [50.471143, 30.48472], [50.470095, 30.484633], [50.470035, 30.48463], [50.469514, 30.484576], [50.46943, 30.484566], [50.46933, 30.484554], [50.469287, 30.484549], [50.468778, 30.484485], [50.46855, 30.484456], [50.467979, 30.484417], [50.46755, 30.484372], [50.466593, 30.484306], [50.46638, 30.4843], [50.465773, 30.484204], [50.465128, 30.484187], [50.465087, 30.484195], [50.465053, 30.485097], [50.465015, 30.486084], [50.465013, 30.486138], [50.464733, 30.486146], [50.464583, 30.486157], [50.464277, 30.486229], [50.463933, 30.486322], [50.463888, 30.486335], [50.463701, 30.486417], [50.463622, 30.486451], [50.463419, 30.486543], [50.462957, 30.486742], [50.462463, 30.486928], [50.462405, 30.486941], [50.462109, 30.486979], [50.462068, 30.486981], [50.461003, 30.486739], [50.460935, 30.486724], [50.46093, 30.48667], [50.460916, 30.486612], [50.460894, 30.486551], [50.460585, 30.48576], [50.46039, 30.485273], [50.460294, 30.485034], [50.460268, 30.484984], [50.460224, 30.484934], [50.460201, 30.484908], [50.460192, 30.484918], [50.46011, 30.485007], [50.459865, 30.485272], [50.459674, 30.48547], [50.459117, 30.486047], [50.459081, 30.486086], [50.458822, 30.486347], [50.458756, 30.486409], [50.458568, 30.486342], [50.457946, 30.486118], [50.457929, 30.486111], [50.457911, 30.486105], [50.457465, 30.48595], [50.457313, 30.485897], [50.456786, 30.485693], [50.454439, 30.484761], [50.454347, 30.484725], [50.454277, 30.484697], [50.454239, 30.484682], [50.454153, 30.484651], [50.453957, 30.484575], [50.453036, 30.484221], [50.452804, 30.484126], [50.452455, 30.483985], [50.451795, 30.483717], [50.451643, 30.483655], [50.450883, 30.483337], [50.450633, 30.483231], [50.449986, 30.482956], [50.449852, 30.482898], [50.449434, 30.482717], [50.449038, 30.482552], [50.448858, 30.482487], [50.44875, 30.482441], [50.448657, 30.482402], [50.448295, 30.48225], [50.448175, 30.4822], [50.448053, 30.482149], [50.447672, 30.482006], [50.447493, 30.481943], [50.447195, 30.481836], [50.447104, 30.481803], [50.447045, 30.481783], [50.447003, 30.481768], [50.446983, 30.481761], [50.446876, 30.481723], [50.446836, 30.481709], [50.446761, 30.481683], [50.446426, 30.481559], [50.445933, 30.481351], [50.445209, 30.481036], [50.444935, 30.480926], [50.444218, 30.480635], [50.444136, 30.480605], [50.444052, 30.480579], [50.44388, 30.480537], [50.443743, 30.480504], [50.443668, 30.480489], [50.443439, 30.480445], [50.443221, 30.480386], [50.442996, 30.480312], [50.441991, 30.479925], [50.441964, 30.480084], [50.441828, 30.4808], [50.441747, 30.481229], [50.441729, 30.481324], [50.441701, 30.481445], [50.441671, 30.481579], [50.44164, 30.481716], [50.441525, 30.482089], [50.441401, 30.482407], [50.441302, 30.482605], [50.441171, 30.482837], [50.440832, 30.483316], [50.440746, 30.483439], [50.440504, 30.483793], [50.440413, 30.483871], [50.440301, 30.483944], [50.440194, 30.483991], [50.440041, 30.484035], [50.439898, 30.484062], [50.439661, 30.484093], [50.439592, 30.484106], [50.43948, 30.484134], [50.439387, 30.484176], [50.439281, 30.484266], [50.439213, 30.484334], [50.439141, 30.484419], [50.438777, 30.484899], [50.438682, 30.485023], [50.438274, 30.48557], [50.438089, 30.485817], [50.437692, 30.486337], [50.437559, 30.486518], [50.437495, 30.486621], [50.437464, 30.486699], [50.437342, 30.487067], [50.437264, 30.487256], [50.437157, 30.487468], [50.436922, 30.487838], [50.436891, 30.487778], [50.436699, 30.487385], [50.436503, 30.487022], [50.436301, 30.486613], [50.436162, 30.486338], [50.435996, 30.486023], [50.435713, 30.485502], [50.435667, 30.485418], [50.43545, 30.485018], [50.435268, 30.484678], [50.434623, 30.483417], [50.434568, 30.4833], [50.434182, 30.48342], [50.434106, 30.483447], [50.43359, 30.48366], [50.433549, 30.483678], [50.433419, 30.483743], [50.433532, 30.484037], [50.43368, 30.484368], [50.433899, 30.484839], [50.433771, 30.484803], [50.433725, 30.484799], [50.432671, 30.484723], [50.43261, 30.484622], [50.432538, 30.484811], [50.432537, 30.485112], [50.432566, 30.485262], [50.432615, 30.485322], [50.432664, 30.485338], [50.433032, 30.485352], [50.433554, 30.485352], [50.433131, 30.485352], [50.433032, 30.485352], [50.432664, 30.485338], [50.432615, 30.485322], [50.432566, 30.485262], [50.432537, 30.485112], [50.432538, 30.484811], [50.43261, 30.484622], [50.432671, 30.484723], [50.433725, 30.484799], [50.433771, 30.484803], [50.433899, 30.484839], [50.434531, 30.486072], [50.434546, 30.4861], [50.434813, 30.486613], [50.434853, 30.486686], [50.435239, 30.487432], [50.435388, 30.487714], [50.435949, 30.488768], [50.436076, 30.489014], [50.435985, 30.48913], [50.43597, 30.489146], [50.435816, 30.489325], [50.43545, 30.489749], [50.435418, 30.489787], [50.435046, 30.490241], [50.434912, 30.490242], [50.43489, 30.490247], [50.434664, 30.490297], [50.434646, 30.490299], [50.434511, 30.490286], [50.434398, 30.490259], [50.434288, 30.490197], [50.434182, 30.49013], [50.434031, 30.490036], [50.433967, 30.48996], [50.43372, 30.489663], [50.433507, 30.489388], [50.433453, 30.48932], [50.433397, 30.489246], [50.433132, 30.488922], [50.432991, 30.48877], [50.432786, 30.488588], [50.432558, 30.488486], [50.432342, 30.488394], [50.43225, 30.488364], [50.43212, 30.488313], [50.43198, 30.48826], [50.431753, 30.488165], [50.431278, 30.487982], [50.431241, 30.487965], [50.431217, 30.487956], [50.431062, 30.487895], [50.431029, 30.487888], [50.430738, 30.487833], [50.430321, 30.487748], [50.430062, 30.487696], [50.429778, 30.487634], [50.429679, 30.487612], [50.429597, 30.487587], [50.429571, 30.487579], [50.429523, 30.487555], [50.429492, 30.487533], [50.429496, 30.487519], [50.429497, 30.487476], [50.42949, 30.487434], [50.429475, 30.487397], [50.429453, 30.48737], [50.429427, 30.487354], [50.4294, 30.487352], [50.429387, 30.487246], [50.429378, 30.487066], [50.429388, 30.486969], [50.429404, 30.486814], [50.429414, 30.486713], [50.429461, 30.486261], [50.429532, 30.485492], [50.429552, 30.484924], [50.429511, 30.484605], [50.429444, 30.484142], [50.42943, 30.484062], [50.429413, 30.483975], [50.42926, 30.483223], [50.42923, 30.483091], [50.429151, 30.482702], [50.429006, 30.481978], [50.428963, 30.481764], [50.428944, 30.481674], [50.428893, 30.48142], [50.428854, 30.481232], [50.428806, 30.481009], [50.428732, 30.480661], [50.428496, 30.479544], [50.428469, 30.47942], [50.428459, 30.47937], [50.428348, 30.478868], [50.428247, 30.47841], [50.428221, 30.478291], [50.428176, 30.478097], [50.428122, 30.477867], [50.428004, 30.477364], [50.427769, 30.476667], [50.42769, 30.476445], [50.427623, 30.476262], [50.427506, 30.47597], [50.427449, 30.475833], [50.427384, 30.475874], [50.427129, 30.476033], [50.427091, 30.476056], [50.426836, 30.476215], [50.426319, 30.476546], [50.42618, 30.476629], [50.425991, 30.476743], [50.425721, 30.476917], [50.425354, 30.477155], [50.425305, 30.477186], [50.425245, 30.477226], [50.424988, 30.477394], [50.424759, 30.477612], [50.424597, 30.477808], [50.424535, 30.477882], [50.424344, 30.478181], [50.424272, 30.478322], [50.424134, 30.478608], [50.42366, 30.479673], [50.423299, 30.480511], [50.42322, 30.480692], [50.423047, 30.481087], [50.423007, 30.481047], [50.422997, 30.481037], [50.422655, 30.480662], [50.422536, 30.480535], [50.422506, 30.480504], [50.421974, 30.479938], [50.421638, 30.479582], [50.421559, 30.479497], [50.421212, 30.479128], [50.420851, 30.478745], [50.420658, 30.47854], [50.420614, 30.478493], [50.420577, 30.478535], [50.420526, 30.478588], [50.420385, 30.478734], [50.420341, 30.478779], [50.420313, 30.478809], [50.420265, 30.478861], [50.420228, 30.478901], [50.420153, 30.478982], [50.420083, 30.479058], [50.420049, 30.479096], [50.419858, 30.479316], [50.419733, 30.479611], [50.419527, 30.480098], [50.419443, 30.480296], [50.419412, 30.480376], [50.419382, 30.480452], [50.419353, 30.48042], [50.419186, 30.480237], [50.419122, 30.480167], [50.418664, 30.479679], [50.41861, 30.479619], [50.4183, 30.479301], [50.417985, 30.478978], [50.417844, 30.478834], [50.417592, 30.478576], [50.417545, 30.478528], [50.417529, 30.47849], [50.417503, 30.478411], [50.417477, 30.478362], [50.417431, 30.478313], [50.417375, 30.478276], [50.417284, 30.478245], [50.416602, 30.478666], [50.415996, 30.479062], [50.415293, 30.479554], [50.415009, 30.479747], [50.414831, 30.479889], [50.414756, 30.479953], [50.414594, 30.480105], [50.414365, 30.480319], [50.414223, 30.480456], [50.413905, 30.480909], [50.413806, 30.48105], [50.413642, 30.481299], [50.412629, 30.483351], [50.412482, 30.483644], [50.412355, 30.483897], [50.412095, 30.484419], [50.411773, 30.485085], [50.411595, 30.485451], [50.411356, 30.485928], [50.411242, 30.486174], [50.410545, 30.487569], [50.410056, 30.488537], [50.409536, 30.489601], [50.408881, 30.490953], [50.408857, 30.490854], [50.408835, 30.490754], [50.407887, 30.486355], [50.407819, 30.48604], [50.407794, 30.485787], [50.407761, 30.485298], [50.40775, 30.485204], [50.407643, 30.485132], [50.407627, 30.485127], [50.407525, 30.485097], [50.407432, 30.485106], [50.407104, 30.485194], [50.406866, 30.485325], [50.406521, 30.485537], [50.406431, 30.485567], [50.406045, 30.485459], [50.40567, 30.485363], [50.405604, 30.485369], [50.405398, 30.485436], [50.405068, 30.485587], [50.405004, 30.485642], [50.40464, 30.48496], [50.404345, 30.48445], [50.40406, 30.483904], [50.403979, 30.483737], [50.403466, 30.482703], [50.403291, 30.482344], [50.403273, 30.482308], [50.40301, 30.481767], [50.402308, 30.480251], [50.40212, 30.479843], [50.401719, 30.480421], [50.401472, 30.480956], [50.401424, 30.481114], [50.401406, 30.48125], [50.401393, 30.481525], [50.401363, 30.48176], [50.401357, 30.48178], [50.401314, 30.481937], [50.401198, 30.482189], [50.400966, 30.482554], [50.400679, 30.482944], [50.400575, 30.483113], [50.400471, 30.483289], [50.400389, 30.483495], [50.400321, 30.48371], [50.400232, 30.484045], [50.399982, 30.485034], [50.399689, 30.486198], [50.399672, 30.486306], [50.399698, 30.486473], [50.399737, 30.486644], [50.399672, 30.486869], [50.399609, 30.48705], [50.3995, 30.487341], [50.399367, 30.487633], [50.399224, 30.487814], [50.399067, 30.487972], [50.398721, 30.488266], [50.397621, 30.489083], [50.397583, 30.489103], [50.397397, 30.4892], [50.396325, 30.489568], [50.396167, 30.489621], [50.396071, 30.489657], [50.396087, 30.489755], [50.396164, 30.490244], [50.396254, 30.49079], [50.396346, 30.491355], [50.396372, 30.491512], [50.39646, 30.492026], [50.396476, 30.492131], [50.396412, 30.492158], [50.394762, 30.492849], [50.394208, 30.493089], [50.394108, 30.493133], [50.394119, 30.493225], [50.394163, 30.493495], [50.394189, 30.493646], [50.394237, 30.493955], [50.394256, 30.494069], [50.394325, 30.494501], [50.394453, 30.495287], [50.394487, 30.495495], [50.394568, 30.496005], [50.394573, 30.496048], [50.394584, 30.496107], [50.394686, 30.496719], [50.39478, 30.49729], [50.394802, 30.497412], [50.39484, 30.497635], [50.395006, 30.498596], [50.39513, 30.499286], [50.395152, 30.499411], [50.395175, 30.499539], [50.39537, 30.500627], [50.395441, 30.50104], [50.395502, 30.501299], [50.395714, 30.502157], [50.396268, 30.504262], [50.396298, 30.504385], [50.396477, 30.505085], [50.396565, 30.505434], [50.396662, 30.505802], [50.396698, 30.505928], [50.396726, 30.506028], [50.396857, 30.506485], [50.397352, 30.508098], [50.397438, 30.508395], [50.397522, 30.508701], [50.397543, 30.508895], [50.397566, 30.509032], [50.397583, 30.509154], [50.397583, 30.509268], [50.397527, 30.50947], [50.397373, 30.510015], [50.39732, 30.510202], [50.397284, 30.51033], [50.397269, 30.510423], [50.397264, 30.510507], [50.39727, 30.510592], [50.397281, 30.510653], [50.39729, 30.510677], [50.397312, 30.510732], [50.397449, 30.511026], [50.39777, 30.511717], [50.397868, 30.511939], [50.397981, 30.512238], [50.398068, 30.512501], [50.398113, 30.512671], [50.398147, 30.512796], [50.398267, 30.513264], [50.398445, 30.513964], [50.398495, 30.514158], [50.398577, 30.514483], [50.39884, 30.515512], [50.39886, 30.5156], [50.398803, 30.515635], [50.39864, 30.515734], [50.398414, 30.515879], [50.39824, 30.515978], [50.398165, 30.516021], [50.397963, 30.516147], [50.397802, 30.516241], [50.397677, 30.516324], [50.397506, 30.51644], [50.397395, 30.516523], [50.397293, 30.516606], [50.397222, 30.51667], [50.397122, 30.516772], [50.397031, 30.516887], [50.396971, 30.516955], [50.396775, 30.51717], [50.39629, 30.517728], [50.395675, 30.518363], [50.395131, 30.51895], [50.394998, 30.519116], [50.39483, 30.519409], [50.394727, 30.519608], [50.394499, 30.520026], [50.39438, 30.520215], [50.393708, 30.521284], [50.393323, 30.521897], [50.393103, 30.522251], [50.393012, 30.522402], [50.392766, 30.522813], [50.392736, 30.522862], [50.392624, 30.523031], [50.391891, 30.524153], [50.391836, 30.524241], [50.390857, 30.525868], [50.390324, 30.526704], [50.390267, 30.526791], [50.390212, 30.526878], [50.390151, 30.526978], [50.389984, 30.527122], [50.390087, 30.527754], [50.39011, 30.527898], [50.390151, 30.528146], [50.390203, 30.528469], [50.390308, 30.529113], [50.390331, 30.529261], [50.390358, 30.529458], [50.390245, 30.529423], [50.390216, 30.529418], [50.390079, 30.529399], [50.389952, 30.5294], [50.389827, 30.529399], [50.389608, 30.529463], [50.388837, 30.529741], [50.387979, 30.530065], [50.387731, 30.530152], [50.387067, 30.530387], [50.386821, 30.530474], [50.386741, 30.530503], [50.385886, 30.530806], [50.385726, 30.53087], [50.385675, 30.530893], [50.38523, 30.531106], [50.384515, 30.531447], [50.384396, 30.531503], [50.38384, 30.531766], [50.383663, 30.531826], [50.383489, 30.53193], [50.382326, 30.53247], [50.382295, 30.532484], [50.382185, 30.532536], [50.381994, 30.532629], [50.381752, 30.532776], [50.381669, 30.532824], [50.381418, 30.532977], [50.381224, 30.533103], [50.381157, 30.533151], [50.381018, 30.533249], [50.380493, 30.533622], [50.380427, 30.533451], [50.380304, 30.532997], [50.38048, 30.53287], [50.38097, 30.532515], [50.381032, 30.532371], [50.381326, 30.532186], [50.381374, 30.532088], [50.38136, 30.531869], [50.38155, 30.531771], [50.381591, 30.531976], [50.381707, 30.532582], [50.381752, 30.532776], [50.381669, 30.532824], [50.381418, 30.532977], [50.381492, 30.533095], [50.38151, 30.533125], [50.381598, 30.533244], [50.381664, 30.533337], [50.381797, 30.533269], [50.381933, 30.532846], [50.381994, 30.532629], [50.382185, 30.532536], [50.382295, 30.532484], [50.382326, 30.53247], [50.383489, 30.53193], [50.383663, 30.531826], [50.38384, 30.531766], [50.384396, 30.531503], [50.384515, 30.531447], [50.38523, 30.531106], [50.385675, 30.530893], [50.385726, 30.53087], [50.385886, 30.530806], [50.386741, 30.530503], [50.386821, 30.530474], [50.387067, 30.530387], [50.387731, 30.530152], [50.387979, 30.530065], [50.388837, 30.529741], [50.389608, 30.529463], [50.389827, 30.529399], [50.389952, 30.5294], [50.390079, 30.529399], [50.390216, 30.529418], [50.390245, 30.529423], [50.390358, 30.529458], [50.390449, 30.529499], [50.39063, 30.52959], [50.390963, 30.529773], [50.391344, 30.529981], [50.391657, 30.530145], [50.391881, 30.530263], [50.392621, 30.53065], [50.392813, 30.53075], [50.392925, 30.530809], [50.393178, 30.530942], [50.393367, 30.53104], [50.393499, 30.531092], [50.393623, 30.531135], [50.393778, 30.531191], [50.393909, 30.531229], [50.394119, 30.53129], [50.39425, 30.531325], [50.394349, 30.531352], [50.394528, 30.531395], [50.394701, 30.531427], [50.39481, 30.531445], [50.394983, 30.531468], [50.395129, 30.531477], [50.39525, 30.531477], [50.395415, 30.531481], [50.395564, 30.531484], [50.395725, 30.531482], [50.395965, 30.531461], [50.396194, 30.531433], [50.396313, 30.531412], [50.396664, 30.531328], [50.396987, 30.53122], [50.397201, 30.53113], [50.397417, 30.531038], [50.397727, 30.530876], [50.397888, 30.530791], [50.397986, 30.530733], [50.398107, 30.530659], [50.398301, 30.530534], [50.398546, 30.530359], [50.398678, 30.530246], [50.399261, 30.529756], [50.399479, 30.529564], [50.399593, 30.529464], [50.399657, 30.529407], [50.399807, 30.529279], [50.399949, 30.52916], [50.399998, 30.529117], [50.400133, 30.528996], [50.400241, 30.528899], [50.400815, 30.528406], [50.401007, 30.52824], [50.40166, 30.527669], [50.402067, 30.52731], [50.402282, 30.52717], [50.402913, 30.526404], [50.403173, 30.526067], [50.403227, 30.525985], [50.403579, 30.525508], [50.403868, 30.525163], [50.404084, 30.524905], [50.404236, 30.524716], [50.404318, 30.524618], [50.4044, 30.524528], [50.404546, 30.524307], [50.404626, 30.524132], [50.404784, 30.523792], [50.405088, 30.523279], [50.40551, 30.522627], [50.405719, 30.522246], [50.405911, 30.521989], [50.406164, 30.521652], [50.406358, 30.521386], [50.406488, 30.521182], [50.406617, 30.520969], [50.406725, 30.520906], [50.406837, 30.520783], [50.406948, 30.520663], [50.407013, 30.520606], [50.407082, 30.52057], [50.407203, 30.520542], [50.407301, 30.520542], [50.407411, 30.520584], [50.407542, 30.520676], [50.407664, 30.520808], [50.40786, 30.521161], [50.407982, 30.521385], [50.408122, 30.521645], [50.408362, 30.522043], [50.408511, 30.522252], [50.408668, 30.52239], [50.408753, 30.522568], [50.409231, 30.523514], [50.40943, 30.523944], [50.409665, 30.524455], [50.410327, 30.525819], [50.410479, 30.526153], [50.410637, 30.526515], [50.410737, 30.52673], [50.410841, 30.526973], [50.411031, 30.527412], [50.411297, 30.528113], [50.411509, 30.528673], [50.41164, 30.529033], [50.411832, 30.529578], [50.412028, 30.530157], [50.412171, 30.530577], [50.412274, 30.530882], [50.412378, 30.531207], [50.412654, 30.532136], [50.412843, 30.532749], [50.413035, 30.533409], [50.413347, 30.534439], [50.413649, 30.53535], [50.413967, 30.536259], [50.414281, 30.537068], [50.414465, 30.537517], [50.414603, 30.537837], [50.414651, 30.537952], [50.414867, 30.538471], [50.41527, 30.539331], [50.415144, 30.539482], [50.415052, 30.5396], [50.415032, 30.539625], [50.414948, 30.539734], [50.414894, 30.539806], [50.414861, 30.53985], [50.414788, 30.539948], [50.414679, 30.54009], [50.41466, 30.540052], [50.414638, 30.540005], [50.414631, 30.539991], [50.414526, 30.539742], [50.414413, 30.5397], [50.414042, 30.539578], [50.413982, 30.539635], [50.413956, 30.539877], [50.413928, 30.539952], [50.413632, 30.5399], [50.413632, 30.5399], [50.413928, 30.539952], [50.413956, 30.539877], [50.413982, 30.539635], [50.414042, 30.539578], [50.414413, 30.5397], [50.414526, 30.539742], [50.414631, 30.539991], [50.414638, 30.540005], [50.41466, 30.540052], [50.414679, 30.54009], [50.414788, 30.539948], [50.414861, 30.53985], [50.414894, 30.539806], [50.414948, 30.539734], [50.415032, 30.539625], [50.415052, 30.5396], [50.415144, 30.539482], [50.41527, 30.539331], [50.415577, 30.539971], [50.416472, 30.541775], [50.416805, 30.542422], [50.416707, 30.542545], [50.416534, 30.542763], [50.416023, 30.54343], [50.41595, 30.543526], [50.415902, 30.543588], [50.415811, 30.543713], [50.415721, 30.543839], [50.415602, 30.544027], [50.415578, 30.544066], [50.415577, 30.544136], [50.415579, 30.544335], [50.415582, 30.544892], [50.415582, 30.545043], [50.415584, 30.545486], [50.415585, 30.545792], [50.415585, 30.545824], [50.415585, 30.545869], [50.415586, 30.546033], [50.415587, 30.546342], [50.415509, 30.546344], [50.414893, 30.54633], [50.414664, 30.546317], [50.414147, 30.546304], [50.414065, 30.546302], [50.413958, 30.546298], [50.413247, 30.546282], [50.413127, 30.54628], [50.412988, 30.546273], [50.412344, 30.546245], [50.412246, 30.546241], [50.412124, 30.546236], [50.411744, 30.546223], [50.411674, 30.546198], [50.411615, 30.546187], [50.411506, 30.546186], [50.411469, 30.546179], [50.41146, 30.546177], [50.41142, 30.546161], [50.411398, 30.546144], [50.411373, 30.54614], [50.411346, 30.546152], [50.411324, 30.546181], [50.411289, 30.546197], [50.411261, 30.546203], [50.411231, 30.546205], [50.411181, 30.546203], [50.410963, 30.546195], [50.410903, 30.546231], [50.410866, 30.54623], [50.410731, 30.546227], [50.410592, 30.546182], [50.410443, 30.546118], [50.410192, 30.54599], [50.410014, 30.545889], [50.409878, 30.545813], [50.409849, 30.545796], [50.409822, 30.545867], [50.4098, 30.54592], [50.409697, 30.546224], [50.409596, 30.546533], [50.409579, 30.546582], [50.40955, 30.546629], [50.409537, 30.546638], [50.409526, 30.546652], [50.409518, 30.54667], [50.409513, 30.54669], [50.409511, 30.546711], [50.409512, 30.546733], [50.409516, 30.546753], [50.409497, 30.546841], [50.409489, 30.54687], [50.409479, 30.546904], [50.409454, 30.546993], [50.409404, 30.547167], [50.409397, 30.547256], [50.409325, 30.547483], [50.409228, 30.5478], [50.409131, 30.548111], [50.409109, 30.548182], [50.409101, 30.548208], [50.40906, 30.548291], [50.409039, 30.548357], [50.409024, 30.548446], [50.40901, 30.548459], [50.408991, 30.548494], [50.408408, 30.548475], [50.40837, 30.548456], [50.408341, 30.548393], [50.407906, 30.547122], [50.407175, 30.544813], [50.406974, 30.544178], [50.406933, 30.544048]], "routeDbId": 40, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0432\\u0443\\u043b. \\u041c\\u0438\\u0442\\u0440\\u043e\\u043f\\u043e\\u043b\\u0438\\u0442\\u0430 \\u0412\\u0430\\u0441\\u0438\\u043b\\u044f \\u041b\\u0438\\u043f\\u043a\\u0456\\u0432\\u0441\\u044c\\u043a\\u043e\\u0433\\u043e 15 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 10, "eta": "09:08", "id": 131, "lat": 50.43313149999999, "lng": 30.4850765, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u044f\\u0431\\u043b\\u0443\\u043d\\u0435\\u0432\\u0430 15/55 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 11, "eta": "09:34", "id": 118, "lat": 50.40322519999999, "lng": 30.4823662, "serviceMin": 15, "stopOrder": 2, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u043f\\u0440-\\u0442 \\u041d\\u0430\\u0443\\u043a\\u0438 60\\u0430 ", "delivery_window_end": "13:00", "delivery_window_start": "10:00", "driveMin": 11, "eta": "10:00", "id": 26, "lat": 50.3805422, "lng": 30.533082, "serviceMin": 15, "stopOrder": 3, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0431\\u0443\\u043b\\u044c\\u0432\\u0430\\u0440 \\u041c\\u0438\\u043a\\u043e\\u043b\\u0438 \\u041c\\u0456\\u0445\\u043d\\u043e\\u0432\\u0441\\u044c\\u043a\\u043e\\u0433\\u043e, 14-16 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 10, "eta": "10:25", "id": 247, "lat": 50.4135419, "lng": 30.5397524, "serviceMin": 15, "stopOrder": 4, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0410\\u043d\\u0434\\u0440\\u0456\\u044f \\u0412\\u0435\\u0440\\u0445\\u043e\\u0433\\u043b\\u044f\\u0434\\u0430, 19\\u0431 ", "delivery_window_end": "13:00", "delivery_window_start": "10:00", "driveMin": 6, "eta": "10:46", "id": 194, "lat": 50.4071478, "lng": 30.5438808, "serviceMin": 15, "stopOrder": 5, "waitMin": 0}], "totalDistanceKm": 25.34, "totalDriveMin": 48}]}	2026-04-25 17:34:05.372524	08:58:00
19	8	2026-04-25	completed	\N	3	11.7	21	\N	\N	\N	\N	2026-04-24 17:02:56.392587	2026-04-25 11:16:05.259186	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 10, "totalDeliveries": 29, "totalDistanceKm": 178.72, "totalDriveMin": 301}, "_selectedDate": "2026-04-25", "_fromDistribute": true, "routes": [{"courierId": "route_19", "courierName": "\\u0412\\u0456\\u0442\\u0430\\u043b\\u0456\\u0439", "departureAdjusted": false, "departureTime": "10:00", "geometry": [[50.473297, 30.482599], [50.473502, 30.482355], [50.47347, 30.482288], [50.473047, 30.481403], [50.473463, 30.480252], [50.473597, 30.47993], [50.473735, 30.479606], [50.473899, 30.479227], [50.473984, 30.479031], [50.474299, 30.478379], [50.474456, 30.478042], [50.474477, 30.477997], [50.474267, 30.477757], [50.473786, 30.477209], [50.473675, 30.477083], [50.473602, 30.477], [50.473547, 30.476932], [50.473399, 30.476768], [50.472755, 30.476038], [50.472703, 30.475972], [50.472265, 30.475462], [50.472156, 30.475336], [50.471636, 30.474724], [50.471449, 30.474504], [50.471231, 30.474262], [50.471075, 30.474089], [50.470961, 30.473956], [50.470842, 30.473819], [50.47039, 30.473305], [50.470282, 30.473193], [50.470158, 30.473064], [50.469777, 30.472613], [50.469619, 30.472426], [50.469568, 30.472361], [50.469594, 30.472301], [50.469611, 30.472271], [50.469885, 30.471668], [50.469977, 30.471463], [50.470353, 30.470682], [50.470506, 30.470362], [50.47054, 30.470286], [50.470807, 30.469735], [50.470763, 30.469686], [50.47071, 30.469621], [50.470181, 30.468958], [50.469482, 30.468144], [50.469468, 30.46812], [50.469439, 30.468058], [50.469471, 30.467986], [50.469745, 30.467381], [50.469962, 30.466901], [50.470506, 30.465757], [50.470489, 30.465588], [50.470486, 30.465506], [50.470484, 30.46544], [50.470464, 30.464851], [50.470416, 30.463784], [50.470407, 30.463603], [50.470404, 30.463411], [50.470395, 30.46311], [50.470392, 30.462936], [50.470386, 30.462609], [50.470386, 30.462512], [50.470382, 30.462394], [50.470377, 30.462162], [50.470371, 30.46197], [50.470369, 30.461923], [50.470343, 30.461305], [50.470321, 30.46088], [50.470297, 30.460538], [50.470184, 30.459577], [50.470091, 30.458928], [50.469943, 30.457854], [50.469922, 30.457725], [50.469843, 30.45716], [50.469797, 30.456683], [50.469766, 30.456111], [50.469776, 30.455598], [50.469806, 30.454375], [50.469807, 30.454195], [50.469811, 30.454047], [50.469844, 30.452675], [50.469849, 30.452398], [50.469893, 30.450595], [50.469902, 30.45032], [50.469946, 30.449703], [50.470003, 30.448983], [50.47006, 30.448212], [50.470112, 30.447669], [50.470147, 30.447008], [50.470152, 30.446909], [50.470156, 30.446803], [50.470162, 30.446641], [50.470166, 30.44651], [50.470169, 30.446407], [50.470186, 30.445852], [50.470192, 30.44571], [50.4702, 30.445516], [50.470221, 30.44503], [50.470236, 30.444718], [50.470239, 30.44462], [50.470269, 30.443875], [50.470267, 30.443683], [50.470272, 30.443492], [50.470285, 30.443365], [50.470312, 30.443179], [50.470358, 30.442941], [50.470416, 30.442742], [50.470502, 30.442482], [50.470604, 30.442201], [50.470735, 30.441901], [50.470955, 30.44151], [50.471022, 30.441402], [50.47126, 30.441104], [50.471284, 30.441081], [50.471327, 30.441032], [50.471408, 30.440941], [50.471523, 30.440819], [50.471757, 30.440548], [50.471941, 30.44031], [50.472121, 30.440032], [50.472384, 30.439549], [50.472449, 30.439345], [50.472552, 30.439052], [50.472841, 30.438193], [50.472964, 30.437769], [50.473139, 30.436927], [50.473205, 30.436637], [50.473285, 30.436377], [50.473308, 30.436219], [50.473227, 30.436153], [50.472811, 30.435938], [50.472694, 30.435738], [50.472654, 30.435573], [50.472639, 30.435373], [50.472717, 30.434899], [50.472839, 30.434414], [50.472717, 30.434899], [50.472639, 30.435373], [50.472654, 30.435573], [50.472694, 30.435738], [50.472798, 30.435915], [50.472811, 30.435938], [50.473227, 30.436153], [50.473308, 30.436219], [50.473285, 30.436377], [50.473205, 30.436637], [50.473139, 30.436927], [50.472964, 30.437769], [50.472841, 30.438193], [50.472552, 30.439052], [50.472449, 30.439345], [50.472384, 30.439549], [50.472121, 30.440032], [50.471941, 30.44031], [50.471757, 30.440548], [50.471523, 30.440819], [50.471408, 30.440941], [50.471327, 30.441032], [50.471284, 30.441081], [50.47126, 30.441104], [50.471022, 30.441402], [50.470955, 30.44151], [50.470735, 30.441901], [50.470604, 30.442201], [50.470502, 30.442482], [50.470416, 30.442742], [50.470358, 30.442941], [50.470312, 30.443179], [50.470285, 30.443365], [50.470272, 30.443492], [50.470267, 30.443683], [50.47017, 30.443639], [50.470093, 30.443597], [50.469905, 30.443462], [50.469279, 30.443028], [50.468885, 30.442756], [50.46835, 30.44239], [50.468283, 30.442339], [50.46723, 30.441614], [50.467181, 30.44158], [50.467142, 30.441553], [50.467, 30.441455], [50.465887, 30.440684], [50.46515, 30.440161], [50.465073, 30.440109], [50.465018, 30.440069], [50.464921, 30.440003], [50.464784, 30.439909], [50.464457, 30.439678], [50.464335, 30.439567], [50.464228, 30.439444], [50.464107, 30.439274], [50.463974, 30.439021], [50.463972, 30.439019], [50.463861, 30.438728], [50.463801, 30.438527], [50.463738, 30.438332], [50.463536, 30.437632], [50.4635, 30.437545], [50.463347, 30.437066], [50.463255, 30.436772], [50.463118, 30.436323], [50.463095, 30.436255], [50.463041, 30.436093], [50.462909, 30.435666], [50.462722, 30.435069], [50.462497, 30.434345], [50.462149, 30.433207], [50.462124, 30.433126], [50.462087, 30.432967], [50.462222, 30.433014], [50.462816, 30.433035], [50.463154, 30.433046], [50.463537, 30.43306], [50.463624, 30.433042], [50.463691, 30.433006], [50.463746, 30.432957], [50.463813, 30.432889], [50.463879, 30.432778], [50.463928, 30.432648], [50.464527, 30.430755], [50.464559, 30.430647], [50.464586, 30.430519], [50.46461, 30.430395], [50.464644, 30.430216], [50.464675, 30.429992], [50.464732, 30.429985], [50.464804, 30.42999], [50.464904, 30.430007], [50.465286, 30.430091], [50.465828, 30.430181], [50.466362, 30.430314], [50.466585, 30.430369], [50.466623, 30.430369], [50.46665, 30.430361], [50.466677, 30.430288], [50.466769, 30.429479], [50.466772, 30.429381], [50.466767, 30.429318], [50.466715, 30.429258], [50.466464, 30.429169], [50.466136, 30.429052], [50.465867, 30.428956], [50.465804, 30.428956], [50.46575, 30.428977], [50.465696, 30.429037], [50.46545, 30.429416], [50.465338, 30.429542], [50.464904, 30.430007], [50.464804, 30.42999], [50.464732, 30.429985], [50.464675, 30.429992], [50.464644, 30.430216], [50.46461, 30.430395], [50.464586, 30.430519], [50.464559, 30.430647], [50.464527, 30.430755], [50.463928, 30.432648], [50.463879, 30.432778], [50.463813, 30.432889], [50.463746, 30.432957], [50.463691, 30.433006], [50.463624, 30.433042], [50.463537, 30.43306], [50.463154, 30.433046], [50.462816, 30.433035], [50.462222, 30.433014], [50.462087, 30.432967], [50.462037, 30.432733], [50.461778, 30.431716], [50.461746, 30.431598], [50.461504, 30.430719], [50.461367, 30.430245], [50.461274, 30.429936], [50.46111, 30.429362], [50.461052, 30.429164], [50.461014, 30.429034], [50.460912, 30.428682], [50.46052, 30.427309], [50.460398, 30.42689], [50.460324, 30.426638], [50.460254, 30.426394], [50.460187, 30.426198], [50.460135, 30.42608], [50.459963, 30.425679], [50.459925, 30.425554], [50.459831, 30.425243], [50.459342, 30.423568], [50.459258, 30.423243], [50.45906, 30.422548], [50.459031, 30.42243], [50.459018, 30.422324], [50.459009, 30.422247], [50.458981, 30.421911], [50.458937, 30.421239], [50.458916, 30.420795], [50.458906, 30.420133], [50.458908, 30.419845], [50.458918, 30.419539], [50.459023, 30.418893], [50.459216, 30.41792], [50.459484, 30.416738], [50.459552, 30.416288], [50.459593, 30.415379], [50.459583, 30.414995], [50.459521, 30.414286], [50.459407, 30.413361], [50.459257, 30.412352], [50.459192, 30.411842], [50.459098, 30.411213], [50.459016, 30.410669], [50.458933, 30.409817], [50.458414, 30.401572], [50.458362, 30.400552], [50.458311, 30.399544], [50.458255, 30.398732], [50.458073, 30.396072], [50.457873, 30.393073], [50.457854, 30.39279], [50.457829, 30.392415], [50.457823, 30.392322], [50.457615, 30.389333], [50.457441, 30.386729], [50.457404, 30.386194], [50.457435, 30.386088], [50.457486, 30.385992], [50.457518, 30.385959], [50.457545, 30.385942], [50.457603, 30.385939], [50.457651, 30.385959], [50.457709, 30.386011], [50.457757, 30.386086], [50.457793, 30.386214], [50.457835, 30.386704], [50.457828, 30.386831], [50.457796, 30.386952], [50.457736, 30.38706], [50.45765, 30.387109], [50.457104, 30.386943], [50.456852, 30.386868], [50.456529, 30.386781], [50.456458, 30.386779], [50.456385, 30.386802], [50.456316, 30.386854], [50.456185, 30.387012], [50.456138, 30.387069], [50.456045, 30.387138], [50.455828, 30.387264], [50.455709, 30.38732], [50.455413, 30.387427], [50.45536, 30.387444], [50.455299, 30.387466], [50.455081, 30.387558], [50.454514, 30.387806], [50.453913, 30.387947], [50.453795, 30.387975], [50.453679, 30.387999], [50.453394, 30.388062], [50.453102, 30.388119], [50.452864, 30.388151], [50.452856, 30.388018], [50.452832, 30.387622], [50.452825, 30.387497], [50.452805, 30.387159], [50.452787, 30.38686], [50.452785, 30.38683], [50.452749, 30.386224], [50.452694, 30.385303], [50.452653, 30.384618], [50.452646, 30.384519], [50.45257, 30.383411], [50.452567, 30.383363], [50.452564, 30.383319], [50.452556, 30.383192], [50.452532, 30.382847], [50.452476, 30.382861], [50.452227, 30.382926]], "routeDbId": 19, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0420\\u0438\\u0437\\u044c\\u043a\\u0430 59 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 7, "eta": "10:07", "id": 49, "lat": 50.4726843, "lng": 30.4360791, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0432\\u0443\\u043b\\u0438\\u0446\\u044f \\u0410\\u0432i\\u0430\\u043a\\u043e\\u043d\\u0441\\u0442\\u0440\\u0443\\u043a\\u0442\\u043e\\u0440\\u0430 I\\u0433\\u043e\\u0440\\u044f \\u0421\\u0456\\u043a\\u043e\\u0440\\u0441\\u044c\\u043a\\u043e\\u0433\\u043e 4\\u0434 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 5, "eta": "10:27", "id": 134, "lat": 50.4660975, "lng": 30.4293167, "serviceMin": 15, "stopOrder": 2, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u041a\\u043e\\u0442\\u0435\\u043b\\u044c\\u043d\\u0438\\u043a\\u043e\\u0432\\u0430 17 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 9, "eta": "10:51", "id": 212, "lat": 50.452258, "lng": 30.3832158, "serviceMin": 15, "stopOrder": 3, "waitMin": 0}], "totalDistanceKm": 11.7, "totalDriveMin": 21}]}	2026-04-25 11:16:05.258792	10:00:00
26	7	2026-04-25	completed	\N	1	4.31	8	\N	\N	\N	\N	2026-04-25 08:04:58.224974	2026-04-25 11:16:05.264984	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 10, "totalDeliveries": 29, "totalDistanceKm": 178.72, "totalDriveMin": 301}, "_selectedDate": "2026-04-25", "_fromDistribute": true, "routes": [{"courierId": "route_26", "courierName": "\\u0423\\u043a\\u043b\\u043e\\u043d", "departureAdjusted": false, "departureTime": "10:52", "geometry": [[50.473297, 30.482599], [50.47286, 30.48312], [50.472523, 30.483521], [50.471796, 30.484387], [50.471599, 30.484617], [50.4715, 30.484745], [50.471425, 30.484739], [50.471143, 30.48472], [50.470095, 30.484633], [50.470035, 30.48463], [50.469514, 30.484576], [50.46943, 30.484566], [50.46933, 30.484554], [50.469287, 30.484549], [50.468778, 30.484485], [50.46855, 30.484456], [50.467979, 30.484417], [50.46755, 30.484372], [50.466593, 30.484306], [50.46638, 30.4843], [50.465773, 30.484204], [50.465128, 30.484187], [50.465087, 30.484195], [50.465053, 30.485097], [50.465015, 30.486084], [50.465013, 30.486138], [50.464733, 30.486146], [50.464583, 30.486157], [50.464277, 30.486229], [50.463933, 30.486322], [50.463888, 30.486335], [50.463701, 30.486417], [50.463622, 30.486451], [50.463419, 30.486543], [50.462957, 30.486742], [50.462463, 30.486928], [50.462405, 30.486941], [50.462109, 30.486979], [50.462068, 30.486981], [50.461003, 30.486739], [50.460935, 30.486724], [50.46093, 30.48667], [50.460916, 30.486612], [50.460894, 30.486551], [50.460585, 30.48576], [50.46039, 30.485273], [50.460294, 30.485034], [50.460268, 30.484984], [50.460224, 30.484934], [50.460201, 30.484908], [50.460192, 30.484918], [50.46011, 30.485007], [50.459865, 30.485272], [50.459674, 30.48547], [50.459117, 30.486047], [50.459081, 30.486086], [50.458822, 30.486347], [50.458756, 30.486409], [50.458642, 30.48651], [50.45858, 30.48657], [50.45833, 30.486817], [50.457941, 30.487201], [50.45786, 30.487285], [50.457583, 30.487584], [50.457533, 30.48764], [50.457402, 30.487841], [50.45724, 30.488133], [50.457151, 30.488331], [50.45711, 30.488411], [50.456947, 30.488731], [50.456887, 30.488849], [50.456785, 30.48886], [50.456721, 30.48889], [50.456443, 30.489022], [50.455913, 30.489284], [50.455881, 30.489307], [50.455811, 30.489341], [50.45498, 30.489732], [50.454439, 30.489986], [50.453903, 30.490252], [50.453317, 30.490524], [50.452846, 30.490762], [50.452791, 30.490785], [50.452742, 30.490801], [50.452673, 30.490832], [50.452546, 30.490889], [50.452487, 30.490916], [50.452284, 30.491018], [50.452192, 30.49107], [50.452054, 30.491142], [50.452033, 30.491157], [50.451854, 30.491333], [50.451745, 30.491463], [50.45153, 30.491714], [50.451395, 30.491887], [50.451184, 30.492138], [50.451169, 30.492156], [50.450858, 30.492526], [50.450754, 30.492648], [50.45065, 30.49277], [50.450424, 30.493038], [50.450347, 30.493129], [50.450301, 30.493183], [50.450249, 30.493245], [50.45006, 30.49347], [50.449842, 30.493728], [50.44979, 30.49379], [50.449421, 30.494227], [50.449343, 30.494313], [50.449268, 30.494392], [50.448787, 30.494898], [50.448748, 30.494937], [50.448303, 30.4954], [50.448228, 30.495485], [50.447953, 30.495776], [50.447853, 30.49588], [50.44782, 30.495914], [50.447761, 30.495976], [50.447795, 30.496062], [50.44817, 30.497], [50.448374, 30.497509], [50.448398, 30.49757], [50.448439, 30.49767], [50.448526, 30.49789], [50.448636, 30.498169], [50.4486, 30.49819], [50.448566, 30.498211], [50.448517, 30.498299], [50.448501, 30.498377], [50.448494, 30.498419], [50.448402, 30.498977], [50.448391, 30.499043], [50.448348, 30.499305], [50.448162, 30.50043], [50.448143, 30.50055], [50.448136, 30.500592], [50.448123, 30.500668], [50.448045, 30.501142], [50.447943, 30.501763], [50.447671, 30.503413], [50.447615, 30.503754], [50.447598, 30.503875], [50.447582, 30.503992], [50.447462, 30.5047], [50.447448, 30.50479], [50.447375, 30.50476], [50.447039, 30.504626], [50.447016, 30.504636], [50.446996, 30.504666], [50.446813, 30.505717], [50.446843, 30.505814], [50.446886, 30.505955], [50.446927, 30.505972], [50.447037, 30.506016], [50.44706, 30.506025], [50.44716, 30.506071], [50.447227, 30.506108], [50.447231, 30.506084], [50.447327, 30.505513], [50.447411, 30.505549], [50.447423, 30.505553], [50.447901, 30.505736]], "routeDbId": 26, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0411\\u043e\\u0433\\u0434\\u0430\\u043d\\u0430 \\u0425\\u043c\\u0435\\u043b\\u044c\\u043d\\u0438\\u0446\\u044c\\u043a\\u043e\\u0433\\u043e 58\\u0430 ", "delivery_window_end": "13:00", "delivery_window_start": "11:00", "driveMin": 8, "eta": "11:00", "id": 255, "lat": 50.4480724, "lng": 30.5054962, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}], "totalDistanceKm": 4.31, "totalDriveMin": 8}]}	2026-04-25 11:16:05.264706	10:52:00
21	7	2026-04-25	completed	\N	4	37.85	64	\N	\N	\N	\N	2026-04-24 17:02:56.40752	2026-04-25 11:16:05.271201	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 10, "totalDeliveries": 29, "totalDistanceKm": 178.72, "totalDriveMin": 301}, "_selectedDate": "2026-04-25", "_fromDistribute": true, "routes": [{"courierId": "route_21", "courierName": "\\u0423\\u043a\\u043b\\u043e\\u043d", "departureAdjusted": false, "departureTime": "11:30", "geometry": [[50.473297, 30.482599], [50.473502, 30.482355], [50.47347, 30.482288], [50.473047, 30.481403], [50.473463, 30.480252], [50.473597, 30.47993], [50.473735, 30.479606], [50.473899, 30.479227], [50.473984, 30.479031], [50.474299, 30.478379], [50.474456, 30.478042], [50.474477, 30.477997], [50.474267, 30.477757], [50.473786, 30.477209], [50.473675, 30.477083], [50.473602, 30.477], [50.473547, 30.476932], [50.473399, 30.476768], [50.473569, 30.476633], [50.47396, 30.476239], [50.474068, 30.47613], [50.474193, 30.476021], [50.474324, 30.475931], [50.474462, 30.475866], [50.474598, 30.475819], [50.474973, 30.47569], [50.475343, 30.475586], [50.475487, 30.475567], [50.475663, 30.475564], [50.475857, 30.475594], [50.476043, 30.475651], [50.476277, 30.475775], [50.476514, 30.475947], [50.477777, 30.47706], [50.477924, 30.477166], [50.478071, 30.477221], [50.478217, 30.477244], [50.478369, 30.477221], [50.478507, 30.477158], [50.479235, 30.476663], [50.479356, 30.476569], [50.479428, 30.476513], [50.480746, 30.475281], [50.480858, 30.475175], [50.48097, 30.475109], [50.4811, 30.475079], [50.481237, 30.475093], [50.481369, 30.475168], [50.481473, 30.475265], [50.481568, 30.475403], [50.48183, 30.475849], [50.481908, 30.475982], [50.48204, 30.476129], [50.482193, 30.476244], [50.482325, 30.476303], [50.48247, 30.47634], [50.482596, 30.476346], [50.482722, 30.476329], [50.482881, 30.476265], [50.483074, 30.476126], [50.483815, 30.475332], [50.484271, 30.474845], [50.484854, 30.47423], [50.484943, 30.474146], [50.485083, 30.474016], [50.485334, 30.473743], [50.485747, 30.473186], [50.485908, 30.47294], [50.486106, 30.472645], [50.486179, 30.472515], [50.486385, 30.472174], [50.486522, 30.471921], [50.486892, 30.471255], [50.487179, 30.470734], [50.487359, 30.470421], [50.487448, 30.470269], [50.487709, 30.469836], [50.48799, 30.469368], [50.488217, 30.468992], [50.488395, 30.468701], [50.488714, 30.468161], [50.489001, 30.467695], [50.489058, 30.467591], [50.489687, 30.466551], [50.489844, 30.466288], [50.489946, 30.466122], [50.490081, 30.465901], [50.490516, 30.465194], [50.490601, 30.465079], [50.490665, 30.464993], [50.490835, 30.464772], [50.491155, 30.464393], [50.491901, 30.463617], [50.49205, 30.463461], [50.492214, 30.463281], [50.492754, 30.462675], [50.492868, 30.462547], [50.492989, 30.462399], [50.493813, 30.461406], [50.493837, 30.461377], [50.493878, 30.461329], [50.494225, 30.4609], [50.4943, 30.460801], [50.4944, 30.460667], [50.494458, 30.460586], [50.494765, 30.460154], [50.495078, 30.459671], [50.495229, 30.459431], [50.495281, 30.459336], [50.495306, 30.459283], [50.495355, 30.459183], [50.495504, 30.4589], [50.495662, 30.458595], [50.495749, 30.458429], [50.496084, 30.45778], [50.496394, 30.45716], [50.496424, 30.45711], [50.496773, 30.456446], [50.496825, 30.45636], [50.496948, 30.45616], [50.497126, 30.45588], [50.497242, 30.455713], [50.498164, 30.454477], [50.498376, 30.454206], [50.499169, 30.453177], [50.499455, 30.452835], [50.499765, 30.452447], [50.50005, 30.452122], [50.500288, 30.451844], [50.500358, 30.451781], [50.500425, 30.451748], [50.500468, 30.451733], [50.500578, 30.45172], [50.500843, 30.451692], [50.500965, 30.451677], [50.501113, 30.451656], [50.5012, 30.451645], [50.501627, 30.45158], [50.502214, 30.451484], [50.502254, 30.451477], [50.503107, 30.451352], [50.503507, 30.451296], [50.503546, 30.451288], [50.503938, 30.451221], [50.504303, 30.451159], [50.504692, 30.45109], [50.505083, 30.451012], [50.505364, 30.450959], [50.50556, 30.450927], [50.505903, 30.450873], [50.506051, 30.450846], [50.506377, 30.450823], [50.506512, 30.450815], [50.506758, 30.450806], [50.507287, 30.45078], [50.50801, 30.450738], [50.50827, 30.450721], [50.508373, 30.450714], [50.508454, 30.450707], [50.50926, 30.450624], [50.509639, 30.450578], [50.510039, 30.450526], [50.510154, 30.45051], [50.510972, 30.450391], [50.511278, 30.450346], [50.511598, 30.450311], [50.511882, 30.450275], [50.511924, 30.45027], [50.512026, 30.450257], [50.512518, 30.450186], [50.512536, 30.450059], [50.512716, 30.449089], [50.512783, 30.448723], [50.512854, 30.448356], [50.51297, 30.447745], [50.51303, 30.447427], [50.513116, 30.446936], [50.513278, 30.44613], [50.513421, 30.445422], [50.513566, 30.4447], [50.513725, 30.443908], [50.513786, 30.4436], [50.513959, 30.442766], [50.513993, 30.442673], [50.51401, 30.442641], [50.514102, 30.442418], [50.514122, 30.44237], [50.514161, 30.442276], [50.514132, 30.442246], [50.513925, 30.442033], [50.513994, 30.441847], [50.514016, 30.441788], [50.514016, 30.441788], [50.513994, 30.441847], [50.513925, 30.442033], [50.514132, 30.442246], [50.514161, 30.442276], [50.514122, 30.44237], [50.514102, 30.442418], [50.51401, 30.442641], [50.513993, 30.442673], [50.513959, 30.442766], [50.513786, 30.4436], [50.513725, 30.443908], [50.513566, 30.4447], [50.513421, 30.445422], [50.513278, 30.44613], [50.513116, 30.446936], [50.51303, 30.447427], [50.51297, 30.447745], [50.512854, 30.448356], [50.512783, 30.448723], [50.512716, 30.449089], [50.512536, 30.450059], [50.512518, 30.450186], [50.512026, 30.450257], [50.511924, 30.45027], [50.511882, 30.450275], [50.511598, 30.450311], [50.511278, 30.450346], [50.510972, 30.450391], [50.510154, 30.45051], [50.510039, 30.450526], [50.509639, 30.450578], [50.50926, 30.450624], [50.508454, 30.450707], [50.508373, 30.450714], [50.508394, 30.450899], [50.508441, 30.451522], [50.508456, 30.45172], [50.508463, 30.451821], [50.508478, 30.452014], [50.50852, 30.452573], [50.508527, 30.452674], [50.508548, 30.45296], [50.508581, 30.453452], [50.508608, 30.453751], [50.508617, 30.453844], [50.508629, 30.453956], [50.508647, 30.454112], [50.508673, 30.454351], [50.50869, 30.454499], [50.508756, 30.455104], [50.508774, 30.455243], [50.508781, 30.455302], [50.508878, 30.456164], [50.509, 30.457249], [50.509015, 30.457357], [50.509025, 30.457424], [50.509038, 30.457502], [50.509051, 30.4576], [50.509074, 30.457841], [50.509118, 30.458287], [50.509162, 30.458734], [50.509344, 30.460586], [50.509454, 30.461709], [50.509514, 30.462282], [50.509528, 30.462427], [50.509394, 30.46251], [50.509244, 30.462599], [50.508343, 30.463178], [50.507597, 30.46362], [50.507483, 30.463686], [50.506849, 30.464052], [50.505955, 30.464569], [50.505869, 30.464595], [50.505702, 30.464631], [50.5057, 30.465062], [50.505694, 30.465462], [50.505663, 30.466875], [50.50566, 30.467303], [50.505682, 30.467734], [50.50573, 30.46819], [50.505824, 30.468774], [50.505819, 30.469164], [50.505943, 30.470064], [50.506171, 30.471773], [50.506477, 30.473947], [50.506492, 30.474044], [50.506694, 30.4755], [50.506743, 30.475855], [50.506804, 30.476271], [50.506908, 30.477014], [50.507024, 30.477949], [50.50709, 30.478528], [50.507142, 30.479087], [50.507164, 30.479603], [50.507165, 30.480251], [50.507158, 30.48086], [50.507146, 30.48147], [50.507144, 30.481597], [50.507087, 30.481718], [50.507008, 30.481886], [50.506934, 30.481961], [50.506867, 30.482], [50.506788, 30.48203], [50.506447, 30.482121], [50.506377, 30.48214], [50.50631, 30.482168], [50.506236, 30.482214], [50.50589, 30.482443], [50.505197, 30.482894], [50.504957, 30.483089], [50.50491, 30.483131], [50.504869, 30.48315], [50.504758, 30.483217], [50.504334, 30.483429], [50.504097, 30.483511], [50.50349, 30.483782], [50.502675, 30.484156], [50.502251, 30.484369], [50.50176, 30.484588], [50.501295, 30.484811], [50.500639, 30.485175], [50.500313, 30.485383], [50.50007, 30.485562], [50.49983, 30.485742], [50.499677, 30.485857], [50.499436, 30.486089], [50.499384, 30.48614], [50.499172, 30.486365], [50.498883, 30.48669], [50.498825, 30.486761], [50.498785, 30.486811], [50.498589, 30.487052], [50.498433, 30.48727], [50.49816, 30.487652], [50.498092, 30.487748], [50.497989, 30.487893], [50.497166, 30.4891], [50.496826, 30.489589], [50.496534, 30.490009], [50.496256, 30.49041], [50.495941, 30.490876], [50.495605, 30.491373], [50.495308, 30.491811], [50.494893, 30.492408], [50.493985, 30.493717], [50.493543, 30.494347], [50.49332, 30.494666], [50.493149, 30.494915], [50.493041, 30.495073], [50.492536, 30.495881], [50.491678, 30.497145], [50.490673, 30.498596], [50.489571, 30.500256], [50.488248, 30.502199], [50.487866, 30.502765], [50.487779, 30.502918], [50.487675, 30.503187], [50.487639, 30.503528], [50.487646, 30.503821], [50.487701, 30.504102], [50.487935, 30.504608], [50.488186, 30.505114], [50.488448, 30.50565], [50.488531, 30.505853], [50.488618, 30.506086], [50.488631, 30.506143], [50.488671, 30.50635], [50.488715, 30.506931], [50.488742, 30.507655], [50.488727, 30.50805], [50.488711, 30.508429], [50.488689, 30.509065], [50.488666, 30.509658], [50.488645, 30.510266], [50.488627, 30.510741], [50.48855, 30.512223], [50.488525, 30.512788], [50.488488, 30.513601], [50.488434, 30.51496], [50.4884, 30.515914], [50.488327, 30.517924], [50.488296, 30.518688], [50.488265, 30.51943], [50.488233, 30.52017], [50.488232, 30.520201], [50.488216, 30.520645], [50.488203, 30.520922], [50.488153, 30.522126], [50.488108, 30.523245], [50.488107, 30.524187], [50.488137, 30.525082], [50.488177, 30.525718], [50.488197, 30.525949], [50.488303, 30.527026], [50.488371, 30.527562], [50.488596, 30.528758], [50.488721, 30.529385], [50.488887, 30.530082], [50.489122, 30.530897], [50.489426, 30.531899], [50.492155, 30.540894], [50.492175, 30.540964], [50.492417, 30.541796], [50.49285, 30.543273], [50.493078, 30.544171], [50.493304, 30.545063], [50.493477, 30.546043], [50.493591, 30.546823], [50.49375, 30.54808], [50.49397, 30.549846], [50.494278, 30.55223], [50.494938, 30.557286], [50.495144, 30.559064], [50.495241, 30.560153], [50.495273, 30.560546], [50.495339, 30.561399], [50.495371, 30.561816], [50.4954, 30.562202], [50.495417, 30.562606], [50.495438, 30.563215], [50.49546, 30.563872], [50.495484, 30.565597], [50.495483, 30.56572], [50.495477, 30.566738], [50.495469, 30.568139], [50.495468, 30.56875], [50.495453, 30.570136], [50.495448, 30.570766], [50.495442, 30.571902], [50.495435, 30.572952], [50.495425, 30.574589], [50.495401, 30.575331], [50.495316, 30.575721], [50.495273, 30.575885], [50.495192, 30.576067], [50.495142, 30.576115], [50.495053, 30.576185], [50.494984, 30.57622], [50.494944, 30.576219], [50.494753, 30.576233], [50.494671, 30.576134], [50.494595, 30.57604], [50.494451, 30.575751], [50.49434, 30.575477], [50.494298, 30.575284], [50.494316, 30.575108], [50.494358, 30.574962], [50.494421, 30.574824], [50.494512, 30.574696], [50.494571, 30.574648], [50.494647, 30.574612], [50.494754, 30.574615], [50.496183, 30.575015], [50.496853, 30.575221], [50.496974, 30.575258], [50.497176, 30.575338], [50.497317, 30.575394], [50.497639, 30.575531], [50.498162, 30.575783], [50.498334, 30.57587], [50.498687, 30.576054], [50.499174, 30.576333], [50.499308, 30.576426], [50.499424, 30.576525], [50.499644, 30.576774], [50.499749, 30.576905], [50.499757, 30.576914], [50.500169, 30.577371], [50.50036, 30.577583], [50.500442, 30.577665], [50.500525, 30.577748], [50.500669, 30.577892], [50.50137, 30.578513], [50.50141, 30.578548], [50.501439, 30.578574], [50.502092, 30.579148], [50.502439, 30.579479], [50.5026, 30.579624], [50.502717, 30.579737], [50.503143, 30.580198], [50.504421, 30.581749], [50.504693, 30.582088], [50.50494, 30.582423], [50.505117, 30.582669], [50.505265, 30.582926], [50.505444, 30.583361], [50.505464, 30.583465], [50.505468, 30.583533], [50.505468, 30.58358], [50.505467, 30.583657], [50.505451, 30.58375], [50.505432, 30.583791], [50.505414, 30.58385], [50.505407, 30.583909], [50.505407, 30.58397], [50.505416, 30.584029], [50.505433, 30.584084], [50.505456, 30.584131], [50.505486, 30.584169], [50.505516, 30.584194], [50.505554, 30.584211], [50.505697, 30.584317], [50.505951, 30.584519], [50.506351, 30.584879], [50.506456, 30.585012], [50.506665, 30.585255], [50.506816, 30.585465], [50.506981, 30.585695], [50.507078, 30.585843], [50.507319, 30.586206], [50.507475, 30.586483], [50.507607, 30.586715], [50.507871, 30.587272], [50.507961, 30.587479], [50.508358, 30.588507], [50.508392, 30.588591], [50.508795, 30.589781], [50.508903, 30.590103], [50.509535, 30.591972], [50.509605, 30.592179], [50.509899, 30.59306], [50.510327, 30.594322], [50.510759, 30.595622], [50.510887, 30.595974], [50.510981, 30.596229], [50.511029, 30.596377], [50.511107, 30.596608], [50.511547, 30.597923], [50.511944, 30.598972], [50.512314, 30.599777], [50.512451, 30.600076], [50.512543, 30.600247], [50.513067, 30.601229], [50.513342, 30.6017], [50.513442, 30.601865], [50.514, 30.60278], [50.514097, 30.602919], [50.514135, 30.602974], [50.514826, 30.603809], [50.515351, 30.604366], [50.51538, 30.604397], [50.515801, 30.604834], [50.516075, 30.605099], [50.516219, 30.605238], [50.5163, 30.605313], [50.516844, 30.603953], [50.516999, 30.603589], [50.517146, 30.603216], [50.517957, 30.601268], [50.518113, 30.600911], [50.518794, 30.599302], [50.519041, 30.598711], [50.519493, 30.59764], [50.519703, 30.597151], [50.520021, 30.596407], [50.520157, 30.596092], [50.520072, 30.596005], [50.519746, 30.595687], [50.51938, 30.59532], [50.51912, 30.59505], [50.518998, 30.594921], [50.518751, 30.594665], [50.518665, 30.59458], [50.51862, 30.594534], [50.51857, 30.59448], [50.518484, 30.594391], [50.517435, 30.593307], [50.517298, 30.593167], [50.517234, 30.593105], [50.517183, 30.593062], [50.516959, 30.592902], [50.516728, 30.592762], [50.516352, 30.592623], [50.516, 30.592581], [50.515791, 30.592594], [50.515505, 30.592668], [50.515329, 30.592753], [50.515293, 30.592782], [50.515261, 30.5928], [50.515255, 30.592622], [50.515257, 30.592551], [50.515266, 30.592449], [50.515291, 30.592043], [50.515306, 30.591914], [50.515352, 30.591614], [50.515378, 30.591482], [50.515481, 30.59046], [50.51561, 30.589113], [50.514573, 30.588863], [50.514267, 30.588794], [50.513899, 30.58871], [50.513601, 30.5886], [50.513036, 30.588291], [50.512796, 30.588152], [50.512324, 30.587877], [50.511854, 30.587604], [50.511178, 30.587185], [50.510463, 30.586594], [50.509913, 30.586111], [50.509768, 30.585973], [50.509356, 30.585579], [50.509138, 30.585491], [50.508958, 30.585442], [50.508848, 30.58535], [50.508721, 30.585386], [50.508609, 30.585426], [50.508473, 30.585526], [50.508406, 30.585582], [50.508248, 30.585275], [50.508053, 30.584919], [50.507821, 30.584532], [50.507684, 30.584303], [50.50737, 30.583835], [50.507306, 30.58374], [50.506424, 30.582425], [50.505894, 30.581625], [50.505716, 30.581357], [50.505589, 30.581173], [50.505166, 30.580617], [50.505081, 30.580516], [50.504967, 30.580377], [50.504726, 30.580092], [50.503958, 30.579166], [50.503427, 30.578597], [50.502913, 30.578071], [50.502361, 30.577568], [50.501896, 30.57718], [50.500995, 30.576428], [50.500521, 30.57619], [50.500259, 30.576109], [50.499974, 30.576051], [50.499966, 30.57605], [50.499728, 30.576012], [50.499525, 30.575955], [50.497969, 30.575179], [50.497747, 30.575025], [50.497616, 30.574785], [50.497498, 30.574564], [50.497404, 30.574379], [50.49709, 30.573739], [50.496662, 30.572859], [50.496468, 30.572462], [50.496367, 30.572266], [50.495826, 30.571086], [50.49573, 30.570875], [50.495666, 30.570643], [50.495579, 30.570035], [50.495585, 30.569349], [50.495589, 30.567267], [50.495582, 30.565681], [50.495559, 30.563874], [50.495544, 30.563213], [50.495508, 30.562199], [50.49549, 30.561862], [50.495432, 30.561097], [50.495422, 30.560968], [50.495401, 30.560697], [50.49534, 30.559973], [50.49531, 30.559605], [50.495245, 30.559067], [50.495083, 30.557629], [50.495043, 30.55725], [50.494386, 30.552189], [50.494076, 30.549783], [50.493709, 30.546802], [50.493623, 30.546013], [50.493451, 30.545008], [50.493215, 30.5441], [50.492995, 30.543252], [50.492526, 30.541691], [50.49226, 30.5409], [50.492246, 30.54085], [50.48945, 30.531555], [50.489229, 30.530817], [50.48901, 30.530027], [50.488983, 30.529709], [50.488969, 30.529445], [50.48898, 30.52917], [50.488984, 30.529114], [50.488996, 30.528966], [50.489033, 30.52872], [50.489546, 30.526909], [50.489931, 30.525592], [50.490086, 30.525133], [50.49015, 30.524946], [50.490271, 30.524741], [50.490389, 30.524524], [50.49061, 30.524311], [50.490974, 30.523947], [50.491042, 30.523878], [50.491091, 30.52383], [50.49123, 30.523693], [50.491604, 30.52326], [50.49209, 30.522773], [50.492809, 30.522094], [50.493143, 30.521783], [50.493488, 30.521441], [50.493579, 30.521352], [50.494205, 30.520733], [50.495233, 30.519714], [50.495331, 30.519618], [50.495447, 30.519504], [50.496115, 30.518818], [50.496319, 30.51861], [50.496416, 30.518518], [50.496438, 30.518497], [50.496492, 30.518328], [50.496516, 30.518165], [50.496505, 30.517999], [50.496463, 30.517846], [50.496391, 30.517722], [50.496294, 30.517635], [50.496213, 30.517539], [50.496162, 30.517477], [50.496098, 30.517339], [50.49602, 30.517141], [50.495963, 30.5169], [50.49594, 30.516688], [50.495932, 30.516186], [50.495937, 30.515855], [50.495954, 30.514603], [50.495971, 30.512811], [50.495988, 30.510914], [50.496001, 30.509931], [50.496002, 30.509827], [50.496003, 30.509711], [50.496009, 30.509289], [50.496043, 30.508904], [50.49609, 30.508666], [50.496154, 30.508448], [50.496234, 30.508197], [50.496269, 30.508128], [50.496296, 30.50805], [50.496425, 30.507772], [50.496528, 30.507575], [50.496622, 30.507418], [50.496651, 30.507377], [50.496763, 30.507247], [50.497444, 30.506558], [50.497659, 30.506341], [50.498752, 30.50522], [50.498905, 30.505062], [50.499604, 30.504372], [50.499719, 30.504256], [50.499758, 30.50437], [50.49977, 30.504408], [50.499785, 30.504453], [50.499781, 30.50458], [50.499762, 30.505191], [50.500622, 30.505181], [50.501051, 30.505177], [50.501057, 30.504718], [50.500658, 30.504721], [50.500229, 30.504724], [50.500658, 30.504721], [50.501057, 30.504718], [50.501051, 30.505177], [50.500895, 30.505178], [50.500622, 30.505181], [50.499762, 30.505191], [50.499781, 30.50458], [50.499785, 30.504453], [50.49977, 30.504408], [50.499758, 30.50437], [50.499719, 30.504256], [50.500257, 30.503711], [50.500366, 30.503612], [50.500504, 30.503549], [50.500637, 30.503524], [50.500742, 30.503546], [50.500828, 30.50359], [50.500971, 30.503713], [50.501075, 30.503779], [50.501182, 30.503787], [50.501285, 30.503741], [50.501373, 30.503644], [50.501437, 30.503509], [50.501469, 30.503348], [50.501472, 30.50328], [50.501493, 30.502973], [50.501504, 30.502662], [50.501529, 30.501303], [50.501538, 30.500773], [50.501546, 30.500002], [50.501551, 30.499524], [50.501562, 30.49883], [50.501564, 30.498727], [50.501573, 30.497876], [50.501574, 30.497755], [50.501577, 30.497556], [50.50158, 30.496939], [50.501593, 30.496008], [50.501618, 30.494231], [50.501624, 30.493809], [50.501625, 30.493684], [50.501628, 30.493516], [50.501637, 30.493245], [50.501667, 30.49302], [50.501708, 30.492839], [50.501812, 30.492522], [50.501936, 30.492232], [50.502038, 30.492055], [50.502087, 30.491975], [50.502254, 30.491778], [50.502424, 30.491624], [50.502626, 30.491502], [50.502698, 30.491463], [50.502877, 30.491369], [50.503056, 30.491276], [50.504997, 30.490265], [50.50546, 30.490009], [50.505522, 30.48997], [50.505766, 30.489842], [50.505909, 30.489768], [50.506087, 30.489676], [50.506279, 30.489592], [50.506517, 30.48953], [50.506768, 30.489517], [50.506817, 30.489523], [50.507091, 30.489553], [50.507187, 30.489551], [50.507278, 30.489503], [50.507357, 30.489416], [50.507415, 30.489297], [50.50743, 30.489238], [50.507445, 30.48918], [50.507451, 30.489138], [50.507454, 30.489003], [50.507435, 30.488872], [50.507394, 30.488753], [50.507315, 30.488534], [50.507264, 30.488257], [50.507215, 30.487845], [50.507196, 30.487472], [50.507196, 30.487327], [50.507197, 30.486298], [50.5072, 30.485447], [50.507215, 30.484023], [50.507232, 30.482764], [50.507253, 30.481592], [50.507256, 30.481471], [50.507265, 30.480797], [50.50727, 30.480236], [50.507261, 30.479595], [50.507235, 30.479072], [50.507192, 30.478502], [50.507118, 30.477884], [50.50705, 30.47734], [50.506906, 30.476244], [50.506655, 30.474414], [50.506582, 30.473858], [50.506484, 30.473193], [50.506201, 30.471177], [50.506084, 30.470342], [50.505972, 30.469508], [50.505919, 30.469107], [50.505824, 30.468774], [50.50573, 30.46819], [50.505682, 30.467734], [50.50566, 30.467303], [50.505663, 30.466875], [50.505694, 30.465462], [50.5057, 30.465062], [50.505702, 30.464631], [50.505869, 30.464595], [50.505955, 30.464569], [50.506849, 30.464052], [50.507483, 30.463686], [50.507597, 30.46362], [50.508343, 30.463178], [50.509244, 30.462599], [50.509394, 30.46251], [50.509528, 30.462427], [50.509514, 30.462282], [50.509454, 30.461709], [50.509344, 30.460586], [50.509162, 30.458734], [50.509118, 30.458287], [50.509074, 30.457841], [50.509051, 30.4576], [50.509038, 30.457502], [50.509025, 30.457424], [50.509015, 30.457357], [50.509, 30.457249], [50.508878, 30.456164], [50.508781, 30.455302], [50.508774, 30.455243], [50.508756, 30.455104], [50.50869, 30.454499], [50.508673, 30.454351], [50.508647, 30.454112], [50.508629, 30.453956], [50.508617, 30.453844], [50.508608, 30.453751], [50.508581, 30.453452], [50.508548, 30.45296], [50.508527, 30.452674], [50.50852, 30.452573], [50.508478, 30.452014], [50.508463, 30.451821], [50.508456, 30.45172], [50.508441, 30.451522], [50.508394, 30.450899], [50.508373, 30.450714], [50.508369, 30.450579], [50.508391, 30.449828], [50.50839, 30.449499], [50.508387, 30.448935], [50.508383, 30.448819], [50.508369, 30.448546], [50.508357, 30.448255], [50.508344, 30.448117], [50.508267, 30.447711], [50.50811, 30.447026], [50.508087, 30.446855], [50.508074, 30.446681], [50.508079, 30.446532], [50.50809, 30.446385], [50.508127, 30.446185], [50.508158, 30.446022], [50.508219, 30.445714], [50.508366, 30.445097], [50.508387, 30.445043], [50.50868, 30.444649], [50.509018, 30.444233], [50.509081, 30.444138], [50.50911, 30.444079], [50.509181, 30.443906], [50.509212, 30.443799], [50.509294, 30.443445], [50.509338, 30.443255], [50.509381, 30.443064], [50.509419, 30.442906], [50.509456, 30.44274], [50.509464, 30.442705], [50.509489, 30.442596], [50.509524, 30.442451], [50.509721, 30.441829], [50.509742, 30.441753], [50.50992, 30.441149], [50.509929, 30.441125], [50.50994, 30.441092], [50.509963, 30.441026], [50.510008, 30.440891], [50.510023, 30.440905], [50.51004, 30.44091], [50.510058, 30.440908], [50.510074, 30.440898], [50.510088, 30.44088], [50.510098, 30.440857], [50.510103, 30.44083], [50.510102, 30.440802], [50.510097, 30.440776], [50.510087, 30.440753], [50.510126, 30.440701], [50.510234, 30.440566], [50.510299, 30.440484], [50.51036, 30.440552], [50.510398, 30.440588], [50.510496, 30.440651], [50.511156, 30.441048], [50.511205, 30.441077], [50.511586, 30.441301], [50.511986, 30.441537], [50.512046, 30.441572], [50.512327, 30.441738], [50.512671, 30.44194], [50.512653, 30.441995], [50.512561, 30.442285], [50.512448, 30.442364], [50.512386, 30.442411], [50.512322, 30.442516], [50.51228, 30.442654], [50.512161, 30.442936], [50.51211, 30.443063], [50.512429, 30.443248]], "routeDbId": 21, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0412\\u0443\\u043b. \\u0411\\u0430\\u0439\\u0434\\u0438-\\u0412\\u0438\\u0448\\u043d\\u0435\\u0432\\u0435\\u0446\\u044c\\u043a\\u043e\\u0433\\u043e \\u0431\\u0443\\u0434. 9 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 11, "eta": "11:41", "id": 165, "lat": 50.5140494, "lng": 30.4416717, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0432\\u0443\\u043b\\u0438\\u0446\\u044f \\u041c\\u0438\\u0442\\u0440\\u043e\\u043f\\u043e\\u043b\\u0438\\u0442\\u0430 \\u0412\\u043e\\u043b\\u043e\\u0434\\u0438\\u043c\\u0438\\u0440\\u0430 \\u0421\\u0430\\u0431\\u043e\\u0434\\u0430\\u043d\\u0430 21 ", "delivery_window_end": "13:00", "delivery_window_start": "10:00", "driveMin": 28, "eta": "12:24", "id": 77, "lat": 50.51427899999999, "lng": 30.5886657, "serviceMin": 15, "stopOrder": 2, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0419\\u043e\\u0440\\u0434\\u0430\\u043d\\u0441\\u044c\\u043a\\u0430, 26  ", "delivery_window_end": "15:00", "delivery_window_start": "12:40", "driveMin": 14, "eta": "12:53", "id": 101, "lat": 50.5008939, "lng": 30.5049628, "serviceMin": 15, "stopOrder": 3, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0412\\u0443\\u043b. \\u0412\\u0456\\u0442\\u0440\\u044f\\u043d\\u0456 \\u0433\\u043e\\u0440\\u0438 10\\u0413 ", "delivery_window_end": "15:00", "delivery_window_start": "13:00", "driveMin": 11, "eta": "13:19", "id": 253, "lat": 50.5123769, "lng": 30.443469, "serviceMin": 15, "stopOrder": 4, "waitMin": 0}], "totalDistanceKm": 37.85, "totalDriveMin": 64}]}	2026-04-25 11:16:05.270855	11:30:00
27	7	2026-04-25	completed	\N	1	9.04	15	\N	\N	\N	\N	2026-04-25 08:04:58.227546	2026-04-25 11:16:05.277122	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 10, "totalDeliveries": 29, "totalDistanceKm": 178.72, "totalDriveMin": 301}, "_selectedDate": "2026-04-25", "_fromDistribute": true, "routes": [{"courierId": "route_27", "courierName": "\\u0423\\u043a\\u043b\\u043e\\u043d", "departureAdjusted": false, "departureTime": "11:45", "geometry": [[50.473297, 30.482599], [50.473502, 30.482355], [50.47347, 30.482288], [50.473047, 30.481403], [50.473463, 30.480252], [50.473597, 30.47993], [50.473735, 30.479606], [50.473899, 30.479227], [50.473984, 30.479031], [50.474299, 30.478379], [50.474456, 30.478042], [50.474477, 30.477997], [50.474267, 30.477757], [50.473786, 30.477209], [50.473675, 30.477083], [50.473602, 30.477], [50.473547, 30.476932], [50.473399, 30.476768], [50.472755, 30.476038], [50.472703, 30.475972], [50.472265, 30.475462], [50.472156, 30.475336], [50.471636, 30.474724], [50.471449, 30.474504], [50.471231, 30.474262], [50.471075, 30.474089], [50.470961, 30.473956], [50.470842, 30.473819], [50.47039, 30.473305], [50.470282, 30.473193], [50.470158, 30.473064], [50.469777, 30.472613], [50.469619, 30.472426], [50.469568, 30.472361], [50.469594, 30.472301], [50.469611, 30.472271], [50.469885, 30.471668], [50.469977, 30.471463], [50.470353, 30.470682], [50.470506, 30.470362], [50.47054, 30.470286], [50.470807, 30.469735], [50.470763, 30.469686], [50.47071, 30.469621], [50.470181, 30.468958], [50.469482, 30.468144], [50.469468, 30.46812], [50.469439, 30.468058], [50.469471, 30.467986], [50.469745, 30.467381], [50.469962, 30.466901], [50.470506, 30.465757], [50.470675, 30.465394], [50.470924, 30.464854], [50.470959, 30.464772], [50.471014, 30.464641], [50.471088, 30.46444], [50.471174, 30.464142], [50.471231, 30.463926], [50.471283, 30.463711], [50.471336, 30.463394], [50.471385, 30.463025], [50.471542, 30.461635], [50.471721, 30.459981], [50.471833, 30.459007], [50.471858, 30.458792], [50.471878, 30.458635], [50.47195, 30.458121], [50.471991, 30.457855], [50.472019, 30.457653], [50.472292, 30.455765], [50.472371, 30.455236], [50.472466, 30.454607], [50.472592, 30.453789], [50.472707, 30.452969], [50.472867, 30.451878], [50.47289, 30.451732], [50.47291, 30.4516], [50.473152, 30.449977], [50.473422, 30.448095], [50.473485, 30.447627], [50.473506, 30.447452], [50.473613, 30.446747], [50.473727, 30.445995], [50.473805, 30.44548], [50.473893, 30.444904], [50.473964, 30.444457], [50.474157, 30.443201], [50.474175, 30.443066], [50.474192, 30.442941], [50.474412, 30.441512], [50.474506, 30.440888], [50.474524, 30.440768], [50.474541, 30.44064], [50.474767, 30.439207], [50.474836, 30.438741], [50.474908, 30.438241], [50.475043, 30.437347], [50.475058, 30.437254], [50.475086, 30.437067], [50.475131, 30.436838], [50.475226, 30.436507], [50.475347, 30.436251], [50.475743, 30.435615], [50.475931, 30.435316], [50.476036, 30.435144], [50.476699, 30.434083], [50.476812, 30.433837], [50.476899, 30.433616], [50.476963, 30.433405], [50.477038, 30.433072], [50.477073, 30.432754], [50.477079, 30.432658], [50.477086, 30.432406], [50.477074, 30.432169], [50.477032, 30.431809], [50.47695, 30.431146], [50.476924, 30.430926], [50.476865, 30.430462], [50.476814, 30.430105], [50.476752, 30.429717], [50.476655, 30.429074], [50.476597, 30.428403], [50.476599, 30.42773], [50.476617, 30.427275], [50.476706, 30.426553], [50.476763, 30.426145], [50.476835, 30.425625], [50.476912, 30.42508], [50.47697, 30.424664], [50.477005, 30.424197], [50.477032, 30.423591], [50.477034, 30.423556], [50.477352, 30.417934], [50.477414, 30.416784], [50.47744, 30.415749], [50.477439, 30.414759], [50.477441, 30.414241], [50.477438, 30.413919], [50.477418, 30.413704], [50.477434, 30.413553], [50.477455, 30.413429], [50.477525, 30.41308], [50.477561, 30.412954], [50.477633, 30.412713], [50.477686, 30.412562], [50.477734, 30.41243], [50.477858, 30.412152], [50.478522, 30.410972], [50.479104, 30.409893], [50.479163, 30.409772], [50.4795, 30.409133], [50.479757, 30.408667], [50.479841, 30.408503], [50.479862, 30.40846], [50.479895, 30.408408], [50.479927, 30.408348], [50.480265, 30.407941], [50.480408, 30.407696], [50.480528, 30.407558], [50.48067, 30.407442], [50.480828, 30.407362], [50.480904, 30.407326], [50.481026, 30.407234], [50.481244, 30.406834], [50.481347, 30.406644], [50.481539, 30.406288], [50.481787, 30.405838], [50.482084, 30.405831], [50.482202, 30.405829], [50.482252, 30.405828], [50.482938, 30.405827], [50.483043, 30.405828], [50.483217, 30.405825], [50.483632, 30.405825], [50.483809, 30.405825], [50.48421, 30.405827], [50.484413, 30.405826], [50.484777, 30.405822], [50.484823, 30.405821], [50.485384, 30.405819], [50.485987, 30.405819], [50.486162, 30.40582], [50.486566, 30.405818], [50.48659, 30.405818], [50.486617, 30.405818], [50.487151, 30.405823], [50.487209, 30.405823], [50.487858, 30.405821], [50.488275, 30.40582], [50.488349, 30.40582], [50.488429, 30.405819], [50.488993, 30.405818], [50.48959, 30.405816], [50.49019, 30.40583], [50.490489, 30.405841], [50.490762, 30.405854], [50.490879, 30.405857], [50.490973, 30.405855], [50.491336, 30.405856], [50.491675, 30.405853], [50.491873, 30.405851], [50.493165, 30.405844], [50.493319, 30.405847], [50.493383, 30.405847], [50.493566, 30.405851], [50.493952, 30.40586], [50.494743, 30.40587], [50.494937, 30.405869], [50.495151, 30.405868], [50.495241, 30.405868], [50.49534, 30.405869], [50.495496, 30.405868], [50.496489, 30.405863], [50.498362, 30.405844], [50.499831, 30.405823], [50.500295, 30.405817], [50.50072, 30.405827], [50.501369, 30.40587], [50.501912, 30.405962], [50.50293, 30.406219], [50.503769, 30.406563], [50.504055, 30.406815], [50.50454, 30.407185], [50.504699, 30.407277], [50.505352, 30.407609], [50.505324, 30.407759], [50.505307, 30.407851], [50.505273, 30.408024], [50.504883, 30.407845]], "routeDbId": 27, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0406\\u0432\\u0430\\u043d\\u0430 \\u0412\\u0438\\u0433\\u043e\\u0432\\u0441\\u044c\\u043a\\u043e\\u0433\\u043e 42 ", "delivery_window_end": "14:00", "delivery_window_start": "12:00", "driveMin": 15, "eta": "12:00", "id": 244, "lat": 50.504867, "lng": 30.4079296, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}], "totalDistanceKm": 9.04, "totalDriveMin": 15}]}	2026-04-25 11:16:05.276842	11:45:00
20	7	2026-04-25	accepted	\N	1	13.67	21	\N	\N	\N	\N	2026-04-24 17:02:56.40241	2026-04-25 11:16:05.281856	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 10, "totalDeliveries": 29, "totalDistanceKm": 178.72, "totalDriveMin": 301}, "_selectedDate": "2026-04-25", "_fromDistribute": true, "routes": [{"courierId": "route_20", "courierName": "\\u0423\\u043a\\u043b\\u043e\\u043d", "departureAdjusted": false, "departureTime": "15:39", "geometry": [[50.473297, 30.482599], [50.473502, 30.482355], [50.47347, 30.482288], [50.473047, 30.481403], [50.473463, 30.480252], [50.473597, 30.47993], [50.473735, 30.479606], [50.473899, 30.479227], [50.473984, 30.479031], [50.474299, 30.478379], [50.474456, 30.478042], [50.474477, 30.477997], [50.474267, 30.477757], [50.473786, 30.477209], [50.473675, 30.477083], [50.473602, 30.477], [50.473547, 30.476932], [50.473399, 30.476768], [50.472755, 30.476038], [50.472703, 30.475972], [50.472265, 30.475462], [50.472156, 30.475336], [50.471636, 30.474724], [50.471449, 30.474504], [50.471231, 30.474262], [50.471075, 30.474089], [50.470961, 30.473956], [50.470842, 30.473819], [50.47039, 30.473305], [50.470282, 30.473193], [50.470158, 30.473064], [50.469777, 30.472613], [50.469619, 30.472426], [50.469568, 30.472361], [50.469594, 30.472301], [50.469611, 30.472271], [50.469885, 30.471668], [50.469977, 30.471463], [50.470353, 30.470682], [50.470506, 30.470362], [50.47054, 30.470286], [50.470807, 30.469735], [50.470763, 30.469686], [50.47071, 30.469621], [50.470181, 30.468958], [50.469482, 30.468144], [50.469468, 30.46812], [50.469439, 30.468058], [50.469471, 30.467986], [50.469745, 30.467381], [50.469962, 30.466901], [50.470506, 30.465757], [50.470489, 30.465588], [50.470486, 30.465506], [50.470484, 30.46544], [50.470464, 30.464851], [50.470416, 30.463784], [50.470407, 30.463603], [50.470404, 30.463411], [50.470395, 30.46311], [50.470392, 30.462936], [50.470386, 30.462609], [50.470386, 30.462512], [50.470382, 30.462394], [50.470377, 30.462162], [50.470371, 30.46197], [50.470369, 30.461923], [50.470343, 30.461305], [50.470321, 30.46088], [50.470297, 30.460538], [50.470184, 30.459577], [50.470091, 30.458928], [50.469943, 30.457854], [50.469922, 30.457725], [50.469843, 30.45716], [50.469797, 30.456683], [50.469766, 30.456111], [50.469776, 30.455598], [50.469806, 30.454375], [50.469807, 30.454195], [50.469811, 30.454047], [50.469844, 30.452675], [50.469849, 30.452398], [50.469893, 30.450595], [50.469902, 30.45032], [50.469946, 30.449703], [50.470003, 30.448983], [50.47006, 30.448212], [50.470112, 30.447669], [50.470147, 30.447008], [50.470152, 30.446909], [50.470156, 30.446803], [50.470162, 30.446641], [50.470166, 30.44651], [50.470169, 30.446407], [50.470186, 30.445852], [50.470192, 30.44571], [50.4702, 30.445516], [50.470221, 30.44503], [50.470236, 30.444718], [50.470239, 30.44462], [50.470269, 30.443875], [50.470267, 30.443683], [50.47017, 30.443639], [50.470093, 30.443597], [50.469905, 30.443462], [50.469279, 30.443028], [50.468885, 30.442756], [50.46835, 30.44239], [50.468283, 30.442339], [50.46723, 30.441614], [50.467181, 30.44158], [50.467142, 30.441553], [50.467, 30.441455], [50.465887, 30.440684], [50.46515, 30.440161], [50.465073, 30.440109], [50.465018, 30.440069], [50.464921, 30.440003], [50.464784, 30.439909], [50.464457, 30.439678], [50.464335, 30.439567], [50.464228, 30.439444], [50.464107, 30.439274], [50.463974, 30.439021], [50.463972, 30.439019], [50.463861, 30.438728], [50.463801, 30.438527], [50.463738, 30.438332], [50.463536, 30.437632], [50.4635, 30.437545], [50.463347, 30.437066], [50.463255, 30.436772], [50.463118, 30.436323], [50.463095, 30.436255], [50.463041, 30.436093], [50.462909, 30.435666], [50.462722, 30.435069], [50.462497, 30.434345], [50.462149, 30.433207], [50.462124, 30.433126], [50.462087, 30.432967], [50.462037, 30.432733], [50.461778, 30.431716], [50.461746, 30.431598], [50.461504, 30.430719], [50.461367, 30.430245], [50.461274, 30.429936], [50.46111, 30.429362], [50.461052, 30.429164], [50.461014, 30.429034], [50.460912, 30.428682], [50.46052, 30.427309], [50.460398, 30.42689], [50.460324, 30.426638], [50.460254, 30.426394], [50.460187, 30.426198], [50.460135, 30.42608], [50.459963, 30.425679], [50.459925, 30.425554], [50.459831, 30.425243], [50.459342, 30.423568], [50.459258, 30.423243], [50.45906, 30.422548], [50.459031, 30.42243], [50.459018, 30.422324], [50.459009, 30.422247], [50.458981, 30.421911], [50.458937, 30.421239], [50.458916, 30.420795], [50.458906, 30.420133], [50.458908, 30.419845], [50.458918, 30.419539], [50.459023, 30.418893], [50.459216, 30.41792], [50.459484, 30.416738], [50.459552, 30.416288], [50.459593, 30.415379], [50.459583, 30.414995], [50.459521, 30.414286], [50.459407, 30.413361], [50.459257, 30.412352], [50.459192, 30.411842], [50.459098, 30.411213], [50.459016, 30.410669], [50.458933, 30.409817], [50.458414, 30.401572], [50.458362, 30.400552], [50.458311, 30.399544], [50.458255, 30.398732], [50.458073, 30.396072], [50.457873, 30.393073], [50.457854, 30.39279], [50.457829, 30.392415], [50.457823, 30.392322], [50.457615, 30.389333], [50.457441, 30.386729], [50.457404, 30.386194], [50.457356, 30.385483], [50.457288, 30.384489], [50.457212, 30.38339], [50.457067, 30.381243], [50.457017, 30.3805], [50.456986, 30.38009], [50.456959, 30.379583], [50.456998, 30.379445], [50.457036, 30.379348], [50.457091, 30.379285], [50.457138, 30.379258], [50.457172, 30.379251], [50.457558, 30.379178], [50.457686, 30.379163], [50.457806, 30.379145], [50.458406, 30.379052], [50.458548, 30.379029], [50.458693, 30.379009], [50.458749, 30.378999], [50.458805, 30.37899], [50.459101, 30.378935], [50.459534, 30.378866], [50.460151, 30.378755], [50.460253, 30.378693], [50.460336, 30.378584], [50.460405, 30.378462], [50.460617, 30.377959], [50.460833, 30.377471], [50.460888, 30.377366], [50.461006, 30.377121], [50.461172, 30.376778], [50.461247, 30.376622], [50.461413, 30.376277], [50.46179, 30.375487], [50.461809, 30.375446], [50.461856, 30.375347], [50.461912, 30.375224], [50.462115, 30.37482], [50.462331, 30.374376], [50.462502, 30.374017], [50.462714, 30.373585], [50.462913, 30.373171], [50.463028, 30.372939], [50.463113, 30.37277], [50.463169, 30.372658], [50.463499, 30.37199], [50.463553, 30.37188], [50.463734, 30.371504], [50.464502, 30.36991], [50.4649, 30.369088], [50.465236, 30.368395], [50.46546, 30.367922], [50.465508, 30.367828], [50.465709, 30.367386], [50.465807, 30.367171], [50.465836, 30.367071], [50.465845, 30.366956], [50.465842, 30.366908], [50.465832, 30.366649], [50.465778, 30.365406], [50.46564, 30.363472], [50.465636, 30.363415], [50.465631, 30.363359], [50.465576, 30.362631], [50.465573, 30.362573], [50.46556, 30.362359], [50.465537, 30.36195], [50.465536, 30.361931], [50.465533, 30.361884], [50.465512, 30.361518], [50.465481, 30.360986], [50.465371, 30.359451], [50.465256, 30.357738], [50.465231, 30.357386], [50.465195, 30.356909], [50.465178, 30.356654], [50.465156, 30.356299], [50.465138, 30.356008], [50.465132, 30.355918], [50.465129, 30.355866], [50.465118, 30.355696], [50.465481, 30.355679], [50.465759, 30.355676], [50.466028, 30.355679], [50.46621, 30.355681], [50.466395, 30.355683], [50.466591, 30.355697], [50.466632, 30.355698], [50.4668, 30.355705], [50.467087, 30.355725], [50.467675, 30.35581], [50.467997, 30.355859], [50.468333, 30.355917], [50.468623, 30.355976], [50.468803, 30.35602], [50.46909, 30.356087], [50.469394, 30.356162], [50.469892, 30.3563], [50.470639, 30.356545], [50.470782, 30.356596], [50.470824, 30.356609], [50.47095, 30.356657], [50.470984, 30.356433], [50.471001, 30.356285], [50.471031, 30.355769], [50.471064, 30.355212], [50.471156, 30.353392], [50.471164, 30.353269], [50.471184, 30.352828], [50.471208, 30.352414], [50.471275, 30.351212], [50.471341, 30.350038], [50.471354, 30.349801], [50.471363, 30.349549], [50.471411, 30.348665], [50.471449, 30.347945], [50.471509, 30.346811], [50.471525, 30.346535], [50.471531, 30.346385], [50.471583, 30.345249], [50.471575, 30.344906], [50.471563, 30.344716], [50.471477, 30.343475], [50.471458, 30.343191], [50.471395, 30.342237], [50.471362, 30.341785], [50.47129, 30.340765], [50.471174, 30.338924], [50.4713, 30.338905], [50.471376, 30.338894], [50.471438, 30.33888], [50.471997, 30.338781], [50.472095, 30.338764], [50.472161, 30.338752], [50.472677, 30.33866], [50.473134, 30.338579], [50.473678, 30.338483], [50.473823, 30.338457], [50.473963, 30.338432], [50.473943, 30.3382], [50.473912, 30.33774], [50.473893, 30.337201], [50.473883, 30.336747], [50.473886, 30.336385], [50.473908, 30.335448], [50.473911, 30.335274], [50.473924, 30.334591], [50.473915, 30.334292], [50.473877, 30.333864], [50.473827, 30.333571], [50.473768, 30.333326], [50.47375, 30.333256], [50.473722, 30.333169], [50.473676, 30.333024], [50.473636, 30.332897], [50.473492, 30.332507], [50.473346, 30.332204], [50.47321, 30.331978], [50.473136, 30.331864], [50.473016, 30.331682], [50.472842, 30.331542], [50.472705, 30.331439], [50.472497, 30.331289], [50.471278, 30.330496], [50.470808, 30.330191]], "routeDbId": 20, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0432\\u0443\\u043b \\u041e\\u043b\\u0435\\u0433\\u0430 \\u041c\\u0443\\u0434\\u0440\\u0430\\u043a\\u0430 66 ", "delivery_window_end": "17:30", "delivery_window_start": "16:00", "driveMin": 21, "eta": "16:00", "id": 160, "lat": 50.4709648, "lng": 30.3295964, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}], "totalDistanceKm": 13.67, "totalDriveMin": 21}]}	2026-04-25 11:16:05.281552	15:39:00
38	7	2026-04-26	accepted	\N	2	26.43	45	\N	\N	\N	\N	2026-04-25 13:09:30.648316	2026-04-25 17:34:05.383132	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 6, "totalDeliveries": 15, "totalDistanceKm": 106.93, "totalDriveMin": 188}, "_selectedDate": "2026-04-26", "_fromDistribute": true, "routes": [{"courierId": "route_38", "courierName": "\\u0423\\u043a\\u043b\\u043e\\u043d", "departureAdjusted": false, "departureTime": "15:32", "geometry": [[50.473297, 30.482599], [50.47286, 30.48312], [50.472523, 30.483521], [50.471796, 30.484387], [50.471599, 30.484617], [50.4715, 30.484745], [50.471425, 30.484739], [50.471143, 30.48472], [50.470095, 30.484633], [50.470074, 30.485231], [50.470033, 30.48643], [50.470027, 30.486516], [50.470025, 30.486587], [50.469998, 30.48732], [50.469961, 30.488342], [50.469955, 30.488525], [50.469939, 30.488528], [50.469924, 30.488539], [50.469912, 30.488556], [50.469904, 30.488578], [50.4699, 30.488603], [50.469901, 30.488628], [50.469906, 30.488652], [50.469916, 30.488672], [50.469929, 30.488686], [50.469944, 30.488695], [50.46996, 30.488696], [50.469975, 30.488689], [50.469989, 30.488676], [50.47, 30.488658], [50.470055, 30.488685], [50.470116, 30.488759], [50.470157, 30.48886], [50.470178, 30.488986], [50.470183, 30.489094], [50.470173, 30.489204], [50.470148, 30.48928], [50.470131, 30.489313], [50.469983, 30.489538], [50.469693, 30.489976], [50.469519, 30.49023], [50.469093, 30.490854], [50.469005, 30.490962], [50.468684, 30.491358], [50.468518, 30.491521], [50.468466, 30.491564], [50.468326, 30.49168], [50.467453, 30.492653], [50.46734, 30.492759], [50.466968, 30.493005], [50.46686, 30.493079], [50.466721, 30.493204], [50.466673, 30.493266], [50.466628, 30.493342], [50.466589, 30.493417], [50.466398, 30.493981], [50.466269, 30.494374], [50.466232, 30.494536], [50.466231, 30.494652], [50.466236, 30.494746], [50.466252, 30.494887], [50.46646, 30.495818], [50.466496, 30.495933], [50.466555, 30.496042], [50.466649, 30.496144], [50.467004, 30.496511], [50.467121, 30.496646], [50.467492, 30.497227], [50.467664, 30.497546], [50.467778, 30.49795], [50.467846, 30.498385], [50.467892, 30.498903], [50.467902, 30.499445], [50.467904, 30.499523], [50.46792, 30.500531], [50.46795, 30.500671], [50.468031, 30.500767], [50.46809, 30.500836], [50.46816, 30.500914], [50.468366, 30.501162], [50.468413, 30.501219], [50.468651, 30.501551], [50.469436, 30.502746], [50.469542, 30.502894], [50.469586, 30.502956], [50.46966, 30.50306], [50.469668, 30.503071], [50.469725, 30.503151], [50.469769, 30.503213], [50.469986, 30.503548], [50.470066, 30.50367], [50.470398, 30.504156], [50.470439, 30.504215], [50.470674, 30.50454], [50.470875, 30.504825], [50.471008, 30.505015], [50.471039, 30.505059], [50.471108, 30.505164], [50.471171, 30.505259], [50.471194, 30.505293], [50.471353, 30.505527], [50.47148, 30.505713], [50.471806, 30.506192], [50.47217, 30.506726], [50.472182, 30.506743], [50.472235, 30.506821], [50.472292, 30.506905], [50.472322, 30.506946], [50.472718, 30.507516], [50.473328, 30.508395], [50.473415, 30.508462], [50.473457, 30.508476], [50.473484, 30.50848], [50.47382, 30.508489], [50.473875, 30.50849], [50.473964, 30.508497], [50.473964, 30.508647], [50.473962, 30.508872], [50.473949, 30.510241], [50.473948, 30.510363], [50.473947, 30.510476], [50.473946, 30.510679], [50.473944, 30.511623], [50.473943, 30.511781], [50.473942, 30.511841], [50.473943, 30.511925], [50.473943, 30.511965], [50.473939, 30.512747], [50.473938, 30.512929], [50.473931, 30.51351], [50.47393, 30.513599], [50.47393, 30.513743], [50.473929, 30.514686], [50.473931, 30.516334], [50.473931, 30.516419], [50.473931, 30.516552], [50.473541, 30.517173], [50.473483, 30.517265], [50.472504, 30.518828], [50.47172, 30.520061], [50.471678, 30.520129], [50.471607, 30.520242], [50.471376, 30.520614], [50.471125, 30.521017], [50.470665, 30.521747], [50.470557, 30.521918], [50.469785, 30.523143], [50.469745, 30.523207], [50.469673, 30.523325], [50.469438, 30.523704], [50.469345, 30.523839], [50.469264, 30.523941], [50.469202, 30.52399], [50.469111, 30.52404], [50.4681, 30.524345], [50.467316, 30.524573], [50.467131, 30.524622], [50.466357, 30.524812], [50.465294, 30.525038], [50.464562, 30.525193], [50.463845, 30.525335], [50.463195, 30.525465], [50.46142, 30.525848], [50.460793, 30.525965], [50.460654, 30.525991], [50.46057, 30.526006], [50.459913, 30.526113], [50.459782, 30.526135], [50.45962, 30.526162], [50.459192, 30.526297], [50.458943, 30.526397], [50.458736, 30.526508], [50.458558, 30.526677], [50.458453, 30.526804], [50.458351, 30.526957], [50.458133, 30.527328], [50.45684, 30.529597], [50.456365, 30.530444], [50.456107, 30.530906], [50.455975, 30.531161], [50.45588, 30.531353], [50.455727, 30.531696], [50.455522, 30.532181], [50.455353, 30.532586], [50.455061, 30.533306], [50.454859, 30.533794], [50.454592, 30.534464], [50.454246, 30.535349], [50.453996, 30.53598], [50.453717, 30.536706], [50.453336, 30.537682], [50.452824, 30.539007], [50.452443, 30.53999], [50.452163, 30.540683], [50.45189, 30.541369], [50.451656, 30.541915], [50.451167, 30.543003], [50.451017, 30.543339], [50.450594, 30.544222], [50.450027, 30.545358], [50.449361, 30.546691], [50.44869, 30.54803], [50.448104, 30.5492], [50.44753, 30.550346], [50.447054, 30.551305], [50.446745, 30.551909], [50.446524, 30.552318], [50.446282, 30.552728], [50.446035, 30.553125], [50.445763, 30.553529], [50.444956, 30.554661], [50.444462, 30.555335], [50.44368, 30.556395], [50.443341, 30.55682], [50.443021, 30.557226], [50.442426, 30.55791], [50.44185, 30.558546], [50.441293, 30.559131], [50.441103, 30.559308], [50.440897, 30.559481], [50.439562, 30.560635], [50.438947, 30.561244], [50.438553, 30.561617], [50.437742, 30.562427], [50.436969, 30.563192], [50.436539, 30.563577], [50.436239, 30.563798], [50.435958, 30.563981], [50.435754, 30.564095], [50.435241, 30.564333], [50.434247, 30.564804], [50.433006, 30.565402], [50.432404, 30.56568], [50.431899, 30.565855], [50.430356, 30.566451], [50.429431, 30.566805], [50.429087, 30.566933], [50.428554, 30.567122], [50.428244, 30.567223], [50.427823, 30.567384], [50.427448, 30.567524], [50.427256, 30.567594], [50.426707, 30.567815], [50.426312, 30.567959], [50.426025, 30.568066], [50.425605, 30.568198], [50.425489, 30.568236], [50.425159, 30.568342], [50.424898, 30.568392], [50.424797, 30.56836], [50.424673, 30.568361], [50.424475, 30.568371], [50.424378, 30.568344], [50.424285, 30.568264], [50.424212, 30.568133], [50.424184, 30.568024], [50.424163, 30.567861], [50.424141, 30.567686], [50.42412, 30.567491], [50.424097, 30.567343], [50.424081, 30.567244], [50.424047, 30.567133], [50.424006, 30.567046], [50.423952, 30.566979], [50.423859, 30.566894], [50.423766, 30.566883], [50.423675, 30.566888], [50.423603, 30.566901], [50.423528, 30.566927], [50.423415, 30.567021], [50.423314, 30.567132], [50.423194, 30.567315], [50.423069, 30.567544], [50.422974, 30.567769], [50.422929, 30.567946], [50.422896, 30.568129], [50.42289, 30.568326], [50.42291, 30.569098], [50.422915, 30.569218], [50.422926, 30.569395], [50.422937, 30.56948], [50.422957, 30.56957], [50.423048, 30.569798], [50.423203, 30.570064], [50.423293, 30.570236], [50.423619, 30.570704], [50.423829, 30.571015], [50.423997, 30.571277], [50.42411, 30.571472], [50.424268, 30.571979], [50.424332, 30.572185], [50.424838, 30.573898], [50.427871, 30.584227], [50.430154, 30.59198], [50.430193, 30.592118], [50.43049, 30.593037], [50.43065, 30.593496], [50.43079, 30.593836], [50.4312, 30.594803], [50.431357, 30.595175], [50.433468, 30.600116], [50.435466, 30.604908], [50.435973, 30.606111], [50.436143, 30.606515], [50.436581, 30.607553], [50.436812, 30.608102], [50.437026, 30.608669], [50.437083, 30.608835], [50.437763, 30.610822], [50.438075, 30.611827], [50.438459, 30.613057], [50.438963, 30.614735], [50.439067, 30.615057], [50.439109, 30.615191], [50.439083, 30.615355], [50.439077, 30.615392], [50.439065, 30.615441], [50.439034, 30.615549], [50.439019, 30.615587], [50.438967, 30.615723], [50.438953, 30.615734], [50.438926, 30.61573], [50.438884, 30.615728], [50.43886, 30.615726], [50.438837, 30.615712], [50.438786, 30.615652], [50.438741, 30.615537], [50.438734, 30.615521], [50.438649, 30.615313], [50.438208, 30.614189], [50.438107, 30.613859], [50.43806, 30.613639], [50.437996, 30.613277], [50.437969, 30.613109], [50.437852, 30.613205], [50.437224, 30.613584], [50.436717, 30.613894], [50.435909, 30.61439], [50.435768, 30.614474], [50.435262, 30.614773], [50.434613, 30.615163], [50.434635, 30.615252], [50.434761, 30.61573], [50.434761, 30.615777], [50.434774, 30.615826], [50.434778, 30.615841], [50.434785, 30.615864], [50.434808, 30.615889], [50.43483, 30.615964], [50.434947, 30.615884], [50.434999, 30.615848], [50.435058, 30.615806], [50.435743, 30.615325], [50.435773, 30.615428], [50.435846, 30.615673], [50.436161, 30.615457], [50.436607, 30.615138], [50.436656, 30.615103], [50.436962, 30.616149], [50.437001, 30.616326], [50.437019, 30.616475], [50.437044, 30.61694], [50.437049, 30.61704], [50.436997, 30.617074], [50.436699, 30.617276], [50.436811, 30.617308], [50.436824, 30.617312], [50.436872, 30.617374], [50.436913, 30.617396], [50.436936, 30.617405], [50.437002, 30.617404], [50.437036, 30.61742], [50.437084, 30.617442], [50.437107, 30.617451], [50.437144, 30.617453], [50.437183, 30.617449], [50.437243, 30.617476], [50.437254, 30.617434], [50.437274, 30.617373], [50.437319, 30.61731], [50.437387, 30.617253], [50.437777, 30.616985], [50.437848, 30.616937], [50.437933, 30.61688], [50.43821, 30.616694], [50.438432, 30.616551], [50.438763, 30.616334], [50.438867, 30.616269], [50.438912, 30.616223], [50.438986, 30.616122], [50.439012, 30.616093], [50.439038, 30.616071], [50.439073, 30.616048], [50.439099, 30.616013], [50.439118, 30.615967], [50.439127, 30.615915], [50.439127, 30.61586], [50.439116, 30.615809], [50.439095, 30.615764], [50.439068, 30.615732], [50.439035, 30.615713], [50.439, 30.61571], [50.438967, 30.615723], [50.438953, 30.615734], [50.438926, 30.61573], [50.438884, 30.615728], [50.43886, 30.615726], [50.438837, 30.615712], [50.438786, 30.615652], [50.438741, 30.615537], [50.438734, 30.615521], [50.438649, 30.615313], [50.438208, 30.614189], [50.438107, 30.613859], [50.43806, 30.613639], [50.437996, 30.613277], [50.437969, 30.613109], [50.437996, 30.612994], [50.438036, 30.6129], [50.438075, 30.612835], [50.438107, 30.612799], [50.438156, 30.612756], [50.438541, 30.612534], [50.438606, 30.612505], [50.438677, 30.612487], [50.438757, 30.612491], [50.438842, 30.612534], [50.438935, 30.612612], [50.439016, 30.612705], [50.43906, 30.612767], [50.439088, 30.612828], [50.439127, 30.612951], [50.439304, 30.613855], [50.439465, 30.61467], [50.43948, 30.614747], [50.439481, 30.614874], [50.439464, 30.614949], [50.439432, 30.614994], [50.439397, 30.61502], [50.439354, 30.615019], [50.439313, 30.614987], [50.439264, 30.614907], [50.439112, 30.614412], [50.439003, 30.614045], [50.438938, 30.613875], [50.438878, 30.613745], [50.4388, 30.613616], [50.438688, 30.61345], [50.438538, 30.612995], [50.438169, 30.611746], [50.437824, 30.610622], [50.437804, 30.610561], [50.437439, 30.609479], [50.437248, 30.608933], [50.436723, 30.607539], [50.435996, 30.60582], [50.435361, 30.604319], [50.433912, 30.600926], [50.432332, 30.597218], [50.431855, 30.596086], [50.431333, 30.594849], [50.430903, 30.593841], [50.430774, 30.593523], [50.430686, 30.593296], [50.430262, 30.592086], [50.430202, 30.591882], [50.428466, 30.585893], [50.427956, 30.584167], [50.424909, 30.573842], [50.424404, 30.572121], [50.424275, 30.571692], [50.424231, 30.571252], [50.424232, 30.571079], [50.424249, 30.570821], [50.424313, 30.570461], [50.424415, 30.570019], [50.424462, 30.569815], [50.424536, 30.56952], [50.424579, 30.569371], [50.424637, 30.569157], [50.42471, 30.569035], [50.424796, 30.568916], [50.424921, 30.568841], [50.425905, 30.568458], [50.42614, 30.568332], [50.426357, 30.568198], [50.426666, 30.568029], [50.426726, 30.568009], [50.427111, 30.567854], [50.427469, 30.567728], [50.428272, 30.567429], [50.428565, 30.567323], [50.42864, 30.567296], [50.429092, 30.56714], [50.429425, 30.567012], [50.430026, 30.566782], [50.430588, 30.566569], [50.431213, 30.566331], [50.431485, 30.566351], [50.432674, 30.566103], [50.433137, 30.566034], [50.433266, 30.565999], [50.433367, 30.565959], [50.433529, 30.56584], [50.433712, 30.565625], [50.433891, 30.565381], [50.434578, 30.564059], [50.434681, 30.563911], [50.435234, 30.563344], [50.435442, 30.563137], [50.435545, 30.563024], [50.435581, 30.562973], [50.435597, 30.562953], [50.435828, 30.562658], [50.43597, 30.562456], [50.436043, 30.562387], [50.436188, 30.56227], [50.436364, 30.56215], [50.436594, 30.561982], [50.436809, 30.561798], [50.437742, 30.560678], [50.438439, 30.559886], [50.439532, 30.558557], [50.440026, 30.557799], [50.440719, 30.556747], [50.441076, 30.556212], [50.441521, 30.555537], [50.442163, 30.554562], [50.442322, 30.554318], [50.44249, 30.554054], [50.442634, 30.553828], [50.442721, 30.553653], [50.442811, 30.553428], [50.442972, 30.552956], [50.443115, 30.552534], [50.44321, 30.552235], [50.443334, 30.551844], [50.443397, 30.551616], [50.443462, 30.551359], [50.443562, 30.550997], [50.443636, 30.550673], [50.443772, 30.549842], [50.443819, 30.549626], [50.443886, 30.54939], [50.444011, 30.549093], [50.444094, 30.54893], [50.444211, 30.548767], [50.444345, 30.548594], [50.444792, 30.548149], [50.444931, 30.547989], [50.445217, 30.547581], [50.445511, 30.547149], [50.445911, 30.546593], [50.446103, 30.546139], [50.446387, 30.545334], [50.446822, 30.544138], [50.44716, 30.543205], [50.447247, 30.543057], [50.447395, 30.542866], [50.447499, 30.542771], [50.447628, 30.542664], [50.448043, 30.542303], [50.448078, 30.542234], [50.448141, 30.542115], [50.448512, 30.541178], [50.448585, 30.540976], [50.448739, 30.540596], [50.448759, 30.540547], [50.448765, 30.540531], [50.448794, 30.540464], [50.448924, 30.540165], [50.449047, 30.539925], [50.449092, 30.539864], [50.449196, 30.539758], [50.449344, 30.539658], [50.449748, 30.539412], [50.449941, 30.539274], [50.450059, 30.539154], [50.450437, 30.538614], [50.450968, 30.537737], [50.451, 30.537678], [50.451374, 30.536992], [50.452206, 30.535465], [50.452373, 30.535159], [50.452434, 30.534917], [50.452431, 30.534657], [50.452372, 30.534403], [50.452328, 30.53428], [50.452039, 30.53343], [50.451516, 30.531785], [50.450869, 30.529779], [50.450846, 30.529703], [50.450736, 30.529372], [50.451056, 30.529047], [50.451913, 30.528246], [50.452331, 30.527819], [50.452361, 30.527778], [50.452384, 30.527728], [50.4524, 30.527671], [50.452415, 30.527603], [50.452423, 30.527472], [50.452418, 30.527338], [50.452401, 30.527205], [50.451972, 30.526617], [50.451742, 30.526302], [50.451594, 30.526101], [50.451307, 30.525711], [50.451053, 30.525366], [50.450572, 30.524713], [50.450416, 30.524501], [50.450385, 30.524458]], "routeDbId": 38, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0421\\u043e\\u0431\\u043e\\u0440\\u043d\\u043e\\u0441\\u0442\\u0456 17\\u043a2 ", "delivery_window_end": "17:30", "delivery_window_start": "16:00", "driveMin": 28, "eta": "16:00", "id": 181, "lat": 50.4351785, "lng": 30.6162293, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432,  ", "delivery_window_end": "17:30", "delivery_window_start": "16:30", "driveMin": 17, "eta": "16:32", "id": 128, "lat": 50.4503596, "lng": 30.5245025, "serviceMin": 15, "stopOrder": 2, "waitMin": 0}], "totalDistanceKm": 26.43, "totalDriveMin": 45}]}	2026-04-25 17:34:05.382326	15:32:00
12	3	2026-04-25	completed	2000	8	31.42	55	314	2026-04-24 16:58:20.693256	2026-04-24 17:18:36.784949	\N	2026-04-24 14:34:14.319932	2026-04-25 11:16:05.293172	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 10, "totalDeliveries": 29, "totalDistanceKm": 178.72, "totalDriveMin": 301}, "_selectedDate": "2026-04-25", "_fromDistribute": true, "routes": [{"courierId": "route_12", "courierName": "\\u0420\\u043e\\u043c\\u0430\\u043d (\\u0447\\u043e\\u043b\\u043e\\u0432\\u0456\\u043a \\u0406\\u0440\\u0438\\u043d\\u0438)", "departureAdjusted": false, "departureTime": "09:00", "geometry": [[50.473297, 30.482599], [50.47286, 30.48312], [50.472523, 30.483521], [50.471796, 30.484387], [50.471599, 30.484617], [50.4715, 30.484745], [50.471425, 30.484739], [50.471143, 30.48472], [50.470095, 30.484633], [50.470074, 30.485231], [50.470033, 30.48643], [50.470027, 30.486516], [50.470025, 30.486587], [50.469998, 30.48732], [50.469961, 30.488342], [50.469955, 30.488525], [50.469939, 30.488528], [50.469924, 30.488539], [50.469912, 30.488556], [50.469904, 30.488578], [50.4699, 30.488603], [50.469901, 30.488628], [50.469906, 30.488652], [50.469916, 30.488672], [50.469929, 30.488686], [50.469944, 30.488695], [50.46996, 30.488696], [50.469975, 30.488689], [50.469989, 30.488676], [50.47, 30.488658], [50.470055, 30.488685], [50.470116, 30.488759], [50.470157, 30.48886], [50.470178, 30.488986], [50.470183, 30.489094], [50.470173, 30.489204], [50.470148, 30.48928], [50.470131, 30.489313], [50.469983, 30.489538], [50.469959, 30.489487], [50.469921, 30.489504], [50.469816, 30.489518], [50.469665, 30.489515], [50.469142, 30.4895], [50.468992, 30.489522], [50.468871, 30.489648], [50.468641, 30.489903], [50.468496, 30.489956], [50.468329, 30.489925], [50.467981, 30.489839], [50.467693, 30.48981], [50.467513, 30.489771], [50.467283, 30.489693], [50.467138, 30.489681], [50.466753, 30.489703], [50.466424, 30.489781], [50.466395, 30.48983], [50.466356, 30.490282], [50.46629, 30.490513], [50.466161, 30.490861], [50.466128, 30.490954], [50.466067, 30.490855], [50.465964, 30.490744], [50.465792, 30.490613], [50.4656, 30.490527], [50.465397, 30.490501], [50.465264, 30.490515], [50.465133, 30.490572], [50.464981, 30.49069], [50.463917, 30.491689], [50.463358, 30.492218], [50.463267, 30.492277], [50.46318, 30.492316], [50.463074, 30.492336], [50.46265, 30.492389], [50.462621, 30.492393], [50.462554, 30.492403], [50.462511, 30.492407], [50.462484, 30.492412], [50.462455, 30.492417], [50.462465, 30.492685], [50.462548, 30.494195], [50.462551, 30.494364], [50.462546, 30.494511], [50.462532, 30.494667], [50.46251, 30.4948], [50.462473, 30.49495], [50.462407, 30.495145], [50.462337, 30.49534], [50.462228, 30.495621], [50.46213, 30.495896], [50.462093, 30.496005], [50.462024, 30.495973], [50.46192, 30.495958], [50.461484, 30.495961], [50.461178, 30.495963], [50.461165, 30.495963], [50.460678, 30.495995], [50.460539, 30.496036], [50.46038, 30.496163], [50.459356, 30.496926], [50.459031, 30.497173], [50.458873, 30.497382], [50.458792, 30.497477], [50.458688, 30.497815], [50.458647, 30.497959], [50.458381, 30.498963], [50.458321, 30.499144], [50.458278, 30.499205], [50.457831, 30.499558], [50.457725, 30.499642], [50.457558, 30.499775], [50.457399, 30.499891], [50.457341, 30.49999], [50.457294, 30.500069], [50.457226, 30.500239], [50.45719, 30.500332], [50.457138, 30.500499], [50.457123, 30.500548], [50.457053, 30.500812], [50.45701, 30.501014], [50.456971, 30.501288], [50.456952, 30.501285], [50.456931, 30.501293], [50.456912, 30.501311], [50.456899, 30.501339], [50.456893, 30.501373], [50.456893, 30.501406], [50.456902, 30.501437], [50.456916, 30.501463], [50.456935, 30.501479], [50.456956, 30.501484], [50.456978, 30.50148], [50.456998, 30.501464], [50.45701, 30.501435], [50.457052, 30.50147], [50.457102, 30.501491], [50.45714, 30.501487], [50.45722, 30.501436], [50.457276, 30.501397], [50.45752, 30.501226], [50.4579, 30.500941], [50.458167, 30.500803], [50.458195, 30.500788], [50.458425, 30.500671], [50.45879, 30.500479], [50.459001, 30.500369], [50.459144, 30.500902], [50.459178, 30.500993], [50.459474, 30.501779], [50.458922, 30.502898], [50.45884, 30.503065], [50.458811, 30.503169], [50.458795, 30.503515], [50.458562, 30.503966], [50.458524, 30.504042], [50.458501, 30.504012], [50.458453, 30.503951], [50.458368, 30.503843], [50.458368, 30.503843], [50.458453, 30.503951], [50.458501, 30.504012], [50.458524, 30.504042], [50.458562, 30.503966], [50.458795, 30.503515], [50.458811, 30.503169], [50.45884, 30.503065], [50.458922, 30.502898], [50.459474, 30.501779], [50.459178, 30.500993], [50.459144, 30.500902], [50.459001, 30.500369], [50.45879, 30.500479], [50.458425, 30.500671], [50.458195, 30.500788], [50.458167, 30.500803], [50.4579, 30.500941], [50.45752, 30.501226], [50.457276, 30.501397], [50.45722, 30.501436], [50.45714, 30.501487], [50.457102, 30.501491], [50.457052, 30.50147], [50.45701, 30.501435], [50.457018, 30.501403], [50.457019, 30.501373], [50.457014, 30.501344], [50.457003, 30.501319], [50.456989, 30.5013], [50.456971, 30.501288], [50.456952, 30.501285], [50.456931, 30.501293], [50.456912, 30.501311], [50.456899, 30.501339], [50.456893, 30.501373], [50.456832, 30.501408], [50.456793, 30.501409], [50.456547, 30.50124], [50.456506, 30.501232], [50.456469, 30.501227], [50.456487, 30.501842], [50.456481, 30.501931], [50.456471, 30.502017], [50.456439, 30.502152], [50.45639, 30.502339], [50.456367, 30.502424], [50.456362, 30.502441], [50.455879, 30.504217], [50.455874, 30.504237], [50.45585, 30.504323], [50.455723, 30.50478], [50.455708, 30.504838], [50.455519, 30.505547], [50.455442, 30.505849], [50.455381, 30.506156], [50.45529, 30.506107], [50.454919, 30.505876], [50.454698, 30.505719], [50.454654, 30.505635], [50.454363, 30.505914], [50.45428, 30.506002], [50.454245, 30.506034], [50.454116, 30.506149], [50.454015, 30.506267], [50.453902, 30.506402], [50.453455, 30.506953], [50.453355, 30.507076], [50.453297, 30.507149], [50.453134, 30.507352], [50.453098, 30.507396], [50.453042, 30.507463], [50.452656, 30.507946], [50.452502, 30.508138], [50.452193, 30.508522], [50.452144, 30.508584], [50.452118, 30.508616], [50.452023, 30.508735], [50.451709, 30.509136], [50.451571, 30.50931], [50.451354, 30.509586], [50.451173, 30.50981], [50.451117, 30.509879], [50.451066, 30.509943], [50.450773, 30.510314], [50.450725, 30.510374], [50.450641, 30.510496], [50.450624, 30.510521], [50.450361, 30.510849], [50.450168, 30.511091], [50.450102, 30.511174], [50.449877, 30.511455], [50.449745, 30.511619], [50.449594, 30.511808], [50.449557, 30.511855], [50.449539, 30.511876], [50.449491, 30.511937], [50.449427, 30.512021], [50.449362, 30.512136], [50.449313, 30.512254], [50.449295, 30.512363], [50.44926, 30.512582], [50.449164, 30.512545], [50.448823, 30.512417], [50.448738, 30.512385], [50.448427, 30.512263], [50.448036, 30.512113], [50.447744, 30.512], [50.44727, 30.511819], [50.447212, 30.511796], [50.446534, 30.511536], [50.446489, 30.51152], [50.446346, 30.511464], [50.446317, 30.511646], [50.446279, 30.511886], [50.44627, 30.511943], [50.44616, 30.512631], [50.446149, 30.512699], [50.446147, 30.512714], [50.446066, 30.513215], [50.446037, 30.513398], [50.446005, 30.513588], [50.445949, 30.513933], [50.44586, 30.51448], [50.445627, 30.515917], [50.445506, 30.515869], [50.445051, 30.515691], [50.444843, 30.515608], [50.444621, 30.515519], [50.444496, 30.515469], [50.444147, 30.51533], [50.443772, 30.515179], [50.443439, 30.515045], [50.443388, 30.515025], [50.443294, 30.515], [50.443055, 30.514936], [50.443004, 30.514916], [50.442626, 30.514765], [50.442273, 30.514624], [50.44213, 30.514568], [50.441736, 30.514411], [50.441559, 30.51434], [50.441515, 30.514323], [50.44147, 30.514305], [50.440939, 30.514093], [50.440626, 30.513953], [50.44048, 30.513889], [50.440075, 30.51373], [50.43995, 30.513601], [50.439815, 30.513531], [50.438867, 30.51353], [50.438577, 30.513531], [50.438266, 30.513531], [50.438059, 30.513531], [50.437853, 30.513531], [50.437623, 30.513531], [50.437328, 30.513532], [50.437261, 30.513532], [50.437208, 30.513532], [50.436731, 30.513533], [50.436134, 30.513524], [50.436094, 30.513543], [50.435962, 30.513616], [50.435851, 30.513616], [50.435517, 30.513613], [50.435296, 30.513612], [50.43512, 30.513611], [50.435044, 30.51361], [50.434914, 30.513609], [50.434713, 30.513608], [50.434534, 30.513607], [50.434132, 30.513594], [50.433992, 30.513591], [50.433886, 30.513589], [50.433303, 30.513577], [50.433208, 30.513576], [50.43318, 30.513575], [50.432911, 30.513572], [50.432107, 30.51356], [50.43203, 30.51356], [50.431889, 30.513558], [50.431855, 30.513558], [50.431428, 30.513557], [50.430749, 30.513546], [50.430059, 30.513533], [50.430005, 30.513532], [50.429908, 30.513536], [50.429793, 30.513555], [50.42965, 30.513558], [50.428082, 30.51361], [50.428027, 30.513615], [50.42791, 30.513636], [50.427863, 30.513644], [50.427745, 30.513698], [50.427114, 30.514091], [50.426593, 30.514415], [50.426541, 30.514447], [50.426491, 30.514478], [50.426215, 30.51465], [50.425828, 30.514891], [50.424711, 30.515585], [50.424568, 30.515672], [50.424485, 30.515728], [50.424233, 30.515896], [50.424063, 30.51601], [50.423556, 30.516327], [50.423362, 30.516455], [50.422556, 30.516973], [50.422498, 30.51701], [50.422436, 30.517051], [50.422493, 30.517236], [50.422611, 30.517627], [50.422793, 30.518222], [50.423051, 30.519046], [50.423097, 30.519196], [50.423148, 30.519374], [50.423439, 30.52041], [50.423685, 30.521263], [50.423737, 30.521471], [50.423683, 30.521504], [50.423251, 30.521777], [50.421735, 30.522731], [50.42166, 30.522778], [50.421187, 30.523091], [50.421095, 30.523152], [50.420418, 30.523558], [50.42035, 30.523599], [50.419799, 30.52393], [50.419721, 30.523978], [50.419761, 30.52412], [50.419944, 30.52481], [50.420266, 30.526022], [50.42031, 30.526188], [50.420331, 30.526271], [50.420352, 30.526351], [50.420394, 30.526512], [50.420731, 30.527807], [50.420806, 30.528081], [50.420837, 30.528236], [50.420861, 30.5284], [50.420883, 30.52895], [50.420884, 30.529213], [50.420894, 30.530074], [50.420846, 30.530068], [50.420254, 30.529934], [50.420213, 30.529924], [50.42017, 30.529915], [50.419891, 30.529852], [50.418824, 30.529609], [50.418797, 30.529603], [50.418782, 30.529545], [50.418676, 30.529127], [50.418532, 30.528562], [50.418272, 30.527544], [50.418253, 30.527472], [50.418214, 30.527317], [50.418144, 30.527042], [50.418057, 30.526704], [50.417994, 30.526459], [50.41796, 30.526321], [50.417884, 30.526023], [50.41772, 30.52538], [50.417695, 30.525282], [50.417675, 30.525206], [50.417529, 30.524634], [50.417357, 30.523957], [50.417174, 30.523242], [50.417116, 30.523016], [50.417065, 30.522821], [50.416657, 30.521267], [50.416584, 30.520989], [50.416562, 30.5209], [50.416538, 30.520802], [50.416449, 30.52086], [50.41613, 30.521064], [50.415987, 30.521154], [50.415852, 30.521242], [50.415383, 30.521554], [50.414705, 30.521995], [50.414627, 30.522047], [50.414484, 30.522145], [50.414012, 30.522436], [50.413869, 30.522535], [50.41384, 30.522565], [50.413642, 30.522782], [50.413591, 30.522845], [50.413353, 30.523154], [50.412919, 30.52371], [50.41242, 30.524326], [50.412318, 30.524445], [50.412252, 30.524519], [50.412106, 30.524713], [50.411925, 30.524932], [50.411298, 30.525691], [50.41128, 30.525712], [50.41115, 30.525878], [50.410278, 30.526923], [50.410167, 30.52701], [50.410053, 30.527073], [50.409938, 30.527113], [50.409822, 30.527133], [50.409707, 30.527123], [50.409602, 30.527075], [50.409512, 30.526992], [50.409433, 30.526882], [50.409367, 30.526753], [50.409313, 30.526612], [50.409283, 30.526457], [50.409277, 30.526302], [50.409288, 30.526152], [50.409318, 30.526005], [50.409363, 30.525868], [50.40942, 30.525753], [50.409487, 30.525662], [50.409562, 30.52559], [50.409643, 30.525538], [50.409725, 30.525508], [50.409807, 30.525498], [50.409888, 30.525507], [50.40997, 30.525533], [50.410048, 30.525566], [50.410122, 30.525626], [50.410197, 30.525698], [50.410327, 30.525819], [50.410479, 30.526153], [50.410637, 30.526515], [50.410737, 30.52673], [50.410841, 30.526973], [50.411031, 30.527412], [50.411297, 30.528113], [50.411509, 30.528673], [50.41164, 30.529033], [50.411832, 30.529578], [50.411734, 30.529656], [50.411514, 30.529813], [50.411545, 30.529935], [50.411608, 30.530233], [50.411622, 30.530279], [50.411769, 30.53077], [50.41184, 30.531015], [50.411863, 30.531093], [50.411881, 30.531154], [50.411863, 30.531093], [50.41184, 30.531015], [50.411769, 30.53077], [50.411684, 30.530487], [50.411622, 30.530279], [50.411608, 30.530233], [50.411545, 30.529935], [50.411514, 30.529813], [50.411734, 30.529656], [50.411832, 30.529578], [50.412028, 30.530157], [50.412171, 30.530577], [50.412274, 30.530882], [50.412378, 30.531207], [50.412654, 30.532136], [50.412843, 30.532749], [50.413035, 30.533409], [50.413347, 30.534439], [50.413649, 30.53535], [50.413967, 30.536259], [50.414281, 30.537068], [50.414465, 30.537517], [50.414603, 30.537837], [50.414651, 30.537952], [50.414867, 30.538471], [50.41527, 30.539331], [50.415577, 30.539971], [50.416472, 30.541775], [50.416805, 30.542422], [50.416707, 30.542545], [50.416534, 30.542763], [50.416023, 30.54343], [50.41595, 30.543526], [50.415902, 30.543588], [50.415811, 30.543713], [50.415721, 30.543839], [50.415602, 30.544027], [50.415578, 30.544066], [50.415577, 30.544136], [50.415579, 30.544335], [50.415582, 30.544892], [50.415582, 30.545043], [50.415584, 30.545486], [50.415585, 30.545792], [50.415585, 30.545824], [50.415585, 30.545869], [50.415586, 30.546033], [50.415587, 30.546342], [50.415509, 30.546344], [50.414893, 30.54633], [50.414664, 30.546317], [50.414147, 30.546304], [50.414065, 30.546302], [50.413958, 30.546298], [50.413247, 30.546282], [50.413127, 30.54628], [50.412988, 30.546273], [50.412344, 30.546245], [50.412246, 30.546241], [50.412124, 30.546236], [50.411744, 30.546223], [50.411674, 30.546198], [50.411615, 30.546187], [50.411506, 30.546186], [50.411469, 30.546179], [50.41146, 30.546177], [50.41142, 30.546161], [50.411398, 30.546144], [50.411373, 30.54614], [50.411375, 30.5461], [50.41138, 30.545953], [50.4114, 30.545367], [50.411403, 30.545279], [50.41141, 30.544731], [50.411412, 30.544575], [50.411418, 30.544005], [50.411431, 30.543956], [50.411453, 30.543923], [50.411491, 30.543902], [50.411733, 30.543883], [50.411886, 30.543879], [50.41217, 30.543871], [50.412587, 30.54386], [50.413272, 30.543866], [50.413321, 30.543837], [50.41338, 30.543802], [50.413422, 30.543801], [50.413605, 30.543809], [50.4137, 30.543874], [50.413753, 30.543874], [50.414121, 30.543881], [50.414698, 30.543902], [50.415276, 30.543922], [50.415446, 30.543991], [50.415531, 30.544031], [50.415549, 30.544046], [50.415578, 30.544066], [50.415602, 30.544027], [50.415721, 30.543839], [50.415811, 30.543713], [50.415902, 30.543588], [50.41595, 30.543526], [50.416023, 30.54343], [50.416534, 30.542763], [50.416707, 30.542545], [50.416805, 30.542422], [50.417426, 30.543611], [50.417809, 30.544333], [50.418337, 30.545337], [50.418803, 30.546216], [50.419234, 30.547045], [50.420303, 30.549104], [50.420421, 30.549331], [50.420569, 30.549616], [50.420753, 30.549976], [50.421418, 30.551277], [50.421483, 30.551408], [50.421543, 30.551528], [50.421743, 30.551936], [50.421908, 30.552308], [50.421936, 30.552371], [50.422108, 30.552812], [50.42226, 30.553202], [50.422415, 30.553629], [50.422499, 30.553863], [50.422594, 30.55415], [50.42266, 30.554368], [50.422679, 30.554431], [50.422789, 30.554833], [50.422928, 30.55537], [50.423107, 30.55607], [50.423354, 30.557025], [50.423604, 30.557982], [50.423742, 30.5585], [50.424009, 30.559473], [50.424208, 30.560233], [50.42432, 30.560697], [50.424395, 30.561043], [50.424413, 30.561143], [50.424431, 30.561259], [50.424441, 30.561354], [50.424465, 30.561696], [50.424478, 30.561904], [50.424475, 30.562402], [50.424465, 30.562622], [50.424436, 30.562869], [50.424372, 30.563307], [50.424206, 30.564115], [50.4241, 30.564588], [50.423824, 30.565872], [50.423749, 30.566228], [50.423677, 30.566602], [50.423648, 30.566786], [50.423605, 30.567096], [50.423591, 30.567247], [50.423578, 30.567426], [50.423569, 30.56764], [50.423571, 30.567964], [50.423583, 30.568344], [50.423608, 30.568899], [50.423625, 30.569288], [50.423638, 30.569484], [50.423656, 30.56972], [50.42371, 30.570094], [50.423804, 30.570444], [50.423841, 30.57059], [50.423904, 30.570795], [50.42411, 30.571472], [50.424268, 30.571979], [50.424332, 30.572185], [50.424838, 30.573898], [50.427871, 30.584227], [50.430154, 30.59198], [50.430193, 30.592118], [50.43049, 30.593037], [50.43065, 30.593496], [50.43079, 30.593836], [50.4312, 30.594803], [50.431357, 30.595175], [50.433468, 30.600116], [50.435466, 30.604908], [50.435973, 30.606111], [50.436143, 30.606515], [50.436581, 30.607553], [50.436812, 30.608102], [50.437026, 30.608669], [50.437083, 30.608835], [50.437147, 30.609159], [50.437161, 30.609243], [50.437161, 30.609334], [50.437151, 30.60957], [50.437094, 30.610278], [50.437084, 30.610437], [50.437088, 30.610543], [50.437106, 30.610721], [50.437093, 30.611139], [50.437074, 30.611268], [50.437053, 30.611415], [50.436996, 30.611809], [50.436956, 30.61184], [50.436909, 30.611908], [50.43688, 30.611997], [50.436872, 30.612095], [50.436885, 30.612192], [50.436919, 30.612277], [50.436965, 30.612335], [50.437022, 30.612367], [50.437492, 30.612501], [50.437746, 30.612547], [50.437863, 30.61255], [50.438021, 30.612523], [50.43811, 30.612464], [50.438478, 30.612246], [50.438626, 30.612156], [50.438679, 30.612115], [50.438773, 30.611993], [50.438866, 30.611825], [50.438947, 30.611663], [50.439011, 30.611483], [50.439066, 30.611247], [50.439094, 30.611158], [50.439102, 30.611073], [50.439094, 30.610988], [50.43907, 30.610911], [50.439034, 30.610847], [50.438987, 30.610803], [50.438941, 30.610784], [50.438932, 30.610664], [50.438935, 30.610557], [50.438935, 30.610557], [50.438948, 30.610279], [50.439022, 30.610219], [50.439271, 30.610051], [50.439432, 30.610036], [50.440033, 30.609681], [50.440083, 30.609628], [50.440123, 30.609584], [50.440198, 30.609513], [50.440232, 30.609469], [50.440535, 30.610175], [50.440615, 30.610335], [50.440456, 30.610476], [50.440258, 30.610575], [50.440119, 30.610645], [50.43995, 30.610729], [50.439821, 30.610782], [50.439704, 30.610808], [50.439502, 30.610831], [50.438987, 30.610803], [50.438941, 30.610784], [50.438895, 30.610783], [50.438842, 30.610805], [50.438795, 30.610849], [50.438759, 30.610913], [50.438736, 30.610991], [50.438729, 30.611076], [50.438735, 30.611151], [50.438754, 30.611221], [50.438767, 30.611343], [50.438765, 30.61145], [50.438743, 30.61163], [50.438687, 30.61186], [50.43863, 30.612002], [50.438553, 30.612136], [50.438478, 30.612246], [50.43811, 30.612464], [50.438022, 30.612474], [50.437843, 30.612491], [50.437698, 30.612475], [50.43754, 30.612391], [50.437465, 30.61232], [50.437394, 30.612237], [50.437306, 30.61213], [50.437235, 30.612015], [50.437215, 30.611938], [50.437182, 30.611873], [50.437142, 30.611648], [50.437125, 30.611546], [50.437107, 30.61127], [50.437093, 30.611139], [50.437106, 30.610721], [50.437127, 30.610565], [50.437142, 30.610448], [50.43717, 30.61034], [50.437219, 30.610252], [50.437283, 30.610193], [50.437357, 30.61017], [50.43743, 30.610185], [50.437471, 30.610212], [50.43755, 30.61032], [50.437763, 30.610822], [50.438075, 30.611827], [50.438459, 30.613057], [50.438963, 30.614735], [50.439067, 30.615057], [50.439109, 30.615191], [50.439333, 30.615902], [50.440326, 30.619107], [50.440464, 30.619567], [50.44107, 30.621543], [50.441469, 30.622843], [50.441612, 30.623334], [50.441664, 30.623527], [50.441772, 30.623926], [50.44183, 30.624255], [50.441859, 30.624544], [50.441873, 30.624792], [50.441878, 30.625062], [50.441883, 30.625307], [50.44179, 30.625836], [50.441718, 30.626154], [50.441669, 30.626342], [50.441591, 30.626587], [50.44153, 30.626745], [50.441393, 30.627044], [50.44126, 30.627239], [50.440872, 30.62773], [50.44079, 30.627826], [50.440689, 30.627943], [50.440586, 30.628059], [50.440473, 30.628169], [50.440334, 30.628303], [50.440208, 30.628407], [50.437154, 30.630224], [50.434295, 30.631913], [50.433578, 30.632351], [50.433095, 30.63264], [50.432066, 30.633252], [50.43155, 30.633568], [50.43111, 30.63384], [50.430527, 30.634229], [50.429582, 30.634948], [50.428512, 30.635777], [50.427593, 30.636569], [50.427529, 30.636711], [50.427412, 30.636819], [50.42716, 30.637091], [50.427018, 30.637269], [50.42688, 30.637461], [50.426741, 30.637674], [50.426679, 30.637779], [50.426594, 30.637926], [50.426472, 30.63814], [50.426338, 30.638397], [50.426215, 30.638658], [50.426101, 30.638936], [50.425996, 30.639226], [50.425945, 30.63938], [50.425902, 30.639513], [50.425891, 30.639552], [50.425865, 30.639646], [50.425829, 30.639777], [50.42568, 30.63964], [50.425608, 30.639573], [50.42514, 30.63916], [50.424964, 30.639002], [50.424477, 30.638553], [50.424316, 30.638333], [50.42419, 30.638167], [50.423849, 30.637841], [50.423091, 30.637133], [50.422775, 30.63685], [50.421577, 30.635761], [50.421302, 30.635505], [50.4212, 30.635383], [50.421109, 30.635259], [50.421009, 30.635111], [50.420833, 30.634807], [50.420734, 30.634594], [50.42065, 30.634364], [50.420573, 30.634116], [50.420503, 30.633867], [50.42038, 30.633935], [50.420352, 30.633949], [50.419579, 30.634329], [50.419349, 30.634431], [50.418938, 30.63462], [50.418896, 30.634639], [50.417899, 30.635054], [50.417655, 30.635159], [50.417411, 30.635264], [50.416898, 30.635484], [50.416851, 30.635505], [50.416309, 30.635723], [50.416219, 30.63576], [50.416172, 30.635783], [50.415859, 30.635915], [50.415698, 30.635983], [50.414985, 30.636283], [50.414879, 30.636332], [50.414727, 30.636398], [50.414662, 30.636429], [50.41424, 30.636629], [50.413621, 30.63689], [50.413499, 30.636942], [50.412895, 30.637196], [50.412535, 30.637348], [50.412412, 30.6374], [50.41224, 30.637472], [50.411413, 30.637815], [50.411284, 30.637876], [50.411148, 30.637351], [50.41083, 30.636232], [50.410535, 30.63512], [50.410161, 30.633684], [50.410133, 30.633582], [50.4101, 30.633456], [50.40954, 30.631263], [50.409668, 30.631185], [50.4097, 30.63116], [50.409794, 30.631085], [50.40979, 30.6308], [50.409788, 30.630556], [50.409804, 30.630492], [50.409835, 30.630466], [50.410128, 30.630483], [50.410237, 30.630551], [50.410241, 30.630253], [50.410237, 30.630551], [50.410128, 30.630483], [50.409835, 30.630466], [50.409804, 30.630492], [50.409788, 30.630556], [50.40979, 30.6308], [50.40979, 30.630827], [50.409794, 30.631085], [50.4097, 30.63116], [50.409668, 30.631185], [50.40954, 30.631263], [50.409113, 30.629489], [50.40903, 30.629176], [50.408993, 30.628986], [50.408612, 30.627542], [50.408552, 30.627335], [50.408542, 30.6273], [50.408476, 30.627069], [50.408108, 30.625772], [50.407762, 30.62449], [50.407713, 30.624304], [50.407674, 30.624157], [50.407563, 30.623688], [50.40722, 30.622287], [50.407105, 30.621833], [50.407037, 30.621577], [50.406898, 30.621008], [50.406838, 30.620795], [50.40678, 30.620572], [50.406441, 30.619274], [50.406394, 30.619094], [50.40623, 30.618464], [50.406183, 30.618285], [50.406165, 30.618215], [50.405927, 30.617301], [50.405912, 30.617245], [50.405883, 30.617134], [50.40587, 30.617085], [50.405855, 30.617029], [50.405658, 30.616195], [50.405624, 30.616055], [50.405483, 30.615445], [50.405253, 30.614441], [50.405161, 30.614082], [50.405113, 30.61391], [50.405011, 30.613577], [50.404783, 30.613835], [50.404661, 30.613952], [50.404324, 30.614238], [50.404126, 30.614385], [50.403856, 30.614558], [50.403818, 30.61458], [50.403621, 30.614675], [50.403441, 30.614752], [50.403264, 30.614819], [50.403056, 30.614879], [50.402871, 30.61492], [50.402582, 30.614964], [50.401849, 30.615016], [50.401537, 30.615033], [50.401336, 30.615046], [50.401186, 30.615055], [50.400824, 30.615089], [50.400402, 30.615135], [50.400199, 30.615161], [50.399854, 30.615195], [50.398938, 30.615284], [50.398798, 30.615301], [50.398615, 30.615323], [50.398257, 30.615374], [50.397762, 30.615443], [50.397348, 30.615518], [50.396621, 30.615683], [50.396522, 30.616023], [50.396133, 30.616151], [50.394808, 30.616632], [50.394653, 30.616681], [50.393632, 30.616982], [50.393263, 30.617084], [50.393228, 30.616713], [50.393139, 30.61665], [50.393085, 30.616612], [50.393024, 30.616569], [50.392921, 30.616482], [50.392843, 30.616372], [50.392802, 30.61626], [50.392783, 30.616167], [50.392742, 30.616165], [50.39257, 30.615994], [50.392538, 30.615926], [50.392516, 30.615856], [50.392535, 30.615842], [50.392548, 30.615816], [50.392553, 30.615783], [50.392548, 30.615751], [50.392535, 30.615725], [50.392516, 30.615711], [50.392494, 30.615711], [50.392476, 30.615726], [50.392462, 30.615752], [50.392458, 30.615784], [50.392463, 30.615816], [50.392476, 30.615842], [50.392495, 30.615856], [50.392516, 30.615856], [50.392538, 30.615926], [50.39257, 30.615994], [50.392614, 30.616038], [50.392742, 30.616165], [50.392783, 30.616167], [50.392802, 30.61626], [50.392843, 30.616372], [50.392921, 30.616482], [50.393024, 30.616569], [50.393085, 30.616612], [50.393139, 30.61665], [50.393228, 30.616713], [50.393263, 30.617084], [50.393632, 30.616982], [50.394653, 30.616681], [50.394808, 30.616632], [50.396133, 30.616151], [50.396522, 30.616023], [50.396743, 30.616144], [50.396799, 30.616219], [50.39685, 30.616332], [50.396874, 30.616451], [50.396877, 30.6166], [50.396853, 30.616742], [50.396809, 30.616907], [50.396748, 30.617055], [50.396576, 30.617459], [50.396489, 30.617613], [50.396413, 30.61771], [50.396355, 30.617758], [50.396272, 30.617795], [50.39621, 30.617789], [50.396152, 30.617778], [50.396094, 30.617745], [50.396041, 30.617699], [50.395968, 30.617609], [50.395895, 30.617486], [50.395618, 30.615704], [50.395492, 30.614916], [50.395157, 30.612776], [50.395034, 30.611917], [50.394997, 30.611665], [50.394797, 30.61031], [50.394699, 30.609607], [50.394667, 30.609371], [50.394574, 30.608513], [50.394497, 30.607808], [50.394414, 30.606555], [50.394363, 30.604864], [50.394365, 30.603899], [50.394383, 30.603369], [50.394509, 30.602944], [50.394685, 30.60239], [50.394812, 30.601998], [50.395149, 30.600812], [50.395226, 30.60085], [50.395249, 30.60086], [50.395364, 30.600915], [50.39531, 30.601176], [50.395257, 30.601443]], "routeDbId": 12, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0432\\u0443\\u043b. \\u041a\\u0443\\u0434\\u0440\\u044f\\u0432\\u0441\\u044c\\u043a\\u0430 24\\u0430 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 6, "eta": "09:06", "id": 72, "lat": 50.4583108, "lng": 30.5037837, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0432\\u0443\\u043b\\u0438\\u0446\\u044f \\u0406\\u043e\\u0430\\u043d\\u043d\\u0430 \\u041f\\u0430\\u0432\\u043b\\u0430 II, 6/1 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 11, "eta": "09:32", "id": 133, "lat": 50.4202942, "lng": 30.5265755, "serviceMin": 15, "stopOrder": 2, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0431-\\u0440 \\u041c\\u0438\\u043a\\u043e\\u043b\\u0438 \\u041c\\u0456\\u0445\\u043d\\u043e\\u0432\\u0441\\u044c\\u043a\\u043e\\u0433\\u043e 4/6 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 5, "eta": "09:52", "id": 112, "lat": 50.41164209999999, "lng": 30.5305176, "serviceMin": 15, "stopOrder": 3, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u041a\\u0430\\u0445\\u0438 \\u0411\\u0435\\u043d\\u0434\\u0443\\u043a\\u0456\\u0434\\u0437\\u0435 2 ", "delivery_window_end": "13:00", "delivery_window_start": "10:00", "driveMin": 4, "eta": "10:11", "id": 23, "lat": 50.4116246, "lng": 30.5445812, "serviceMin": 15, "stopOrder": 4, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u043f\\u0440\\u043e\\u0441\\u043f\\u0435\\u043a\\u0442 \\u0421\\u043e\\u0431\\u043e\\u0440\\u043d\\u043e\\u0441\\u0442\\u0456 30  ", "delivery_window_end": "22:30", "delivery_window_start": "09:00", "driveMin": 11, "eta": "10:37", "id": 236, "lat": 50.4389165, "lng": 30.6099748, "serviceMin": 15, "stopOrder": 5, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0410\\u043d\\u043d\\u0438 \\u0410\\u0445\\u043c\\u0430\\u0442\\u043e\\u0432\\u043e\\u0457 18 ", "delivery_window_end": "13:00", "delivery_window_start": "10:00", "driveMin": 9, "eta": "11:01", "id": 232, "lat": 50.4099686, "lng": 30.6308206, "serviceMin": 15, "stopOrder": 6, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0417\\u0430\\u0432\\u0430\\u043b\\u044c\\u043d\\u0430 10\\u0433 ", "delivery_window_end": "13:00", "delivery_window_start": "10:00", "driveMin": 5, "eta": "11:21", "id": 59, "lat": 50.39266620000001, "lng": 30.6159093, "serviceMin": 15, "stopOrder": 7, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0417\\u0430\\u0440\\u0456\\u0447\\u043d\\u0430 1\\u0413 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 4, "eta": "11:40", "id": 147, "lat": 50.3952962, "lng": 30.6015543, "serviceMin": 15, "stopOrder": 8, "waitMin": 0}], "totalDistanceKm": 31.42, "totalDriveMin": 55}]}	2026-04-25 11:16:05.292825	09:00:00
22	7	2026-04-25	accepted	\N	1	4.84	9	\N	\N	\N	\N	2026-04-24 17:02:56.412429	2026-04-25 12:38:17.243312	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 10, "totalDeliveries": 29, "totalDistanceKm": 178.72, "totalDriveMin": 301}, "_selectedDate": "2026-04-25", "_fromDistribute": true, "routes": [{"courierId": "route_22", "courierName": "\\u0412\\u0456\\u0442\\u0430\\u043b\\u0456\\u0439", "departureAdjusted": false, "departureTime": "15:13", "geometry": [[50.473297, 30.482599], [50.47286, 30.48312], [50.472523, 30.483521], [50.471796, 30.484387], [50.471599, 30.484617], [50.4715, 30.484745], [50.471425, 30.484739], [50.471143, 30.48472], [50.470095, 30.484633], [50.470074, 30.485231], [50.470033, 30.48643], [50.470027, 30.486516], [50.470025, 30.486587], [50.469998, 30.48732], [50.469961, 30.488342], [50.469955, 30.488525], [50.469939, 30.488528], [50.469924, 30.488539], [50.469912, 30.488556], [50.469904, 30.488578], [50.4699, 30.488603], [50.469901, 30.488628], [50.469906, 30.488652], [50.469916, 30.488672], [50.469929, 30.488686], [50.469944, 30.488695], [50.46996, 30.488696], [50.469975, 30.488689], [50.469989, 30.488676], [50.47, 30.488658], [50.470055, 30.488685], [50.470116, 30.488759], [50.470157, 30.48886], [50.470178, 30.488986], [50.470183, 30.489094], [50.470173, 30.489204], [50.470148, 30.48928], [50.470131, 30.489313], [50.469983, 30.489538], [50.469959, 30.489487], [50.469921, 30.489504], [50.469816, 30.489518], [50.469665, 30.489515], [50.469142, 30.4895], [50.468992, 30.489522], [50.468871, 30.489648], [50.468641, 30.489903], [50.468496, 30.489956], [50.468329, 30.489925], [50.467981, 30.489839], [50.467693, 30.48981], [50.467513, 30.489771], [50.467283, 30.489693], [50.467138, 30.489681], [50.466753, 30.489703], [50.466424, 30.489781], [50.466395, 30.48983], [50.466356, 30.490282], [50.46629, 30.490513], [50.466161, 30.490861], [50.466128, 30.490954], [50.466067, 30.490855], [50.465964, 30.490744], [50.465792, 30.490613], [50.4656, 30.490527], [50.465397, 30.490501], [50.465264, 30.490515], [50.465133, 30.490572], [50.464981, 30.49069], [50.463917, 30.491689], [50.463358, 30.492218], [50.463267, 30.492277], [50.46318, 30.492316], [50.463074, 30.492336], [50.46265, 30.492389], [50.462621, 30.492393], [50.462554, 30.492403], [50.462511, 30.492407], [50.462484, 30.492412], [50.462455, 30.492417], [50.462465, 30.492685], [50.462548, 30.494195], [50.462551, 30.494364], [50.462546, 30.494511], [50.462532, 30.494667], [50.46251, 30.4948], [50.462473, 30.49495], [50.462407, 30.495145], [50.462337, 30.49534], [50.462228, 30.495621], [50.46213, 30.495896], [50.462093, 30.496005], [50.462024, 30.495973], [50.46192, 30.495958], [50.461484, 30.495961], [50.461178, 30.495963], [50.461165, 30.495963], [50.460678, 30.495995], [50.460539, 30.496036], [50.46038, 30.496163], [50.459356, 30.496926], [50.459031, 30.497173], [50.458873, 30.497382], [50.458792, 30.497477], [50.458688, 30.497815], [50.458647, 30.497959], [50.458381, 30.498963], [50.458321, 30.499144], [50.458278, 30.499205], [50.457831, 30.499558], [50.457725, 30.499642], [50.457558, 30.499775], [50.457399, 30.499891], [50.457341, 30.49999], [50.457294, 30.500069], [50.457226, 30.500239], [50.45719, 30.500332], [50.457138, 30.500499], [50.457123, 30.500548], [50.457053, 30.500812], [50.45701, 30.501014], [50.456971, 30.501288], [50.456952, 30.501285], [50.456931, 30.501293], [50.456912, 30.501311], [50.456899, 30.501339], [50.456893, 30.501373], [50.456832, 30.501408], [50.456793, 30.501409], [50.456547, 30.50124], [50.456506, 30.501232], [50.456469, 30.501227], [50.456487, 30.501842], [50.456481, 30.501931], [50.456471, 30.502017], [50.456439, 30.502152], [50.45639, 30.502339], [50.456367, 30.502424], [50.456362, 30.502441], [50.455879, 30.504217], [50.455874, 30.504237], [50.45585, 30.504323], [50.455723, 30.50478], [50.455708, 30.504838], [50.455519, 30.505547], [50.455442, 30.505849], [50.455381, 30.506156], [50.45535, 30.506386], [50.455338, 30.506496], [50.45533, 30.506564], [50.455275, 30.507074], [50.455244, 30.507373], [50.455219, 30.507589], [50.455165, 30.508112], [50.455161, 30.508656], [50.455175, 30.509093], [50.455212, 30.509806], [50.455248, 30.510346], [50.45529, 30.51097], [50.455332, 30.511573], [50.455334, 30.511647], [50.455338, 30.5117], [50.455344, 30.511814], [50.455352, 30.512006], [50.455361, 30.51238], [50.455371, 30.512876], [50.455376, 30.513037], [50.455399, 30.513661], [50.455405, 30.51379], [50.45541, 30.513931], [50.455414, 30.514001], [50.455425, 30.514227], [50.455426, 30.514462], [50.455423, 30.515377], [50.455417, 30.515592], [50.455406, 30.516357], [50.455415, 30.516942], [50.455411, 30.517123], [50.455404, 30.517352], [50.455375, 30.518032], [50.455343, 30.519005], [50.455325, 30.51946], [50.455312, 30.519593], [50.455279, 30.519845], [50.455271, 30.519903], [50.455261, 30.519967], [50.455217, 30.520177], [50.455152, 30.520378], [50.455084, 30.520524], [50.455012, 30.520626], [50.454586, 30.520978], [50.454468, 30.521069], [50.454425, 30.521101], [50.454189, 30.521277], [50.453789, 30.521571], [50.45372, 30.521623], [50.453637, 30.521683], [50.453481, 30.52179], [50.453425, 30.521825], [50.453377, 30.52185], [50.4532, 30.521924], [50.453046, 30.521983], [50.453014, 30.521995], [50.452816, 30.522067], [50.452774, 30.522083], [50.452707, 30.522105], [50.452414, 30.522201], [50.452356, 30.52222], [50.452077, 30.52232], [50.45175, 30.522432], [50.451479, 30.522525], [50.451468, 30.52253], [50.451457, 30.522537], [50.451447, 30.522546], [50.451438, 30.522558], [50.45143, 30.522571], [50.451409, 30.522608], [50.451391, 30.522645], [50.451326, 30.522808], [50.451284, 30.522906], [50.451249, 30.522979], [50.451235, 30.523009], [50.451211, 30.523055], [50.451163, 30.523146], [50.450558, 30.524244], [50.450416, 30.524501], [50.450385, 30.524458]], "routeDbId": 22, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0412\\u0443\\u043b.\\u0425\\u0435\\u0440\\u0441\\u043e\\u043d\\u0441\\u044c\\u043a\\u0430 4/2 ", "delivery_window_end": "16:00", "delivery_window_start": "13:00", "driveMin": 9, "eta": "15:22", "id": 85, "lat": 50.4503596, "lng": 30.5245025, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}], "totalDistanceKm": 4.84, "totalDriveMin": 9}]}	2026-04-25 11:16:05.286664	15:13:00
39	4	2026-04-26	accepted	850	3	20.27	34	341	2026-04-25 13:14:12.536085	2026-04-25 13:17:36.407042	\N	2026-04-25 13:09:30.652778	2026-04-25 17:34:05.392474	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 6, "totalDeliveries": 15, "totalDistanceKm": 106.93, "totalDriveMin": 188}, "_selectedDate": "2026-04-26", "_fromDistribute": true, "routes": [{"courierId": "route_39", "courierName": "\\u0410\\u043d\\u0434\\u0440\\u0456\\u0439 (\\u0434\\u0436\\u0443\\u043d)", "departureAdjusted": false, "departureTime": "11:56", "geometry": [[50.473297, 30.482599], [50.47286, 30.48312], [50.472523, 30.483521], [50.471796, 30.484387], [50.471599, 30.484617], [50.4715, 30.484745], [50.471425, 30.484739], [50.471143, 30.48472], [50.470095, 30.484633], [50.470035, 30.48463], [50.469514, 30.484576], [50.46943, 30.484566], [50.46933, 30.484554], [50.469287, 30.484549], [50.468778, 30.484485], [50.46855, 30.484456], [50.467979, 30.484417], [50.46755, 30.484372], [50.466593, 30.484306], [50.46638, 30.4843], [50.465773, 30.484204], [50.465128, 30.484187], [50.465087, 30.484195], [50.465053, 30.485097], [50.465015, 30.486084], [50.465013, 30.486138], [50.464733, 30.486146], [50.464583, 30.486157], [50.464277, 30.486229], [50.463933, 30.486322], [50.463888, 30.486335], [50.463701, 30.486417], [50.463622, 30.486451], [50.463419, 30.486543], [50.462957, 30.486742], [50.462463, 30.486928], [50.462405, 30.486941], [50.462109, 30.486979], [50.462068, 30.486981], [50.461003, 30.486739], [50.460935, 30.486724], [50.46093, 30.48667], [50.460916, 30.486612], [50.460894, 30.486551], [50.460585, 30.48576], [50.46039, 30.485273], [50.460294, 30.485034], [50.460268, 30.484984], [50.460224, 30.484934], [50.460201, 30.484908], [50.460192, 30.484918], [50.46011, 30.485007], [50.459865, 30.485272], [50.459674, 30.48547], [50.459117, 30.486047], [50.459081, 30.486086], [50.458822, 30.486347], [50.458756, 30.486409], [50.458642, 30.48651], [50.45858, 30.48657], [50.45833, 30.486817], [50.457941, 30.487201], [50.45786, 30.487285], [50.457583, 30.487584], [50.457533, 30.48764], [50.457402, 30.487841], [50.45724, 30.488133], [50.457151, 30.488331], [50.45711, 30.488411], [50.456947, 30.488731], [50.456887, 30.488849], [50.456785, 30.48886], [50.456721, 30.48889], [50.456443, 30.489022], [50.455913, 30.489284], [50.455881, 30.489307], [50.455811, 30.489341], [50.45498, 30.489732], [50.454439, 30.489986], [50.453903, 30.490252], [50.453317, 30.490524], [50.452846, 30.490762], [50.452791, 30.490785], [50.452742, 30.490801], [50.452756, 30.490847], [50.452893, 30.491499], [50.452923, 30.491631], [50.453014, 30.492026], [50.453274, 30.493232], [50.453289, 30.493302], [50.453319, 30.493442], [50.453229, 30.493469], [50.452481, 30.49424], [50.452374, 30.494356], [50.452176, 30.49456], [50.451885, 30.494857], [50.451578, 30.495175], [50.451467, 30.495297], [50.451298, 30.495471], [50.451014, 30.495765], [50.451002, 30.495777], [50.450494, 30.496314], [50.450369, 30.496446], [50.450322, 30.496333], [50.450216, 30.496094], [50.450072, 30.495769], [50.449987, 30.495577], [50.4499, 30.49538], [50.449964, 30.495308], [50.44999, 30.495278], [50.45011, 30.495142], [50.450176, 30.495067], [50.450267, 30.494787], [50.45031, 30.494737], [50.450333, 30.494712], [50.450359, 30.494682], [50.450355, 30.494672], [50.450342, 30.494643], [50.45063, 30.494328], [50.450539, 30.494126], [50.450405, 30.494275], [50.450274, 30.494421], [50.450259, 30.494466], [50.450342, 30.494643], [50.450355, 30.494672], [50.450359, 30.494682], [50.450333, 30.494712], [50.45031, 30.494737], [50.450267, 30.494787], [50.450176, 30.495067], [50.45011, 30.495142], [50.44999, 30.495278], [50.449964, 30.495308], [50.4499, 30.49538], [50.449734, 30.495032], [50.44969, 30.494934], [50.449582, 30.494733], [50.4494, 30.494415], [50.449343, 30.494313], [50.449268, 30.494392], [50.448787, 30.494898], [50.448748, 30.494937], [50.448303, 30.4954], [50.448228, 30.495485], [50.447953, 30.495776], [50.447853, 30.49588], [50.44782, 30.495914], [50.447761, 30.495976], [50.447795, 30.496062], [50.44817, 30.497], [50.448374, 30.497509], [50.448398, 30.49757], [50.448439, 30.49767], [50.448526, 30.49789], [50.448636, 30.498169], [50.4486, 30.49819], [50.448566, 30.498211], [50.448517, 30.498299], [50.448501, 30.498377], [50.448494, 30.498419], [50.448402, 30.498977], [50.448391, 30.499043], [50.448348, 30.499305], [50.448162, 30.50043], [50.448143, 30.50055], [50.448136, 30.500592], [50.448123, 30.500668], [50.448045, 30.501142], [50.447943, 30.501763], [50.447671, 30.503413], [50.447615, 30.503754], [50.447598, 30.503875], [50.447582, 30.503992], [50.447462, 30.5047], [50.447448, 30.50479], [50.447327, 30.505513], [50.447231, 30.506084], [50.447227, 30.506108], [50.447215, 30.506176], [50.447137, 30.506642], [50.44712, 30.506745], [50.447116, 30.50677], [50.447069, 30.507048], [50.447037, 30.507241], [50.447031, 30.507273], [50.447019, 30.507344], [50.446833, 30.508501], [50.446826, 30.50854], [50.446807, 30.508649], [50.446786, 30.508772], [50.446692, 30.509352], [50.44664, 30.509667], [50.446541, 30.51025], [50.446534, 30.510292], [50.446495, 30.510533], [50.446582, 30.510564], [50.446631, 30.510582], [50.446787, 30.510641], [50.446894, 30.51068], [50.446894, 30.51068], [50.446787, 30.510641], [50.446631, 30.510582], [50.446582, 30.510564], [50.446495, 30.510533], [50.446534, 30.510292], [50.446541, 30.51025], [50.44664, 30.509667], [50.446692, 30.509352], [50.446786, 30.508772], [50.446807, 30.508649], [50.446712, 30.508611], [50.446697, 30.508605], [50.446512, 30.508539], [50.446389, 30.508494], [50.446013, 30.508336], [50.445716, 30.508212], [50.445624, 30.50817], [50.44558, 30.508153], [50.445497, 30.508117], [50.445491, 30.508114], [50.445461, 30.508102], [50.44459, 30.507751], [50.444535, 30.507721], [50.444511, 30.507681], [50.444494, 30.507625], [50.444508, 30.507532], [50.444696, 30.50637], [50.444701, 30.506338], [50.44474, 30.5061], [50.44489, 30.505156], [50.444995, 30.504501], [50.445013, 30.504393], [50.445096, 30.503873], [50.445252, 30.502953], [50.445554, 30.501103], [50.445373, 30.500793], [50.445069, 30.50011], [50.444948, 30.499834], [50.444838, 30.499579], [50.444648, 30.499153], [50.444515, 30.498857], [50.444462, 30.498743], [50.444361, 30.498509], [50.444131, 30.497991], [50.444058, 30.497826], [50.444015, 30.497728], [50.443933, 30.497535], [50.443782, 30.497184], [50.443721, 30.497044], [50.44383, 30.496926], [50.444173, 30.496555], [50.444309, 30.496408], [50.444589, 30.496105], [50.444697, 30.495986], [50.444992, 30.49567], [50.445221, 30.495423], [50.445476, 30.495147], [50.445933, 30.494647], [50.445963, 30.494632], [50.445966, 30.494484], [50.445957, 30.494406], [50.445945, 30.494338], [50.445887, 30.494153], [50.445841, 30.494047], [50.445791, 30.493924], [50.445726, 30.493786], [50.445624, 30.493558], [50.445592, 30.493487], [50.445561, 30.493413], [50.445441, 30.493146], [50.445317, 30.492866], [50.445272, 30.492764], [50.445208, 30.492597], [50.445236, 30.492568], [50.445453, 30.492405], [50.445512, 30.492315], [50.445577, 30.492185], [50.445701, 30.49189], [50.445871, 30.491468], [50.445954, 30.49121], [50.445973, 30.491137], [50.445985, 30.491091], [50.446076, 30.490724], [50.446086, 30.490685], [50.446101, 30.490631], [50.446225, 30.490003], [50.446277, 30.489705], [50.446335, 30.489111], [50.446337, 30.489016], [50.44635, 30.488455], [50.446341, 30.487789], [50.446318, 30.48748], [50.44628, 30.487167], [50.446269, 30.48697], [50.446258, 30.486577], [50.446265, 30.486254], [50.446288, 30.485987], [50.446321, 30.485723], [50.446564, 30.484151], [50.446632, 30.483715], [50.446733, 30.483299], [50.446909, 30.482597], [50.446966, 30.482291], [50.447032, 30.481854], [50.447091, 30.481533], [50.447175, 30.481038], [50.44729, 30.480519], [50.447451, 30.479795], [50.447456, 30.479757], [50.447479, 30.479612], [50.447519, 30.479329], [50.447589, 30.478843], [50.447625, 30.478581], [50.447669, 30.478198], [50.447738, 30.47758], [50.447775, 30.477126], [50.447815, 30.476557], [50.447835, 30.476192], [50.447845, 30.475518], [50.447808, 30.47433], [50.447723, 30.473318], [50.44742, 30.471517], [50.447386, 30.471237], [50.447345, 30.470775], [50.4473, 30.470434], [50.446814, 30.467964], [50.446737, 30.46756], [50.446645, 30.467076], [50.446542, 30.466493], [50.446334, 30.465414], [50.446014, 30.463838], [50.44591, 30.46332], [50.445837, 30.462827], [50.44579, 30.462148], [50.445786, 30.461625], [50.445799, 30.461233], [50.445823, 30.46083], [50.445865, 30.460415], [50.445965, 30.459524], [50.446121, 30.458198], [50.446235, 30.457312], [50.446476, 30.455594], [50.446581, 30.454732], [50.446696, 30.453682], [50.446712, 30.453434], [50.446714, 30.453174], [50.446706, 30.452907], [50.446673, 30.452602], [50.446626, 30.452333], [50.446539, 30.451954], [50.446209, 30.450673], [50.445673, 30.448599], [50.44535, 30.447333], [50.445328, 30.447244], [50.44502, 30.446014], [50.445015, 30.445992], [50.444893, 30.445523], [50.444399, 30.443604], [50.444216, 30.442788], [50.444185, 30.442664], [50.443918, 30.441609], [50.443831, 30.441265], [50.443787, 30.4411], [50.44343, 30.439703], [50.443276, 30.439107], [50.443062, 30.438276], [50.443049, 30.438226], [50.442976, 30.437938], [50.442962, 30.437883], [50.442688, 30.436785], [50.442628, 30.436543], [50.442438, 30.435805], [50.442119, 30.434553], [50.442101, 30.434483], [50.441826, 30.43333], [50.441679, 30.432684], [50.441549, 30.432116], [50.441327, 30.431214], [50.441079, 30.430268], [50.440846, 30.429408], [50.440502, 30.428218], [50.440026, 30.426394], [50.439775, 30.425397], [50.439587, 30.424661], [50.439455, 30.424135], [50.438679, 30.421169], [50.438376, 30.419909], [50.438148, 30.419018], [50.438024, 30.418533], [50.43752, 30.416612], [50.43705, 30.414786], [50.436644, 30.413207], [50.436312, 30.411908], [50.435994, 30.410578], [50.43593, 30.410315], [50.435916, 30.410259], [50.435812, 30.409852], [50.435618, 30.409217], [50.435519, 30.408896], [50.435364, 30.40828], [50.435349, 30.408219], [50.435156, 30.407475], [50.434866, 30.406358], [50.434495, 30.404925], [50.434097, 30.403394], [50.43404, 30.403165], [50.433502, 30.401032], [50.433411, 30.400659], [50.433263, 30.399905], [50.433043, 30.399058], [50.432924, 30.398647], [50.432839, 30.398354], [50.43277, 30.398087], [50.43227, 30.396105], [50.431821, 30.394369], [50.43168, 30.393826], [50.431662, 30.393762], [50.431351, 30.392557], [50.431073, 30.391474], [50.430501, 30.389277], [50.430421, 30.388974], [50.429759, 30.386288], [50.429738, 30.385993], [50.429758, 30.385806], [50.429804, 30.38559], [50.429823, 30.38553], [50.429859, 30.385346], [50.429866, 30.385154], [50.429842, 30.384965], [50.429789, 30.384791], [50.42971, 30.384643], [50.429611, 30.38453], [50.429554, 30.384489], [50.429363, 30.3843], [50.429299, 30.384218], [50.429243, 30.384134], [50.429193, 30.38402], [50.429158, 30.383912], [50.428869, 30.382747], [50.428253, 30.380374], [50.426824, 30.374846], [50.426243, 30.372592], [50.425443, 30.369438], [50.425397, 30.369183], [50.425399, 30.36896], [50.425441, 30.368788], [50.426003, 30.367401], [50.426006, 30.367303], [50.425982, 30.367173], [50.425944, 30.36704], [50.425881, 30.366903], [50.42581, 30.366817], [50.425744, 30.366769], [50.425668, 30.366732], [50.425545, 30.366726], [50.425414, 30.366788], [50.425238, 30.366908], [50.424982, 30.367122], [50.424886, 30.367225], [50.424765, 30.367311], [50.424719, 30.367348], [50.42463, 30.367406], [50.424617, 30.367356], [50.424397, 30.36652], [50.424292, 30.36598], [50.424294, 30.365942], [50.424289, 30.365904], [50.424222, 30.3655], [50.424183, 30.365251], [50.424145, 30.365028], [50.424064, 30.364547], [50.424055, 30.364495], [50.424037, 30.36439], [50.423872, 30.363397], [50.423677, 30.362134], [50.423662, 30.362022], [50.423651, 30.361944], [50.423558, 30.361331], [50.423481, 30.360857], [50.423408, 30.36053], [50.423311, 30.360156], [50.423283, 30.360044], [50.423196, 30.359648], [50.423088, 30.359083], [50.423039, 30.35877], [50.423006, 30.358465], [50.422764, 30.356423], [50.422669, 30.355939], [50.422558, 30.355484], [50.422505, 30.355287], [50.422489, 30.355244], [50.422424, 30.355112], [50.422313, 30.354965], [50.422229, 30.354853], [50.422131, 30.354724], [50.422084, 30.354662], [50.421979, 30.354464], [50.421885, 30.354232], [50.42177, 30.353876], [50.421744, 30.353747], [50.421732, 30.353585], [50.421727, 30.353449], [50.421729, 30.353141], [50.421741, 30.352701], [50.421779, 30.352304], [50.421792, 30.35216], [50.421927, 30.350622], [50.421941, 30.350511], [50.421996, 30.35009], [50.422039, 30.349857], [50.422079, 30.349666], [50.422125, 30.349506], [50.422163, 30.349379], [50.422192, 30.349243], [50.422205, 30.349143], [50.422209, 30.349111], [50.422223, 30.348955], [50.422234, 30.34831], [50.422244, 30.347941], [50.422262, 30.347532], [50.422267, 30.34721], [50.422255, 30.346972], [50.422223, 30.34663], [50.422128, 30.346016], [50.421949, 30.345006], [50.422025, 30.344931], [50.422492, 30.344465], [50.422958, 30.344019], [50.422493, 30.343045], [50.422096, 30.342042], [50.421142, 30.339601], [50.420546, 30.338675], [50.420113, 30.337971], [50.419492, 30.33698], [50.419331, 30.336704], [50.419176, 30.33639], [50.418705, 30.335138], [50.418772, 30.335086], [50.419527, 30.334722], [50.421514, 30.333767], [50.422173, 30.333432], [50.422331, 30.333351], [50.422942, 30.33304], [50.423065, 30.332982], [50.424171, 30.332454], [50.424265, 30.332418], [50.424377, 30.332424], [50.424496, 30.332413], [50.424543, 30.332412], [50.424605, 30.332409], [50.424695, 30.332416], [50.424763, 30.332426], [50.424804, 30.332438], [50.424846, 30.332427], [50.42488, 30.332398], [50.424908, 30.332349], [50.424924, 30.332288], [50.424925, 30.332222], [50.424949, 30.332135], [50.424978, 30.332048], [50.425019, 30.331958], [50.425086, 30.331911], [50.425366, 30.331739], [50.424886, 30.330637], [50.424402, 30.329536], [50.424381, 30.329488], [50.423931, 30.32848], [50.423882, 30.328365], [50.423501, 30.32748], [50.423465, 30.327395], [50.423343, 30.327107]], "routeDbId": 39, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0412\\u0443\\u043b. \\u0411\\u0443\\u043b\\u044c\\u0432\\u0430\\u0440\\u043d\\u043e-\\u041a\\u0443\\u0434\\u0440\\u044f\\u0432\\u0441\\u044c\\u043a\\u0430 36 ", "delivery_window_end": "13:00", "delivery_window_start": "10:00", "driveMin": 7, "eta": "12:03", "id": 53, "lat": 50.4504425, "lng": 30.4943602, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0432\\u0443\\u043b. \\u0411\\u043e\\u0433\\u0434\\u0430\\u043d\\u0430 \\u0425\\u043c\\u0435\\u043b\\u044c\\u043d\\u0438\\u0446\\u044c\\u043a\\u043e\\u0433\\u043e 32 ", "delivery_window_end": "13:00", "delivery_window_start": "11:00", "driveMin": 3, "eta": "12:21", "id": 76, "lat": 50.4469091, "lng": 30.5106438, "serviceMin": 15, "stopOrder": 2, "waitMin": 0}, {"address": "\\u041f\\u0435\\u0442\\u0440\\u043e\\u043f\\u0430\\u0432\\u043b\\u0456\\u0432\\u0441\\u044c\\u043a\\u0430 \\u0411\\u043e\\u0440\\u0449\\u0430\\u0433\\u0456\\u0432\\u043a\\u0430, \\u0432\\u0443\\u043b \\u041f\\u0430\\u0440\\u043a\\u043e\\u0432\\u0430 22 ", "delivery_window_end": "16:00", "delivery_window_start": "13:00", "driveMin": 24, "eta": "13:00", "id": 206, "lat": 50.4233327, "lng": 30.3271168, "serviceMin": 15, "stopOrder": 3, "waitMin": 0}], "totalDistanceKm": 20.27, "totalDriveMin": 34}]}	2026-04-25 17:34:05.392125	11:56:00
36	7	2026-04-26	accepted	\N	2	13.61	24	\N	\N	\N	\N	2026-04-25 13:09:30.640874	2026-04-25 17:34:05.400085	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 6, "totalDeliveries": 15, "totalDistanceKm": 106.93, "totalDriveMin": 188}, "_selectedDate": "2026-04-26", "_fromDistribute": true, "routes": [{"courierId": "route_36", "courierName": "\\u0423\\u043a\\u043b\\u043e\\u043d", "departureAdjusted": false, "departureTime": "08:48", "geometry": [[50.473297, 30.482599], [50.473502, 30.482355], [50.47347, 30.482288], [50.473047, 30.481403], [50.473463, 30.480252], [50.473597, 30.47993], [50.473735, 30.479606], [50.473899, 30.479227], [50.473984, 30.479031], [50.474299, 30.478379], [50.474456, 30.478042], [50.474477, 30.477997], [50.474267, 30.477757], [50.473786, 30.477209], [50.473675, 30.477083], [50.473602, 30.477], [50.473547, 30.476932], [50.473399, 30.476768], [50.473569, 30.476633], [50.47396, 30.476239], [50.474068, 30.47613], [50.474193, 30.476021], [50.474324, 30.475931], [50.474462, 30.475866], [50.474598, 30.475819], [50.474973, 30.47569], [50.475343, 30.475586], [50.475487, 30.475567], [50.475663, 30.475564], [50.475857, 30.475594], [50.476043, 30.475651], [50.476277, 30.475775], [50.476514, 30.475947], [50.477777, 30.47706], [50.477924, 30.477166], [50.478071, 30.477221], [50.478217, 30.477244], [50.478369, 30.477221], [50.478507, 30.477158], [50.479235, 30.476663], [50.479356, 30.476569], [50.479428, 30.476513], [50.480746, 30.475281], [50.480858, 30.475175], [50.48097, 30.475109], [50.4811, 30.475079], [50.481237, 30.475093], [50.481369, 30.475168], [50.481473, 30.475265], [50.481568, 30.475403], [50.48183, 30.475849], [50.481908, 30.475982], [50.48204, 30.476129], [50.482193, 30.476244], [50.482325, 30.476303], [50.48247, 30.47634], [50.482596, 30.476346], [50.482722, 30.476329], [50.482881, 30.476265], [50.483074, 30.476126], [50.483815, 30.475332], [50.484271, 30.474845], [50.484854, 30.47423], [50.484943, 30.474146], [50.485083, 30.474016], [50.485334, 30.473743], [50.485747, 30.473186], [50.485908, 30.47294], [50.486106, 30.472645], [50.486179, 30.472515], [50.486385, 30.472174], [50.486522, 30.471921], [50.486892, 30.471255], [50.487179, 30.470734], [50.487359, 30.470421], [50.487448, 30.470269], [50.487709, 30.469836], [50.48799, 30.469368], [50.488217, 30.468992], [50.488395, 30.468701], [50.488714, 30.468161], [50.489001, 30.467695], [50.489058, 30.467591], [50.489687, 30.466551], [50.489771, 30.466662], [50.489791, 30.466689], [50.489857, 30.466784], [50.489906, 30.466855], [50.490184, 30.467281], [50.491324, 30.469029], [50.491602, 30.469442], [50.491657, 30.469523], [50.491723, 30.469618], [50.491829, 30.469491], [50.492165, 30.469127], [50.493193, 30.46805], [50.4938, 30.467405], [50.493944, 30.467251], [50.49409, 30.467095], [50.494491, 30.466666], [50.495517, 30.465575], [50.496006, 30.465051], [50.496093, 30.464961], [50.496166, 30.46489], [50.496439, 30.464614], [50.497012, 30.464009], [50.497537, 30.463441], [50.497615, 30.463356], [50.497657, 30.463309], [50.498352, 30.462669], [50.498858, 30.46221], [50.498915, 30.46216], [50.498959, 30.46212], [50.499029, 30.462047], [50.499261, 30.461849], [50.500237, 30.460986], [50.500634, 30.460667], [50.500852, 30.460543], [50.501344, 30.460355], [50.501414, 30.46033], [50.501928, 30.460149], [50.502587, 30.459921], [50.50284, 30.45983], [50.503015, 30.459769], [50.503354, 30.459649], [50.503588, 30.45957], [50.504711, 30.45919], [50.504934, 30.4591], [50.505097, 30.45904], [50.507798, 30.458042], [50.50836, 30.45785], [50.508969, 30.457631], [50.509051, 30.4576], [50.509128, 30.457573], [50.511717, 30.456618], [50.512302, 30.456419], [50.512529, 30.456338], [50.513344, 30.456034], [50.515065, 30.455439], [50.515965, 30.455125], [50.516053, 30.455093], [50.516064, 30.455201], [50.516188, 30.456138], [50.516213, 30.456283], [50.516341, 30.457316], [50.516353, 30.457402], [50.516476, 30.458344], [50.516493, 30.458468], [50.516595, 30.458419], [50.516746, 30.458348], [50.517061, 30.458198], [50.518032, 30.457737], [50.518401, 30.457561], [50.518518, 30.457506], [50.518676, 30.45743], [50.518766, 30.457415], [50.518997, 30.457422], [50.519383, 30.457514], [50.519555, 30.456764], [50.519661, 30.45629], [50.519785, 30.456364], [50.519839, 30.456396], [50.519972, 30.456507], [50.520099, 30.456551], [50.520329, 30.456689], [50.520489, 30.456987], [50.520724, 30.457121], [50.520838, 30.457187], [50.521516, 30.457575], [50.521932, 30.457813], [50.522477, 30.458125], [50.522547, 30.457841], [50.522607, 30.457876], [50.522805, 30.457992], [50.522703, 30.458439], [50.522603, 30.458872], [50.522529, 30.45914], [50.522479, 30.459112], [50.522469, 30.459107], [50.520877, 30.458206], [50.520709, 30.458112], [50.519873, 30.45764], [50.519618, 30.457496], [50.519383, 30.457514], [50.519555, 30.456764], [50.519661, 30.45629], [50.520123, 30.454222], [50.520203, 30.454082], [50.520322, 30.453476], [50.520369, 30.452953], [50.520418, 30.45259], [50.520531, 30.451798], [50.520544, 30.451718], [50.520588, 30.451451], [50.520617, 30.451255], [50.520664, 30.450905], [50.520777, 30.450239], [50.520805, 30.450061], [50.520831, 30.449943], [50.520848, 30.449862], [50.520875, 30.449857], [50.520905, 30.449843], [50.520945, 30.449813], [50.52099, 30.449758], [50.521036, 30.449652], [50.521054, 30.449554], [50.521052, 30.449451], [50.521035, 30.449364], [50.521004, 30.449288], [50.520961, 30.449226], [50.520902, 30.44918], [50.520871, 30.449173], [50.520836, 30.449164], [50.520781, 30.449175], [50.52073, 30.449207], [50.520481, 30.449252], [50.520116, 30.44931], [50.520003, 30.449329], [50.519437, 30.449394], [50.518893, 30.449459], [50.518477, 30.44951], [50.517471, 30.449604], [50.516892, 30.449679], [50.516861, 30.449684], [50.51681, 30.449695], [50.516322, 30.44975], [50.516138, 30.449773], [50.516034, 30.449784], [50.514698, 30.449935], [50.514591, 30.449952], [50.514455, 30.449964], [50.514129, 30.449992], [50.513357, 30.450071], [50.513237, 30.450088], [50.512652, 30.450171], [50.512518, 30.450186], [50.512026, 30.450257], [50.511924, 30.45027], [50.511882, 30.450275], [50.511598, 30.450311], [50.511278, 30.450346], [50.510972, 30.450391], [50.510154, 30.45051], [50.510039, 30.450526], [50.509639, 30.450578], [50.50926, 30.450624], [50.508454, 30.450707], [50.508373, 30.450714], [50.50827, 30.450721], [50.50801, 30.450738], [50.507287, 30.45078], [50.506758, 30.450806], [50.506512, 30.450815], [50.506377, 30.450823], [50.506051, 30.450846], [50.505903, 30.450873], [50.50556, 30.450927], [50.505364, 30.450959], [50.505083, 30.451012], [50.504692, 30.45109], [50.504303, 30.451159], [50.503938, 30.451221], [50.503546, 30.451288], [50.503507, 30.451296], [50.503107, 30.451352], [50.502254, 30.451477], [50.502214, 30.451484], [50.501627, 30.45158], [50.5012, 30.451645], [50.501113, 30.451656], [50.500965, 30.451677], [50.500843, 30.451692], [50.500578, 30.45172], [50.500468, 30.451733], [50.500425, 30.451748], [50.500358, 30.451781], [50.500288, 30.451844], [50.50005, 30.452122], [50.499765, 30.452447], [50.499455, 30.452835], [50.499169, 30.453177], [50.498376, 30.454206], [50.498164, 30.454477], [50.497242, 30.455713], [50.497126, 30.45588], [50.496948, 30.45616], [50.496866, 30.456013], [50.496741, 30.455779], [50.496269, 30.454868], [50.496085, 30.454499], [50.495936, 30.454096], [50.494554, 30.449853], [50.494191, 30.448788], [50.494159, 30.448689], [50.494003, 30.448207], [50.493941, 30.448014], [50.493859, 30.44776], [50.493627, 30.447069], [50.493263, 30.445953], [50.493204, 30.445706], [50.493139, 30.445384], [50.493037, 30.444392], [50.493012, 30.444131], [50.492994, 30.44395], [50.49294, 30.443427], [50.492875, 30.442767], [50.492804, 30.442023], [50.492779, 30.441772], [50.492697, 30.440906], [50.492592, 30.43982], [50.492498, 30.438777], [50.492392, 30.437756], [50.492296, 30.436788], [50.492253, 30.436381], [50.49223, 30.436142], [50.49222, 30.436045], [50.492211, 30.435957], [50.492204, 30.435883], [50.492188, 30.435722], [50.492068, 30.434568], [50.492053, 30.434419], [50.491814, 30.432161], [50.491697, 30.430997], [50.491572, 30.429527], [50.491542, 30.42918], [50.491525, 30.428977], [50.491512, 30.42881], [50.491485, 30.428471], [50.491454, 30.428066], [50.491446, 30.427975], [50.49135, 30.426963], [50.491264, 30.426538], [50.491156, 30.426206], [50.49108, 30.425984], [50.490999, 30.42579], [50.490825, 30.425374], [50.490578, 30.424783], [50.490165, 30.423796], [50.490115, 30.423675], [50.490084, 30.423711], [50.489993, 30.423718], [50.489864, 30.423705], [50.489791, 30.423645], [50.48969, 30.423482], [50.489562, 30.423192], [50.489433, 30.423055], [50.489156, 30.422857], [50.488996, 30.422713], [50.489052, 30.422494], [50.489096, 30.422332], [50.489136, 30.422174], [50.489202, 30.421928], [50.489319, 30.421487], [50.489345, 30.421387], [50.489433, 30.421056], [50.489615, 30.420319], [50.489872, 30.419291], [50.490264, 30.41772], [50.490324, 30.417753], [50.490412, 30.417803], [50.490421, 30.417808], [50.490486, 30.417845], [50.490593, 30.417909], [50.4906, 30.417913], [50.490834, 30.418055], [50.490853, 30.418066], [50.49089, 30.418088], [50.490877, 30.418156], [50.49072, 30.418959]], "routeDbId": 36, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u043f\\u0440\\u043e\\u0441\\u043f\\u0435\\u043a\\u0442 \\u0414\\u043c\\u0438\\u0442\\u0440\\u0430 \\u041f\\u0430\\u0432\\u043b\\u0438\\u0447\\u043a\\u0430 3 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 12, "eta": "09:00", "id": 154, "lat": 50.5214648, "lng": 30.4577936, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0412\\u0456\\u043a\\u0442\\u043e\\u0440\\u0430 \\u041d\\u0435\\u043a\\u0440\\u0430\\u0441\\u043e\\u0432\\u0430 8 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 12, "eta": "09:27", "id": 151, "lat": 50.4908138, "lng": 30.4193247, "serviceMin": 15, "stopOrder": 2, "waitMin": 0}], "totalDistanceKm": 13.61, "totalDriveMin": 24}]}	2026-04-25 17:34:05.399682	08:48:00
30	7	2026-04-26	accepted	\N	2	21.28	37	\N	\N	\N	\N	2026-04-25 10:52:25.395765	2026-04-25 17:34:47.118259	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 6, "totalDeliveries": 15, "totalDistanceKm": 106.93, "totalDriveMin": 188}, "_selectedDate": "2026-04-26", "_fromDistribute": true, "routes": [{"courierId": "route_30", "departureAdjusted": false, "departureTime": "08:51", "geometry": [[50.473297, 30.482599], [50.47286, 30.48312], [50.472523, 30.483521], [50.471796, 30.484387], [50.471599, 30.484617], [50.4715, 30.484745], [50.471425, 30.484739], [50.471143, 30.48472], [50.470095, 30.484633], [50.470074, 30.485231], [50.470033, 30.48643], [50.470027, 30.486516], [50.470025, 30.486587], [50.469998, 30.48732], [50.469961, 30.488342], [50.469955, 30.488525], [50.469939, 30.488528], [50.469924, 30.488539], [50.469912, 30.488556], [50.469904, 30.488578], [50.4699, 30.488603], [50.469901, 30.488628], [50.469906, 30.488652], [50.469916, 30.488672], [50.469929, 30.488686], [50.469944, 30.488695], [50.46996, 30.488696], [50.469975, 30.488689], [50.469989, 30.488676], [50.47, 30.488658], [50.470055, 30.488685], [50.470116, 30.488759], [50.470157, 30.48886], [50.470178, 30.488986], [50.470183, 30.489094], [50.470173, 30.489204], [50.470148, 30.48928], [50.470131, 30.489313], [50.469983, 30.489538], [50.469693, 30.489976], [50.469519, 30.49023], [50.469093, 30.490854], [50.469005, 30.490962], [50.468684, 30.491358], [50.468518, 30.491521], [50.468466, 30.491564], [50.468326, 30.49168], [50.467453, 30.492653], [50.46734, 30.492759], [50.466968, 30.493005], [50.46686, 30.493079], [50.466721, 30.493204], [50.466673, 30.493266], [50.466628, 30.493342], [50.466589, 30.493417], [50.466398, 30.493981], [50.466269, 30.494374], [50.466232, 30.494536], [50.466231, 30.494652], [50.466236, 30.494746], [50.466252, 30.494887], [50.46646, 30.495818], [50.466496, 30.495933], [50.466555, 30.496042], [50.466649, 30.496144], [50.467004, 30.496511], [50.467121, 30.496646], [50.467492, 30.497227], [50.467664, 30.497546], [50.467778, 30.49795], [50.467846, 30.498385], [50.467892, 30.498903], [50.467902, 30.499445], [50.467904, 30.499523], [50.46792, 30.500531], [50.46795, 30.500671], [50.468031, 30.500767], [50.46809, 30.500836], [50.46816, 30.500914], [50.468366, 30.501162], [50.468413, 30.501219], [50.468651, 30.501551], [50.469436, 30.502746], [50.469542, 30.502894], [50.469586, 30.502956], [50.46966, 30.50306], [50.469668, 30.503071], [50.469725, 30.503151], [50.469769, 30.503213], [50.469986, 30.503548], [50.470066, 30.50367], [50.470398, 30.504156], [50.470439, 30.504215], [50.470674, 30.50454], [50.470875, 30.504825], [50.471008, 30.505015], [50.471039, 30.505059], [50.471108, 30.505164], [50.471171, 30.505259], [50.471194, 30.505293], [50.471353, 30.505527], [50.47148, 30.505713], [50.471806, 30.506192], [50.47217, 30.506726], [50.472182, 30.506743], [50.472235, 30.506821], [50.472292, 30.506905], [50.472322, 30.506946], [50.472718, 30.507516], [50.473328, 30.508395], [50.473415, 30.508462], [50.473457, 30.508476], [50.473484, 30.50848], [50.47382, 30.508489], [50.473875, 30.50849], [50.473964, 30.508497], [50.473964, 30.508647], [50.473962, 30.508872], [50.473949, 30.510241], [50.473948, 30.510363], [50.473947, 30.510476], [50.473946, 30.510679], [50.473944, 30.511623], [50.473943, 30.511781], [50.473942, 30.511841], [50.473943, 30.511925], [50.473943, 30.511965], [50.473939, 30.512747], [50.473938, 30.512929], [50.473931, 30.51351], [50.47393, 30.513599], [50.47393, 30.513743], [50.473929, 30.514686], [50.473931, 30.516334], [50.473931, 30.516419], [50.473931, 30.516552], [50.473541, 30.517173], [50.473483, 30.517265], [50.472504, 30.518828], [50.47172, 30.520061], [50.471678, 30.520129], [50.471607, 30.520242], [50.471376, 30.520614], [50.471125, 30.521017], [50.470665, 30.521747], [50.470557, 30.521918], [50.469785, 30.523143], [50.469745, 30.523207], [50.469673, 30.523325], [50.469438, 30.523704], [50.469345, 30.523839], [50.469264, 30.523941], [50.469202, 30.52399], [50.469111, 30.52404], [50.4681, 30.524345], [50.467316, 30.524573], [50.467131, 30.524622], [50.466357, 30.524812], [50.465294, 30.525038], [50.464562, 30.525193], [50.463845, 30.525335], [50.463195, 30.525465], [50.46142, 30.525848], [50.460793, 30.525965], [50.460654, 30.525991], [50.46057, 30.526006], [50.459913, 30.526113], [50.459782, 30.526135], [50.45962, 30.526162], [50.459192, 30.526297], [50.458943, 30.526397], [50.458736, 30.526508], [50.458558, 30.526677], [50.458453, 30.526804], [50.458351, 30.526957], [50.458133, 30.527328], [50.45684, 30.529597], [50.456365, 30.530444], [50.456107, 30.530906], [50.455975, 30.531161], [50.45588, 30.531353], [50.455727, 30.531696], [50.455522, 30.532181], [50.455353, 30.532586], [50.455061, 30.533306], [50.454859, 30.533794], [50.454592, 30.534464], [50.454246, 30.535349], [50.453996, 30.53598], [50.453717, 30.536706], [50.453336, 30.537682], [50.452824, 30.539007], [50.452443, 30.53999], [50.452163, 30.540683], [50.45189, 30.541369], [50.451656, 30.541915], [50.451167, 30.543003], [50.451017, 30.543339], [50.450594, 30.544222], [50.450027, 30.545358], [50.449361, 30.546691], [50.44869, 30.54803], [50.448104, 30.5492], [50.44753, 30.550346], [50.447054, 30.551305], [50.446745, 30.551909], [50.446524, 30.552318], [50.446282, 30.552728], [50.446035, 30.553125], [50.445763, 30.553529], [50.444956, 30.554661], [50.444462, 30.555335], [50.44368, 30.556395], [50.443341, 30.55682], [50.443021, 30.557226], [50.442426, 30.55791], [50.442112, 30.558133], [50.441359, 30.558847], [50.441251, 30.558947], [50.441049, 30.559134], [50.440836, 30.55933], [50.440455, 30.559682], [50.440328, 30.559717], [50.440216, 30.559729], [50.440128, 30.559735], [50.440053, 30.559747], [50.439977, 30.559776], [50.439912, 30.559811], [50.439537, 30.560138], [50.437266, 30.562054], [50.436702, 30.562542], [50.436657, 30.56264], [50.43664, 30.562693], [50.436639, 30.562751], [50.436649, 30.56281], [50.436679, 30.562866], [50.436774, 30.562957], [50.437181, 30.562906], [50.437482, 30.562864], [50.437669, 30.562828], [50.43777, 30.562804], [50.437868, 30.562762], [50.438011, 30.562665], [50.438504, 30.562241], [50.439044, 30.561761], [50.439432, 30.561406], [50.439733, 30.561137], [50.440222, 30.560692], [50.440722, 30.560254], [50.441063, 30.559914], [50.441148, 30.559862], [50.441232, 30.559885], [50.441289, 30.559938], [50.44132, 30.559985], [50.443838, 30.568963], [50.443926, 30.56934], [50.443955, 30.569439], [50.444133, 30.570041], [50.44429, 30.570442], [50.444369, 30.570609], [50.444426, 30.570757], [50.444469, 30.570943], [50.446093, 30.576827], [50.447553, 30.582121], [50.448834, 30.586738], [50.450514, 30.592808], [50.451434, 30.596056], [50.45145, 30.596111], [50.45146, 30.596147], [50.451549, 30.596473], [50.451906, 30.597779], [50.452077, 30.598403], [50.452535, 30.600041], [50.452585, 30.600222], [50.452657, 30.600466], [50.452886, 30.601301], [50.453132, 30.602183], [50.45333, 30.60287], [50.453548, 30.603636], [50.454575, 30.607132], [50.454603, 30.607233], [50.454735, 30.607289], [50.454878, 30.60735], [50.45527, 30.607516], [50.455543, 30.60763], [50.455779, 30.607726], [50.455932, 30.607791], [50.456002, 30.607819], [50.456214, 30.607802], [50.456345, 30.607766], [50.456478, 30.607694], [50.456626, 30.607577], [50.456753, 30.607427], [50.456974, 30.60712], [50.457137, 30.60661], [50.457502, 30.605622], [50.457868, 30.60479], [50.45811, 30.604402], [50.458293, 30.604209], [50.458567, 30.603919], [50.458705, 30.603776], [50.461684, 30.600676], [50.461899, 30.600493], [50.46199, 30.600415], [50.462271, 30.600278], [50.462417, 30.600234], [50.463244, 30.60013], [50.464242, 30.600008], [50.464761, 30.599944], [50.464844, 30.599933], [50.465138, 30.59986], [50.465165, 30.599869], [50.465261, 30.599902], [50.465368, 30.599938], [50.465467, 30.59997], [50.465621, 30.600054], [50.465748, 30.600121], [50.465916, 30.600214], [50.466301, 30.600456], [50.466343, 30.600484], [50.466414, 30.600901], [50.466478, 30.60128], [50.466662, 30.602342], [50.466716, 30.602655], [50.466729, 30.602731], [50.466753, 30.60287], [50.466759, 30.602958], [50.466751, 30.603029], [50.466701, 30.603051], [50.466499, 30.60314], [50.466477, 30.603133], [50.466456, 30.603113], [50.466445, 30.603084], [50.466345, 30.602549], [50.466347, 30.602516], [50.466359, 30.602483], [50.466384, 30.602463], [50.466582, 30.602377], [50.46663, 30.602356], [50.466662, 30.602342], [50.466559, 30.601747], [50.466478, 30.60128], [50.466629, 30.600651], [50.467322, 30.601032], [50.46739, 30.601068], [50.467831, 30.601303], [50.468063, 30.601357], [50.468269, 30.601349], [50.46832, 30.601344], [50.468364, 30.601336], [50.468635, 30.601275], [50.468712, 30.601258], [50.46908, 30.601223], [50.469333, 30.601218], [50.469496, 30.601257], [50.469628, 30.601288], [50.469875, 30.601355], [50.47002, 30.601431], [50.470119, 30.601499], [50.470498, 30.601756], [50.470578, 30.601802], [50.470654, 30.601859], [50.470791, 30.601966], [50.470847, 30.601993], [50.471013, 30.602062], [50.471184, 30.602086], [50.471608, 30.602135], [50.471656, 30.602141], [50.471629, 30.602961], [50.471638, 30.603849], [50.471647, 30.604647], [50.471661, 30.605884], [50.47168, 30.607596], [50.47168, 30.607614], [50.471722, 30.610131], [50.471745, 30.611373], [50.47187, 30.611429], [50.471919, 30.611464], [50.471964, 30.611522], [50.471991, 30.611567], [50.472317, 30.61211], [50.472399, 30.612256], [50.472102, 30.61269], [50.471991, 30.61289], [50.471911, 30.613092], [50.471779, 30.613508], [50.471623, 30.613989], [50.471556, 30.614197], [50.471379, 30.614721], [50.471352, 30.614802], [50.471333, 30.614857], [50.470826, 30.616365], [50.470484, 30.617432], [50.470222, 30.61822], [50.470013, 30.618832], [50.469358, 30.620828], [50.469221, 30.621228], [50.469184, 30.621335], [50.468935, 30.622103], [50.468656, 30.622855], [50.468538, 30.623141], [50.468189, 30.623826], [50.468072, 30.624024], [50.467768, 30.624429], [50.467567, 30.624671], [50.467361, 30.624888], [50.467185, 30.625057], [50.467016, 30.625198], [50.465154, 30.626525], [50.463418, 30.627767], [50.463242, 30.627885], [50.462606, 30.628311], [50.462072, 30.628668], [50.461937, 30.628763], [50.461148, 30.62932], [50.461054, 30.629385], [50.460568, 30.629717], [50.460405, 30.629828], [50.459945, 30.630155], [50.459612, 30.630379], [50.459365, 30.630527], [50.4592, 30.630643], [50.458452, 30.631182], [50.458393, 30.631223], [50.457509, 30.631837], [50.457377, 30.631923], [50.455841, 30.632973], [50.45573, 30.633025], [50.455606, 30.63306], [50.455504, 30.633089], [50.455372, 30.633081], [50.455061, 30.632897], [50.454903, 30.632798], [50.452627, 30.631381], [50.452436, 30.631229], [50.452321, 30.631131], [50.452112, 30.630963], [50.45156, 30.630563], [50.45151, 30.630526], [50.451306, 30.630399], [50.450884, 30.630158], [50.450427, 30.629896], [50.449685, 30.629472], [50.44834, 30.628656], [50.447416, 30.628096], [50.447198, 30.627963], [50.445813, 30.627126], [50.445394, 30.626873], [50.445301, 30.626817], [50.444138, 30.626126], [50.444086, 30.626312], [50.443868, 30.627185], [50.443741, 30.627686], [50.443499, 30.628668], [50.443468, 30.62879], [50.443249, 30.628648], [50.443164, 30.628593], [50.442182, 30.628039], [50.441958, 30.627909], [50.441825, 30.627825], [50.441781, 30.627889], [50.441757, 30.627925], [50.441661, 30.628064], [50.441628, 30.628166], [50.441609, 30.628248], [50.441358, 30.629409], [50.441305, 30.629386], [50.441004, 30.629253], [50.440956, 30.629214], [50.440898, 30.629141], [50.440841, 30.629056], [50.440825, 30.629026], [50.440048, 30.629495], [50.439603, 30.629769], [50.439272, 30.629964], [50.438885, 30.63019], [50.438472, 30.630437], [50.438452, 30.630453], [50.438444, 30.630481], [50.438448, 30.630517], [50.438492, 30.630707], [50.438191, 30.630893], [50.438105, 30.630536], [50.437819, 30.63071], [50.437675, 30.630798], [50.43769, 30.630857], [50.437761, 30.631164], [50.437976, 30.632106], [50.438172, 30.632916], [50.438199, 30.633036], [50.438346, 30.63363], [50.438344, 30.633689], [50.438327, 30.63374], [50.438264, 30.633777], [50.438108, 30.633791]], "routeDbId": 30, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0432\\u0443\\u043b. \\u0412\\u043e\\u0441\\u043a\\u0440\\u0435\\u0441\\u0435\\u043d\\u0441\\u044c\\u043a\\u0430 2\\u0432 ", "delivery_window_end": "10:00", "delivery_window_start": "09:00", "driveMin": 24, "eta": "09:15", "id": 191, "lat": 50.4664095, "lng": 30.6018108, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u043f\\u0440\\u043e\\u0432\\u0443\\u043b\\u043e\\u043a \\u041b\\u043e\\u0431\\u0430\\u0447\\u0435\\u0432\\u0441\\u044c\\u043a\\u043e\\u0433\\u043e  7 ", "delivery_window_end": "12:00", "delivery_window_start": "09:12", "driveMin": 13, "eta": "09:43", "id": 139, "lat": 50.4381187, "lng": 30.6341096, "serviceMin": 15, "stopOrder": 2, "waitMin": 0}], "totalDistanceKm": 21.28, "totalDriveMin": 37}]}	2026-04-25 17:34:05.355388	08:51:00
24	\N	2026-04-27	draft	\N	1	24.76	21	\N	\N	\N	\N	2026-04-24 18:18:44.022513	2026-04-24 18:18:44.022516	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "droppedOrders": 0, "stats": {"autoCouriers": true, "numCouriers": 2, "serviceTimePerStop": 15, "timeBufferMin": 15, "totalDeliveries": 4, "totalDistanceKm": 55.9, "totalDriveMin": 51}, "_selectedDate": "2026-04-27", "routes": [{"courierId": 1, "geometry": [[50.473297, 30.482599], [50.47286, 30.48312], [50.472523, 30.483521], [50.471796, 30.484387], [50.471599, 30.484617], [50.4715, 30.484745], [50.471425, 30.484739], [50.471143, 30.48472], [50.470095, 30.484633], [50.470035, 30.48463], [50.469514, 30.484576], [50.46943, 30.484566], [50.46933, 30.484554], [50.469287, 30.484549], [50.468778, 30.484485], [50.46855, 30.484456], [50.467979, 30.484417], [50.46755, 30.484372], [50.466593, 30.484306], [50.46638, 30.4843], [50.465773, 30.484204], [50.465128, 30.484187], [50.465087, 30.484195], [50.465053, 30.485097], [50.465015, 30.486084], [50.465013, 30.486138], [50.464733, 30.486146], [50.464583, 30.486157], [50.464277, 30.486229], [50.463933, 30.486322], [50.463888, 30.486335], [50.463701, 30.486417], [50.463622, 30.486451], [50.463419, 30.486543], [50.462957, 30.486742], [50.462463, 30.486928], [50.462405, 30.486941], [50.462109, 30.486979], [50.462068, 30.486981], [50.461003, 30.486739], [50.460935, 30.486724], [50.46093, 30.48667], [50.460916, 30.486612], [50.460894, 30.486551], [50.460585, 30.48576], [50.46039, 30.485273], [50.460294, 30.485034], [50.460268, 30.484984], [50.460224, 30.484934], [50.460201, 30.484908], [50.460192, 30.484918], [50.46011, 30.485007], [50.459865, 30.485272], [50.459674, 30.48547], [50.459117, 30.486047], [50.459081, 30.486086], [50.458822, 30.486347], [50.458756, 30.486409], [50.458568, 30.486342], [50.457946, 30.486118], [50.457929, 30.486111], [50.457911, 30.486105], [50.457465, 30.48595], [50.457313, 30.485897], [50.456786, 30.485693], [50.454439, 30.484761], [50.454347, 30.484725], [50.454277, 30.484697], [50.454239, 30.484682], [50.454153, 30.484651], [50.453957, 30.484575], [50.453036, 30.484221], [50.452804, 30.484126], [50.452455, 30.483985], [50.451795, 30.483717], [50.451643, 30.483655], [50.450883, 30.483337], [50.450633, 30.483231], [50.449986, 30.482956], [50.449852, 30.482898], [50.449434, 30.482717], [50.449038, 30.482552], [50.448858, 30.482487], [50.44875, 30.482441], [50.448657, 30.482402], [50.448295, 30.48225], [50.448175, 30.4822], [50.448053, 30.482149], [50.447672, 30.482006], [50.447493, 30.481943], [50.447195, 30.481836], [50.447104, 30.481803], [50.447045, 30.481783], [50.447003, 30.481768], [50.446983, 30.481761], [50.446876, 30.481723], [50.446836, 30.481709], [50.446761, 30.481683], [50.446426, 30.481559], [50.445933, 30.481351], [50.445209, 30.481036], [50.444935, 30.480926], [50.444218, 30.480635], [50.444136, 30.480605], [50.444052, 30.480579], [50.44388, 30.480537], [50.443743, 30.480504], [50.443668, 30.480489], [50.443439, 30.480445], [50.443221, 30.480386], [50.442996, 30.480312], [50.441991, 30.479925], [50.441727, 30.479818], [50.441586, 30.479758], [50.441324, 30.479626], [50.440947, 30.479401], [50.440863, 30.479331], [50.440467, 30.479016], [50.440099, 30.47867], [50.439909, 30.47848], [50.439543, 30.478048], [50.439488, 30.477983], [50.439383, 30.477848], [50.439096, 30.477419], [50.438327, 30.476173], [50.437961, 30.475528], [50.437903, 30.475426], [50.437854, 30.47535], [50.437801, 30.475269], [50.437646, 30.475062], [50.437411, 30.474784], [50.436931, 30.47431], [50.436201, 30.473568], [50.435984, 30.473367], [50.434863, 30.472301], [50.434819, 30.472259], [50.434744, 30.472184], [50.434639, 30.472082], [50.434215, 30.471665], [50.433735, 30.471196], [50.432877, 30.470358], [50.432112, 30.469603], [50.431986, 30.469473], [50.431816, 30.469305], [50.431587, 30.469074], [50.429595, 30.467063], [50.429264, 30.466712], [50.428873, 30.466337], [50.428701, 30.466157], [50.428619, 30.46606], [50.428475, 30.465897], [50.428413, 30.46581], [50.428259, 30.465519], [50.428145, 30.465276], [50.427609, 30.464138], [50.427424, 30.463743], [50.427384, 30.463659], [50.426971, 30.462781], [50.426319, 30.461375], [50.4258, 30.460259], [50.425769, 30.460122], [50.425753, 30.459905], [50.425778, 30.459819], [50.42579, 30.459681], [50.425787, 30.459566], [50.425759, 30.459443], [50.425714, 30.459331], [50.425627, 30.459223], [50.425442, 30.459073], [50.425308, 30.45898], [50.4252, 30.458904], [50.424946, 30.458726], [50.424534, 30.458428], [50.424487, 30.458394], [50.42431, 30.458265], [50.424017, 30.458052], [50.423697, 30.457811], [50.423597, 30.457695], [50.423062, 30.457112], [50.422287, 30.456266], [50.422178, 30.456148], [50.421865, 30.455808], [50.421674, 30.4556], [50.421583, 30.455496], [50.421504, 30.455412], [50.421356, 30.455255], [50.421088, 30.454968], [50.420667, 30.454511], [50.420585, 30.454421], [50.420289, 30.454097], [50.420241, 30.454045], [50.420174, 30.453971], [50.420002, 30.453784], [50.419642, 30.45339], [50.419359, 30.45308], [50.419189, 30.452895], [50.419013, 30.452702], [50.418732, 30.452395], [50.418477, 30.452118], [50.418475, 30.452116], [50.41847, 30.45211], [50.418413, 30.452048], [50.41836, 30.451985], [50.418176, 30.451756], [50.417225, 30.450583], [50.417111, 30.450443], [50.41701, 30.450311], [50.416997, 30.450293], [50.416385, 30.449501], [50.416231, 30.449293], [50.415901, 30.44884], [50.415527, 30.448308], [50.415438, 30.448183], [50.415411, 30.448139], [50.415303, 30.447972], [50.415213, 30.447833], [50.415069, 30.447609], [50.41498, 30.447479], [50.414839, 30.447016], [50.41475, 30.446722], [50.414674, 30.44646], [50.414613, 30.446201], [50.414586, 30.446016], [50.414569, 30.445897], [50.414546, 30.445622], [50.414533, 30.445], [50.414532, 30.444601], [50.414555, 30.443515], [50.414561, 30.442866], [50.414558, 30.442436], [50.414528, 30.441975], [50.414504, 30.441702], [50.414453, 30.44141], [50.414384, 30.441139], [50.414334, 30.440968], [50.414273, 30.440767], [50.414201, 30.440552], [50.414013, 30.440132], [50.413786, 30.439785], [50.413528, 30.439488], [50.413417, 30.439389], [50.413149, 30.43915], [50.412805, 30.438894], [50.412672, 30.438794], [50.412011, 30.438301], [50.411266, 30.437745], [50.411325, 30.437555], [50.412037, 30.435381], [50.412421, 30.434206], [50.412516, 30.433943], [50.412617, 30.433695], [50.412635, 30.433626], [50.412659, 30.433453], [50.412662, 30.433381], [50.412653, 30.433265], [50.412622, 30.433088], [50.412582, 30.432962], [50.412539, 30.432859], [50.412457, 30.432751], [50.412371, 30.432696], [50.412113, 30.432567], [50.411161, 30.431932], [50.409081, 30.430542], [50.408867, 30.430394], [50.408568, 30.430144], [50.408444, 30.430077], [50.40825, 30.430017], [50.408107, 30.429975], [50.407835, 30.429891], [50.40756, 30.429821], [50.407514, 30.429796], [50.407378, 30.429705], [50.407126, 30.429517], [50.40683, 30.429237], [50.406458, 30.428881], [50.406167, 30.42864], [50.405031, 30.427856], [50.404081, 30.427146], [50.403652, 30.426741], [50.403217, 30.426317], [50.402467, 30.425549], [50.401907, 30.424887], [50.401649, 30.424573], [50.40148, 30.424366], [50.400996, 30.423711], [50.400503, 30.422979], [50.399684, 30.421589], [50.398976, 30.420397], [50.39876, 30.419958], [50.398315, 30.419138], [50.397705, 30.417901], [50.397556, 30.417555], [50.396376, 30.414566], [50.39625, 30.414385], [50.396193, 30.414321], [50.396131, 30.414281], [50.396041, 30.414257], [50.395961, 30.414257], [50.395884, 30.414298], [50.395831, 30.414357], [50.395775, 30.414436], [50.39573, 30.414568], [50.395715, 30.414668], [50.395707, 30.414781], [50.395719, 30.414932], [50.395733, 30.415064], [50.395751, 30.415293], [50.395929, 30.415836], [50.396228, 30.416764], [50.396358, 30.417189], [50.39701, 30.419266], [50.397064, 30.419438], [50.397121, 30.41963], [50.397218, 30.419963], [50.397511, 30.420845], [50.39753, 30.420904], [50.397801, 30.421663], [50.398065, 30.422347], [50.39817, 30.422614], [50.398224, 30.42275], [50.398109, 30.422884], [50.398055, 30.422975], [50.397829, 30.423532], [50.397815, 30.423699], [50.397607, 30.4243], [50.397593, 30.424343], [50.397206, 30.42532], [50.396433, 30.427173], [50.396158, 30.427824], [50.396027, 30.428096], [50.395767, 30.428563]], "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u043f\\u0440\\u043e\\u0432\\u0443\\u043b\\u043e\\u043a \\u0428\\u0435\\u0432\\u0447\\u0435\\u043d\\u043a\\u0430 34 ", "driveMin": 21, "eta": "15:00", "lat": 50.3956388, "lng": 30.4283882, "serviceMin": 15, "timeEnd": "17:00", "timeStart": "15:00", "waitMin": 0}], "suggestedDepartureTime": "14:39", "totalDistanceKm": 24.76, "totalDriveMin": 21, "departureTime": "14:39"}]}	2026-04-24 18:18:44.022029	14:39:00
25	\N	2026-04-27	draft	\N	3	31.14	30	\N	\N	\N	\N	2026-04-24 18:18:44.025287	2026-04-24 18:18:44.025291	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "droppedOrders": 0, "stats": {"autoCouriers": true, "numCouriers": 2, "serviceTimePerStop": 15, "timeBufferMin": 15, "totalDeliveries": 4, "totalDistanceKm": 55.9, "totalDriveMin": 51}, "_selectedDate": "2026-04-27", "routes": [{"courierId": 3, "geometry": [[50.473297, 30.482599], [50.47286, 30.48312], [50.472523, 30.483521], [50.471796, 30.484387], [50.471599, 30.484617], [50.4715, 30.484745], [50.471425, 30.484739], [50.471143, 30.48472], [50.470095, 30.484633], [50.470035, 30.48463], [50.469514, 30.484576], [50.46943, 30.484566], [50.46933, 30.484554], [50.469287, 30.484549], [50.468778, 30.484485], [50.46855, 30.484456], [50.467979, 30.484417], [50.46755, 30.484372], [50.466593, 30.484306], [50.46638, 30.4843], [50.465773, 30.484204], [50.465128, 30.484187], [50.465087, 30.484195], [50.465053, 30.485097], [50.465015, 30.486084], [50.465013, 30.486138], [50.464733, 30.486146], [50.464583, 30.486157], [50.464277, 30.486229], [50.463933, 30.486322], [50.463888, 30.486335], [50.463701, 30.486417], [50.463622, 30.486451], [50.463419, 30.486543], [50.462957, 30.486742], [50.462463, 30.486928], [50.462405, 30.486941], [50.462109, 30.486979], [50.462068, 30.486981], [50.461003, 30.486739], [50.460935, 30.486724], [50.46093, 30.48667], [50.460916, 30.486612], [50.460894, 30.486551], [50.460585, 30.48576], [50.46039, 30.485273], [50.460294, 30.485034], [50.460268, 30.484984], [50.460224, 30.484934], [50.460201, 30.484908], [50.460192, 30.484918], [50.46011, 30.485007], [50.459865, 30.485272], [50.459674, 30.48547], [50.459117, 30.486047], [50.459081, 30.486086], [50.459006, 30.485912], [50.458982, 30.485857], [50.458739, 30.485265], [50.458729, 30.485243], [50.458722, 30.485227], [50.458761, 30.485186], [50.458985, 30.484945], [50.459561, 30.484353], [50.459591, 30.484322], [50.459853, 30.484076], [50.459848, 30.484065], [50.459824, 30.484025], [50.459784, 30.483946], [50.459759, 30.483892], [50.459271, 30.482707], [50.459203, 30.48254], [50.458883, 30.481721], [50.45866, 30.481155], [50.458619, 30.48102], [50.458573, 30.480888], [50.458545, 30.480787], [50.458498, 30.480555], [50.458434, 30.480504], [50.458395, 30.480444], [50.458361, 30.480389], [50.458301, 30.48023], [50.458253, 30.480105], [50.458011, 30.479483], [50.45793, 30.479271], [50.457734, 30.478764], [50.457776, 30.478729], [50.457928, 30.478602], [50.45816, 30.478416], [50.458029, 30.478051], [50.458029, 30.478051], [50.45816, 30.478416], [50.457928, 30.478602], [50.457776, 30.478729], [50.457734, 30.478764], [50.45793, 30.479271], [50.458011, 30.479483], [50.458253, 30.480105], [50.458301, 30.48023], [50.458361, 30.480389], [50.458282, 30.480353], [50.45823, 30.480331], [50.456382, 30.479644], [50.455627, 30.47936], [50.455315, 30.479229], [50.455241, 30.479188], [50.455189, 30.47916], [50.455153, 30.479136], [50.455108, 30.479103], [50.455051, 30.479068], [50.454831, 30.478969], [50.454135, 30.478665], [50.453401, 30.47833], [50.452757, 30.478003], [50.45259, 30.477917], [50.452577, 30.477985], [50.452528, 30.478292], [50.452484, 30.478561], [50.452293, 30.479718], [50.452277, 30.479815], [50.452148, 30.480593], [50.452133, 30.480683], [50.451979, 30.481619], [50.45196, 30.481732], [50.451857, 30.482358], [50.451805, 30.482677], [50.451675, 30.483452], [50.451659, 30.483553], [50.451643, 30.483655], [50.450883, 30.483337], [50.450633, 30.483231], [50.449986, 30.482956], [50.449852, 30.482898], [50.449434, 30.482717], [50.449038, 30.482552], [50.448858, 30.482487], [50.44875, 30.482441], [50.448657, 30.482402], [50.448295, 30.48225], [50.448175, 30.4822], [50.448053, 30.482149], [50.447672, 30.482006], [50.447493, 30.481943], [50.447195, 30.481836], [50.447104, 30.481803], [50.447045, 30.481783], [50.447003, 30.481768], [50.446983, 30.481761], [50.446876, 30.481723], [50.446836, 30.481709], [50.446761, 30.481683], [50.446426, 30.481559], [50.445933, 30.481351], [50.445209, 30.481036], [50.444935, 30.480926], [50.444218, 30.480635], [50.444136, 30.480605], [50.444052, 30.480579], [50.44388, 30.480537], [50.443743, 30.480504], [50.443668, 30.480489], [50.443439, 30.480445], [50.443221, 30.480386], [50.442996, 30.480312], [50.441991, 30.479925], [50.441727, 30.479818], [50.441586, 30.479758], [50.441324, 30.479626], [50.440947, 30.479401], [50.440863, 30.479331], [50.440467, 30.479016], [50.440099, 30.47867], [50.439909, 30.47848], [50.439543, 30.478048], [50.439488, 30.477983], [50.439383, 30.477848], [50.439096, 30.477419], [50.438327, 30.476173], [50.437961, 30.475528], [50.437903, 30.475426], [50.437854, 30.47535], [50.437801, 30.475269], [50.437646, 30.475062], [50.437411, 30.474784], [50.436931, 30.47431], [50.436201, 30.473568], [50.435984, 30.473367], [50.434863, 30.472301], [50.434819, 30.472259], [50.434744, 30.472184], [50.434639, 30.472082], [50.434215, 30.471665], [50.433735, 30.471196], [50.432877, 30.470358], [50.432112, 30.469603], [50.431986, 30.469473], [50.431816, 30.469305], [50.431587, 30.469074], [50.429595, 30.467063], [50.429264, 30.466712], [50.429213, 30.466851], [50.429167, 30.466898], [50.428842, 30.467222], [50.428808, 30.467256], [50.428429, 30.467653], [50.428072, 30.468025], [50.428051, 30.468048], [50.426678, 30.46958], [50.426147, 30.47022], [50.426124, 30.470254], [50.425238, 30.471581], [50.425208, 30.471627], [50.425173, 30.471586], [50.425154, 30.471564], [50.42464, 30.470956], [50.424616, 30.470928], [50.424202, 30.470428], [50.424001, 30.470186], [50.423787, 30.469926], [50.423658, 30.469769], [50.423606, 30.469707], [50.42316, 30.469169], [50.422847, 30.468792], [50.422564, 30.46845], [50.422152, 30.467946], [50.422079, 30.467857], [50.422034, 30.467805], [50.421262, 30.469544], [50.420993, 30.47015], [50.42074, 30.470737], [50.420647, 30.470955], [50.420415, 30.471493], [50.419558, 30.473453], [50.419136, 30.474417], [50.418566, 30.47571], [50.418376, 30.476178], [50.418212, 30.476558], [50.417807, 30.477489], [50.417543, 30.478028], [50.417473, 30.47811], [50.417401, 30.478166], [50.417284, 30.478245], [50.416602, 30.478666], [50.415996, 30.479062], [50.415293, 30.479554], [50.415009, 30.479747], [50.414831, 30.479889], [50.414756, 30.479953], [50.414594, 30.480105], [50.414365, 30.480319], [50.414223, 30.480456], [50.413905, 30.480909], [50.413806, 30.48105], [50.413642, 30.481299], [50.412629, 30.483351], [50.412482, 30.483644], [50.412355, 30.483897], [50.412095, 30.484419], [50.411773, 30.485085], [50.411595, 30.485451], [50.411356, 30.485928], [50.411242, 30.486174], [50.410545, 30.487569], [50.410056, 30.488537], [50.409536, 30.489601], [50.408881, 30.490953], [50.408767, 30.491204], [50.408601, 30.491569], [50.40858, 30.491624], [50.408555, 30.491683], [50.408458, 30.491906], [50.408312, 30.491792], [50.408248, 30.491744], [50.408151, 30.491671], [50.40801, 30.49157], [50.407748, 30.491383], [50.40744, 30.491164], [50.407195, 30.491026], [50.406897, 30.490857], [50.406696, 30.490778], [50.406567, 30.490727], [50.406446, 30.490701], [50.406277, 30.490686], [50.406103, 30.490661], [50.405406, 30.490573], [50.404919, 30.490454], [50.404512, 30.490324], [50.404051, 30.490155], [50.403486, 30.489901], [50.402979, 30.489668], [50.402736, 30.489563], [50.402252, 30.489288], [50.401784, 30.489002], [50.401322, 30.488686], [50.401042, 30.488415], [50.400704, 30.488027], [50.400488, 30.487746], [50.4002, 30.487337], [50.399893, 30.486885], [50.399872, 30.486852], [50.399737, 30.486644], [50.399624, 30.486447], [50.399317, 30.486004], [50.399249, 30.48588], [50.399112, 30.485632], [50.39897, 30.485373], [50.398579, 30.484401], [50.398484, 30.48413], [50.398425, 30.483946], [50.398241, 30.483364], [50.397911, 30.48187], [50.397585, 30.480339], [50.397542, 30.480136], [50.397501, 30.479942], [50.397489, 30.479871], [50.397452, 30.479589], [50.397392, 30.478953], [50.39734, 30.478813], [50.397235, 30.47877], [50.397111, 30.478786], [50.397082, 30.478703], [50.396905, 30.47819], [50.396884, 30.478054], [50.396759, 30.477244], [50.396711, 30.477196], [50.396335, 30.477336], [50.396052, 30.477442], [50.396002, 30.477509], [50.396066, 30.478007], [50.396043, 30.478175], [50.39607, 30.478333], [50.396193, 30.479046], [50.396198, 30.479075], [50.396209, 30.479141], [50.396086, 30.479191], [50.39588, 30.479255], [50.395771, 30.479273], [50.395635, 30.479289], [50.395523, 30.479288], [50.394246, 30.479186], [50.393758, 30.479153], [50.393546, 30.479138], [50.393196, 30.479104], [50.39297, 30.479082], [50.392875, 30.479105], [50.392883, 30.479223], [50.392931, 30.479863], [50.392984, 30.480619], [50.392988, 30.480688], [50.393012, 30.481025], [50.393039, 30.481564], [50.393044, 30.481778], [50.393053, 30.482125], [50.393049, 30.484054], [50.393049, 30.484223], [50.39274, 30.48475], [50.392607, 30.484969], [50.39245, 30.48469], [50.392434, 30.484667], [50.392343, 30.484533], [50.392208, 30.484369], [50.392048, 30.484206], [50.391788, 30.484006], [50.391564, 30.48386], [50.390407, 30.483105], [50.390246, 30.482999], [50.390084, 30.482891], [50.389952, 30.482801], [50.389877, 30.482751], [50.389809, 30.482644], [50.389496, 30.48244], [50.387925, 30.481428], [50.387766, 30.481318], [50.387724, 30.48129], [50.38724, 30.480968], [50.386952, 30.480777], [50.386893, 30.480737], [50.386465, 30.480453], [50.386403, 30.480415], [50.38587, 30.480055], [50.385571, 30.479848], [50.385358, 30.479701], [50.385008, 30.479461], [50.384596, 30.479197], [50.384035, 30.478834], [50.383376, 30.478423], [50.383224, 30.478343], [50.382992, 30.478223], [50.38242, 30.477937], [50.381885, 30.477662], [50.381707, 30.477569], [50.381633, 30.47753], [50.381384, 30.477396], [50.381341, 30.477373], [50.381284, 30.47734], [50.381197, 30.47729], [50.380841, 30.476342], [50.380297, 30.474973], [50.379976, 30.474166], [50.379648, 30.473385], [50.379361, 30.472777], [50.379043, 30.472092], [50.378599, 30.471226], [50.378286, 30.470673], [50.378127, 30.470416], [50.37758, 30.469598], [50.377455, 30.469408], [50.376674, 30.468218], [50.376579, 30.468074], [50.37617, 30.467425], [50.375839, 30.46694], [50.375603, 30.466607], [50.37528, 30.466126], [50.374727, 30.465283], [50.37448, 30.464896], [50.374265, 30.464553], [50.374232, 30.464501], [50.37397, 30.464103], [50.373551, 30.463466], [50.373232, 30.463004], [50.372704, 30.46222], [50.372555, 30.462], [50.371927, 30.461046], [50.370575, 30.458926], [50.370132, 30.458217], [50.369918, 30.457755], [50.369876, 30.45756], [50.369858, 30.457441], [50.369855, 30.457253], [50.369887, 30.457073], [50.369958, 30.456913], [50.370042, 30.456806], [50.370134, 30.456743], [50.370251, 30.456713], [50.370376, 30.456738], [50.370499, 30.456835], [50.370591, 30.456982], [50.370647, 30.457152], [50.370661, 30.457309], [50.370662, 30.457371], [50.370659, 30.457441], [50.370618, 30.45759], [50.370466, 30.457963], [50.370134, 30.458421], [50.369736, 30.45897], [50.369603, 30.459159], [50.369462, 30.459121], [50.369422, 30.45911], [50.369335, 30.459079], [50.369233, 30.459011], [50.369134, 30.458892], [50.369051, 30.458695], [50.369029, 30.458464], [50.369046, 30.458292], [50.369094, 30.458141], [50.369157, 30.458031], [50.369223, 30.457951], [50.369281, 30.457908], [50.369366, 30.45787], [50.369456, 30.457865], [50.369553, 30.457884], [50.369745, 30.457965], [50.369863, 30.458157], [50.370447, 30.459099], [50.371651, 30.46093], [50.371834, 30.461227], [50.37191, 30.461508], [50.371906, 30.461691], [50.371875, 30.461748], [50.371833, 30.461778], [50.371785, 30.461774], [50.371582, 30.461564], [50.371529, 30.461552], [50.3715, 30.461565], [50.371455, 30.461691], [50.371391, 30.461836], [50.371396, 30.461941], [50.371439, 30.462094], [50.371564, 30.462203], [50.371553, 30.462364], [50.371525, 30.462493], [50.371353, 30.462882]], "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u041a\\u043e\\u043f\\u0435\\u0440\\u043d\\u0456\\u043a\\u0430 12\\u0414 ", "driveMin": 5, "eta": "11:00", "lat": 50.4581954, "lng": 30.47771329999999, "serviceMin": 15, "timeEnd": "13:00", "timeStart": "11:00", "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u041e\\u0445\\u0442\\u0438\\u0440\\u0441\\u044c\\u043a\\u0438\\u0439 \\u043f\\u0440\\u043e\\u0432\\u0443\\u043b\\u043e\\u043a 7 ", "driveMin": 16, "eta": "11:31", "lat": 50.3963788, "lng": 30.4776238, "serviceMin": 15, "timeEnd": "13:00", "timeStart": "11:00", "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u041f\\u0440\\u043e\\u0441\\u043f\\u0435\\u043a\\u0442 \\u0410\\u043a\\u0430\\u0434\\u0435\\u043c\\u0456\\u043a\\u0430 \\u0413\\u043b\\u0443\\u0448\\u043a\\u043e\\u0432\\u0430 9\\u0433 ", "driveMin": 9, "eta": "11:55", "lat": 50.37118779999999, "lng": 30.46270209999999, "serviceMin": 15, "timeEnd": "13:00", "timeStart": "11:00", "waitMin": 0}], "suggestedDepartureTime": "10:55", "totalDistanceKm": 31.14, "totalDriveMin": 30, "departureTime": "10:55"}]}	2026-04-24 18:18:44.024614	10:55:00
18	4	2026-04-25	completed	\N	7	39.81	65	319	2026-04-24 17:07:03.078078	2026-04-24 17:07:08.82112	\N	2026-04-24 17:02:56.386337	2026-04-25 11:16:05.238888	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 10, "totalDeliveries": 29, "totalDistanceKm": 178.72, "totalDriveMin": 301}, "_selectedDate": "2026-04-25", "_fromDistribute": true, "routes": [{"courierId": "route_18", "courierName": "\\u0410\\u043d\\u0434\\u0440\\u0456\\u0439 (\\u0434\\u0436\\u0443\\u043d)", "departureAdjusted": false, "departureTime": "09:00", "geometry": [[50.473297, 30.482599], [50.47286, 30.48312], [50.472523, 30.483521], [50.471796, 30.484387], [50.471599, 30.484617], [50.4715, 30.484745], [50.471425, 30.484739], [50.471143, 30.48472], [50.470095, 30.484633], [50.470035, 30.48463], [50.469514, 30.484576], [50.46943, 30.484566], [50.46933, 30.484554], [50.469287, 30.484549], [50.468778, 30.484485], [50.46855, 30.484456], [50.467979, 30.484417], [50.46755, 30.484372], [50.466593, 30.484306], [50.46638, 30.4843], [50.465773, 30.484204], [50.465128, 30.484187], [50.465087, 30.484195], [50.465053, 30.485097], [50.465015, 30.486084], [50.465013, 30.486138], [50.464733, 30.486146], [50.464583, 30.486157], [50.464277, 30.486229], [50.463933, 30.486322], [50.463888, 30.486335], [50.463701, 30.486417], [50.463622, 30.486451], [50.463419, 30.486543], [50.462957, 30.486742], [50.462463, 30.486928], [50.462405, 30.486941], [50.462109, 30.486979], [50.462068, 30.486981], [50.461003, 30.486739], [50.460935, 30.486724], [50.46093, 30.48667], [50.460916, 30.486612], [50.460894, 30.486551], [50.460585, 30.48576], [50.46039, 30.485273], [50.460294, 30.485034], [50.460268, 30.484984], [50.460224, 30.484934], [50.460201, 30.484908], [50.460192, 30.484918], [50.46011, 30.485007], [50.459865, 30.485272], [50.459674, 30.48547], [50.459117, 30.486047], [50.459081, 30.486086], [50.458822, 30.486347], [50.458756, 30.486409], [50.458568, 30.486342], [50.457946, 30.486118], [50.457929, 30.486111], [50.457911, 30.486105], [50.457465, 30.48595], [50.457313, 30.485897], [50.456786, 30.485693], [50.454439, 30.484761], [50.454347, 30.484725], [50.454277, 30.484697], [50.454239, 30.484682], [50.454153, 30.484651], [50.453957, 30.484575], [50.453036, 30.484221], [50.452804, 30.484126], [50.452455, 30.483985], [50.451795, 30.483717], [50.451643, 30.483655], [50.450883, 30.483337], [50.450633, 30.483231], [50.449986, 30.482956], [50.449852, 30.482898], [50.449434, 30.482717], [50.449038, 30.482552], [50.448858, 30.482487], [50.44875, 30.482441], [50.448657, 30.482402], [50.448295, 30.48225], [50.448175, 30.4822], [50.448053, 30.482149], [50.447672, 30.482006], [50.447493, 30.481943], [50.447195, 30.481836], [50.447104, 30.481803], [50.447045, 30.481783], [50.447003, 30.481768], [50.446983, 30.481761], [50.446876, 30.481723], [50.446836, 30.481709], [50.446761, 30.481683], [50.446426, 30.481559], [50.445933, 30.481351], [50.445209, 30.481036], [50.444935, 30.480926], [50.444218, 30.480635], [50.444136, 30.480605], [50.444052, 30.480579], [50.44388, 30.480537], [50.443743, 30.480504], [50.443668, 30.480489], [50.443439, 30.480445], [50.443221, 30.480386], [50.442996, 30.480312], [50.441991, 30.479925], [50.441727, 30.479818], [50.441586, 30.479758], [50.441324, 30.479626], [50.440947, 30.479401], [50.440863, 30.479331], [50.440467, 30.479016], [50.440099, 30.47867], [50.439909, 30.47848], [50.439543, 30.478048], [50.439488, 30.477983], [50.439383, 30.477848], [50.439096, 30.477419], [50.438327, 30.476173], [50.437961, 30.475528], [50.437903, 30.475426], [50.437854, 30.47535], [50.437801, 30.475269], [50.437646, 30.475062], [50.437411, 30.474784], [50.436931, 30.47431], [50.436201, 30.473568], [50.435984, 30.473367], [50.434863, 30.472301], [50.434819, 30.472259], [50.434744, 30.472184], [50.434639, 30.472082], [50.434215, 30.471665], [50.433735, 30.471196], [50.432877, 30.470358], [50.432112, 30.469603], [50.432055, 30.469742], [50.432019, 30.469835], [50.431435, 30.471325], [50.43135, 30.471511], [50.431302, 30.471617], [50.431175, 30.471798], [50.431134, 30.471855], [50.431169, 30.471893], [50.431291, 30.472027], [50.431299, 30.472034], [50.431843, 30.472587], [50.431926, 30.472691], [50.432004, 30.472913], [50.432052, 30.473131], [50.43211, 30.473682], [50.432115, 30.473723], [50.432182, 30.474497], [50.432184, 30.474516], [50.432184, 30.474527], [50.432193, 30.474626], [50.432197, 30.474665], [50.43223, 30.475017], [50.432283, 30.47558], [50.432286, 30.475617], [50.43219, 30.475639], [50.432181, 30.475641], [50.431208, 30.475873], [50.431164, 30.475877], [50.431258, 30.47669], [50.431289, 30.476961], [50.430894, 30.477008], [50.430902, 30.477147], [50.430906, 30.477195], [50.430957, 30.477802], [50.430557, 30.478601], [50.430432, 30.478747], [50.430271, 30.478533], [50.430432, 30.478747], [50.430557, 30.478601], [50.430957, 30.477802], [50.430937, 30.477561], [50.430906, 30.477195], [50.430902, 30.477147], [50.430894, 30.477008], [50.430596, 30.477077], [50.430559, 30.47716], [50.430523, 30.477358], [50.430478, 30.477478], [50.430328, 30.477743], [50.430272, 30.477795], [50.430126, 30.477891], [50.430011, 30.477992], [50.429927, 30.478142], [50.429884, 30.478332], [50.429876, 30.478669], [50.429787, 30.47871], [50.429473, 30.478841], [50.429436, 30.478857], [50.429269, 30.478979], [50.429153, 30.479063], [50.428963, 30.479158], [50.428751, 30.47923], [50.428603, 30.479294], [50.428519, 30.479338], [50.428459, 30.47937], [50.428348, 30.478868], [50.428247, 30.47841], [50.428221, 30.478291], [50.428176, 30.478097], [50.428122, 30.477867], [50.428004, 30.477364], [50.427769, 30.476667], [50.42769, 30.476445], [50.427623, 30.476262], [50.427506, 30.47597], [50.427449, 30.475833], [50.427403, 30.475726], [50.42722, 30.475308], [50.427082, 30.474993], [50.427048, 30.474915], [50.426902, 30.474582], [50.426679, 30.474073], [50.426575, 30.473835], [50.426462, 30.473576], [50.426445, 30.473535], [50.426302, 30.473191], [50.426258, 30.473084], [50.426085, 30.472716], [50.425745, 30.472294], [50.425247, 30.471676], [50.425208, 30.471627], [50.425173, 30.471586], [50.425154, 30.471564], [50.42464, 30.470956], [50.424616, 30.470928], [50.424202, 30.470428], [50.424001, 30.470186], [50.423787, 30.469926], [50.423658, 30.469769], [50.423606, 30.469707], [50.42316, 30.469169], [50.422847, 30.468792], [50.422564, 30.46845], [50.422152, 30.467946], [50.422079, 30.467857], [50.422128, 30.467753], [50.422345, 30.467251], [50.422734, 30.466381], [50.423296, 30.465094], [50.423572, 30.464495], [50.423993, 30.463545], [50.424147, 30.463202], [50.424371, 30.462816], [50.424415, 30.46272], [50.424578, 30.462364], [50.424839, 30.461742], [50.42502, 30.461312], [50.425202, 30.460878], [50.425403, 30.460402], [50.425447, 30.460316], [50.425532, 30.460152], [50.425549, 30.460145], [50.425602, 30.46011], [50.425658, 30.460062], [50.425716, 30.459978], [50.425753, 30.459905], [50.425778, 30.459819], [50.42579, 30.459681], [50.425787, 30.459566], [50.425759, 30.459443], [50.425714, 30.459331], [50.425627, 30.459223], [50.425442, 30.459073], [50.425308, 30.45898], [50.4252, 30.458904], [50.424946, 30.458726], [50.424534, 30.458428], [50.424487, 30.458394], [50.42431, 30.458265], [50.424017, 30.458052], [50.423697, 30.457811], [50.423597, 30.457695], [50.423371, 30.457449], [50.423062, 30.457112], [50.422287, 30.456266], [50.422178, 30.456148], [50.421865, 30.455808], [50.421674, 30.4556], [50.421583, 30.455496], [50.421547, 30.455617], [50.421538, 30.455646], [50.42141, 30.456076], [50.421345, 30.456296], [50.421263, 30.456573], [50.421108, 30.457092], [50.421074, 30.457207], [50.421021, 30.457496], [50.421142, 30.457558], [50.421562, 30.457776], [50.421744, 30.457863], [50.422142, 30.458071], [50.422866, 30.458449], [50.423187, 30.458618], [50.423471, 30.458771], [50.423488, 30.458782], [50.423612, 30.458864], [50.423809, 30.459018], [50.424046, 30.459187], [50.424172, 30.459281], [50.424498, 30.459515], [50.424563, 30.459561], [50.424709, 30.459657], [50.424969, 30.459979], [50.425041, 30.4601], [50.425079, 30.460213], [50.425085, 30.460346], [50.425072, 30.460496], [50.425034, 30.46062], [50.424885, 30.460968], [50.424717, 30.46135], [50.424409, 30.46206], [50.424196, 30.462627], [50.424115, 30.462929], [50.424103, 30.462974], [50.424068, 30.463102], [50.423893, 30.463497], [50.423841, 30.463614], [50.423635, 30.464075], [50.423496, 30.4644], [50.423077, 30.465358], [50.422683, 30.466271], [50.422439, 30.466842], [50.422078, 30.467703], [50.422034, 30.467805], [50.421262, 30.469544], [50.420993, 30.47015], [50.42074, 30.470737], [50.420647, 30.470955], [50.420415, 30.471493], [50.419558, 30.473453], [50.419136, 30.474417], [50.418566, 30.47571], [50.418376, 30.476178], [50.418212, 30.476558], [50.417807, 30.477489], [50.417543, 30.478028], [50.417467, 30.478188], [50.417448, 30.478248], [50.417431, 30.478313], [50.417422, 30.478433], [50.417405, 30.478556], [50.417395, 30.478619], [50.417381, 30.47865], [50.417218, 30.479027], [50.416779, 30.480037], [50.416517, 30.480649], [50.416078, 30.481714], [50.416325, 30.481961], [50.417275, 30.482901], [50.417311, 30.482937], [50.417594, 30.483219], [50.417967, 30.483562], [50.418043, 30.483632], [50.418127, 30.48371], [50.418429, 30.483993], [50.418457, 30.484131], [50.418495, 30.484277], [50.418613, 30.484658], [50.418755, 30.485168], [50.418769, 30.485215], [50.418802, 30.485476], [50.418805, 30.485651], [50.418768, 30.485836], [50.418598, 30.486256], [50.418448, 30.486683], [50.41836, 30.487173], [50.417966, 30.488592], [50.417936, 30.4888], [50.417939, 30.488992], [50.41797, 30.489135], [50.417991, 30.489233], [50.41764, 30.490018], [50.417476, 30.490387], [50.41726, 30.490871], [50.416857, 30.491772], [50.416588, 30.491525], [50.416197, 30.491127], [50.416032, 30.490955], [50.415875, 30.490792], [50.415609, 30.490523], [50.415429, 30.490332], [50.415179, 30.490076], [50.414936, 30.489862], [50.414738, 30.489792], [50.414661, 30.489783], [50.414603, 30.489787], [50.414539, 30.48981], [50.4144, 30.489888], [50.414143, 30.490043], [50.413865, 30.490249], [50.413721, 30.490456], [50.413634, 30.490623], [50.413509, 30.490869], [50.413436, 30.491059], [50.413406, 30.491202], [50.413362, 30.491582], [50.413334, 30.491794], [50.413007, 30.494387], [50.412903, 30.495235], [50.412887, 30.495368], [50.412714, 30.496608], [50.412668, 30.496979], [50.412619, 30.497397], [50.412593, 30.497655], [50.41256, 30.49797], [50.412468, 30.498843], [50.412406, 30.499433], [50.412403, 30.499721], [50.412419, 30.500094], [50.412439, 30.500419], [50.412455, 30.50075], [50.412452, 30.501056], [50.412437, 30.501321], [50.412412, 30.501727], [50.412386, 30.502138], [50.412349, 30.502516], [50.411999, 30.503512], [50.411564, 30.504589], [50.411371, 30.504889], [50.411142, 30.505285], [50.410828, 30.505993], [50.410678, 30.506378], [50.410593, 30.506584], [50.410511, 30.50663], [50.410534, 30.5068], [50.410547, 30.506881], [50.410575, 30.50705], [50.41062, 30.507285], [50.410652, 30.507405], [50.410764, 30.507757], [50.410806, 30.507886], [50.410854, 30.508036], [50.410883, 30.508124], [50.410893, 30.508155], [50.411027, 30.508538], [50.411056, 30.508626], [50.411686, 30.510532], [50.411823, 30.511004], [50.411833, 30.511039], [50.411912, 30.511339], [50.411921, 30.511375], [50.412016, 30.51175], [50.41215, 30.512381], [50.412377, 30.51347], [50.412419, 30.513682], [50.412458, 30.513829], [50.412539, 30.51414], [50.412663, 30.514556], [50.412777, 30.514928], [50.412913, 30.51533], [50.412956, 30.515461], [50.412878, 30.515539], [50.412283, 30.516049], [50.412203, 30.516118], [50.411911, 30.516374], [50.410536, 30.517587], [50.409666, 30.518327], [50.409056, 30.518835], [50.408986, 30.518893], [50.408574, 30.518367], [50.40854, 30.518317], [50.408506, 30.518279], [50.408454, 30.518259], [50.408071, 30.518186], [50.4079, 30.518154], [50.407457, 30.51806], [50.407338, 30.518032], [50.407337, 30.517814], [50.407324, 30.517542], [50.40729, 30.517134], [50.407267, 30.51689], [50.407208, 30.516252], [50.407123, 30.516127], [50.407055, 30.516122], [50.407011, 30.516164], [50.406951, 30.516263], [50.406969, 30.517016], [50.40701, 30.517726], [50.40695, 30.517893], [50.406909, 30.517962], [50.406864, 30.518003], [50.406781, 30.518044], [50.406692, 30.518019], [50.406432, 30.517796], [50.406163, 30.517564], [50.406033, 30.517463], [50.40592, 30.517382], [50.405676, 30.517228], [50.405446, 30.517097], [50.405146, 30.516949], [50.405042, 30.516897], [50.404672, 30.516726], [50.404383, 30.516585], [50.404243, 30.516518], [50.403994, 30.516373], [50.403674, 30.516188], [50.403286, 30.515949], [50.403038, 30.515784], [50.402856, 30.515651], [50.402708, 30.515544], [50.402613, 30.515458], [50.402379, 30.515214], [50.402236, 30.515069], [50.402005, 30.514823], [50.401663, 30.514457], [50.40134, 30.514111], [50.40099, 30.513716], [50.400889, 30.513599], [50.400517, 30.513156], [50.400113, 30.512671], [50.399808, 30.512284], [50.399421, 30.511807], [50.399048, 30.51136], [50.398531, 30.510712], [50.398609, 30.510637], [50.398685, 30.510573], [50.399388, 30.511524], [50.39915, 30.511202], [50.398685, 30.510573], [50.398609, 30.510637], [50.398531, 30.510712], [50.398321, 30.510445], [50.398151, 30.510189], [50.398023, 30.509967], [50.397924, 30.509773], [50.397856, 30.509614], [50.397786, 30.509426], [50.397715, 30.50924], [50.397663, 30.509088], [50.397619, 30.508959], [50.397522, 30.508701], [50.397438, 30.508395], [50.397352, 30.508098], [50.396857, 30.506485], [50.396726, 30.506028], [50.396698, 30.505928], [50.396662, 30.505802], [50.396565, 30.505434], [50.396477, 30.505085], [50.396298, 30.504385], [50.396268, 30.504262], [50.395714, 30.502157], [50.395502, 30.501299], [50.395441, 30.50104], [50.39537, 30.500627], [50.395175, 30.499539], [50.395152, 30.499411], [50.39513, 30.499286], [50.395006, 30.498596], [50.39484, 30.497635], [50.394802, 30.497412], [50.39478, 30.49729], [50.394686, 30.496719], [50.394584, 30.496107], [50.394573, 30.496048], [50.394568, 30.496005], [50.394487, 30.495495], [50.394453, 30.495287], [50.394325, 30.494501], [50.394256, 30.494069], [50.394237, 30.493955], [50.394189, 30.493646], [50.394163, 30.493495], [50.394119, 30.493225], [50.394108, 30.493133], [50.394092, 30.493031], [50.394003, 30.492509], [50.39398, 30.492373], [50.393871, 30.491722], [50.393865, 30.491687], [50.393766, 30.491033], [50.393704, 30.49063], [50.393685, 30.490504], [50.393637, 30.490215], [50.393394, 30.488747], [50.393355, 30.488506], [50.393218, 30.487688], [50.393176, 30.487424], [50.39312, 30.487074], [50.393014, 30.48643], [50.392952, 30.486052], [50.392855, 30.48567], [50.392769, 30.485397], [50.392688, 30.485172], [50.392607, 30.484969], [50.39274, 30.48475], [50.393049, 30.484223], [50.393049, 30.484054], [50.393053, 30.482125], [50.393044, 30.481778], [50.393039, 30.481564], [50.393012, 30.481025], [50.392988, 30.480688], [50.392984, 30.480619], [50.392931, 30.479863], [50.392883, 30.479223], [50.392875, 30.479105], [50.392857, 30.47891], [50.392839, 30.478733], [50.392779, 30.478132], [50.392656, 30.476921], [50.392642, 30.476786], [50.392586, 30.476246], [50.392567, 30.476078], [50.392554, 30.475956], [50.392544, 30.475861], [50.392449, 30.47498], [50.39241, 30.474613], [50.392385, 30.474375], [50.3923, 30.473662], [50.392275, 30.473431], [50.392197, 30.472679], [50.392184, 30.472563], [50.392152, 30.472284], [50.392076, 30.471567], [50.392063, 30.471454], [50.392028, 30.471116], [50.392021, 30.471045], [50.391989, 30.470765], [50.3919, 30.469948], [50.391875, 30.469725], [50.391828, 30.469332], [50.391809, 30.469189], [50.391793, 30.469082], [50.39175, 30.468797], [50.391698, 30.468522], [50.391631, 30.468193], [50.391583, 30.468007], [50.391555, 30.467898], [50.391507, 30.467724], [50.391429, 30.46746], [50.391334, 30.467165], [50.391206, 30.466832], [50.391048, 30.466481], [50.390804, 30.465982], [50.390602, 30.465587], [50.390489, 30.465374], [50.390374, 30.465163], [50.389884, 30.464264], [50.389806, 30.464125], [50.389714, 30.463961], [50.38964, 30.463827], [50.389606, 30.463766], [50.389589, 30.463736], [50.389566, 30.463694], [50.389503, 30.463581], [50.389213, 30.463058], [50.388894, 30.462459], [50.388867, 30.462409], [50.388798, 30.462282], [50.3887, 30.462102], [50.388498, 30.461734], [50.388114, 30.461036], [50.388035, 30.460893], [50.387659, 30.460209], [50.387362, 30.459658], [50.386919, 30.458837], [50.386832, 30.458684], [50.38676, 30.45855], [50.386629, 30.458304], [50.386506, 30.458073], [50.38629, 30.457702], [50.386095, 30.457345], [50.385737, 30.456686], [50.38557, 30.456382], [50.385338, 30.455987], [50.385305, 30.455925], [50.385199, 30.455732], [50.385042, 30.455961], [50.384592, 30.456574], [50.384471, 30.456576], [50.384412, 30.45654], [50.384393, 30.456529], [50.384353, 30.456511], [50.384323, 30.456485], [50.384285, 30.45641], [50.384272, 30.456386], [50.38417, 30.456185], [50.384145, 30.456136], [50.384118, 30.456085], [50.384222, 30.455938], [50.384267, 30.455873], [50.384329, 30.455783], [50.384267, 30.455667], [50.384192, 30.455526], [50.384059, 30.455278], [50.383898, 30.455492], [50.38378, 30.455655], [50.383921, 30.455908], [50.384063, 30.456164], [50.384118, 30.456085], [50.384145, 30.456136], [50.38417, 30.456185], [50.384272, 30.456386], [50.384285, 30.45641], [50.384323, 30.456485], [50.384333, 30.456543], [50.384337, 30.456593], [50.38434, 30.456638], [50.384349, 30.456726], [50.384331, 30.456922], [50.384066, 30.457299], [50.383737, 30.457733], [50.383389, 30.458215], [50.382822, 30.458985], [50.382771, 30.459064], [50.382708, 30.459159], [50.382471, 30.459537], [50.382148, 30.460055], [50.381949, 30.460374], [50.381912, 30.460432], [50.380711, 30.462353], [50.37982, 30.463776], [50.379335, 30.464565], [50.379074, 30.46498], [50.378955, 30.465169], [50.378713, 30.465553], [50.378678, 30.465612], [50.378592, 30.465758], [50.378463, 30.465969], [50.377817, 30.467025], [50.377589, 30.467325], [50.377412, 30.467474], [50.377307, 30.46756], [50.377154, 30.467635], [50.376883, 30.467742], [50.376646, 30.46769], [50.376578, 30.467672], [50.376556, 30.467666], [50.376325, 30.467552], [50.37617, 30.467425], [50.375839, 30.46694], [50.375603, 30.466607], [50.37528, 30.466126], [50.374727, 30.465283], [50.37448, 30.464896], [50.374265, 30.464553], [50.374232, 30.464501], [50.37397, 30.464103], [50.373551, 30.463466], [50.373232, 30.463004], [50.372704, 30.46222], [50.372555, 30.462], [50.371927, 30.461046], [50.370575, 30.458926], [50.370132, 30.458217], [50.368778, 30.456101], [50.368498, 30.455698], [50.368042, 30.455029], [50.368274, 30.454633], [50.368334, 30.45473], [50.368729, 30.455306], [50.369251, 30.456056], [50.36928, 30.456077], [50.36931, 30.456089], [50.369339, 30.45609], [50.369368, 30.456083], [50.369444, 30.456037], [50.369529, 30.456004], [50.369616, 30.455996], [50.369691, 30.456007], [50.369747, 30.456037], [50.369796, 30.456089], [50.369851, 30.456161], [50.369888, 30.456209], [50.369912, 30.456226], [50.369947, 30.456238], [50.37025, 30.456272], [50.370841, 30.456289], [50.37095, 30.456262], [50.371016, 30.456229], [50.371063, 30.456178], [50.371083, 30.456155], [50.371317, 30.455873], [50.371671, 30.455377], [50.371628, 30.455305], [50.371197, 30.45466], [50.371125, 30.454553], [50.370562, 30.45373], [50.369744, 30.452473], [50.369058, 30.451443], [50.369026, 30.451395], [50.368638, 30.450822], [50.36848, 30.450585], [50.368218, 30.450171], [50.368128, 30.450044], [50.367346, 30.448852], [50.366775, 30.447992], [50.366681, 30.447823], [50.366506, 30.447512], [50.366479, 30.447463], [50.366471, 30.447333], [50.366482, 30.447212], [50.366505, 30.446957], [50.366522, 30.446771], [50.366566, 30.446273], [50.366628, 30.445589], [50.366675, 30.444674], [50.366677, 30.444074], [50.366679, 30.443539], [50.366705, 30.443016], [50.366712, 30.44281], [50.366739, 30.442111], [50.366817, 30.440117], [50.366833, 30.439703], [50.366843, 30.439454], [50.366852, 30.439196], [50.366859, 30.438983], [50.366901, 30.437705], [50.366924, 30.437201], [50.366437, 30.437059], [50.365425, 30.436744], [50.364278, 30.436442], [50.363511, 30.436279], [50.363365, 30.436248], [50.363258, 30.436223], [50.363187, 30.436175], [50.363158, 30.436119], [50.363131, 30.436009], [50.363126, 30.43591], [50.363208, 30.435114], [50.361154, 30.43501], [50.361068, 30.434987], [50.360982, 30.434924], [50.360782, 30.434644], [50.36074, 30.434573], [50.36042, 30.434133], [50.360311, 30.433976], [50.360195, 30.433809], [50.360002, 30.433505], [50.359089, 30.43218], [50.359023, 30.432286], [50.358217, 30.433621], [50.357828, 30.434258], [50.357459, 30.434869], [50.357443, 30.434897], [50.356911, 30.435787], [50.35655, 30.436401], [50.356505, 30.436547], [50.356482, 30.436669], [50.356479, 30.436785], [50.3565, 30.436918], [50.356535, 30.437011], [50.356869, 30.437563], [50.356875, 30.437646], [50.356871, 30.437744], [50.356857, 30.437796], [50.356728, 30.438051], [50.356576, 30.437829], [50.356042, 30.437008], [50.355994, 30.436939], [50.355483, 30.436198], [50.355215, 30.435796], [50.354135, 30.434195], [50.354073, 30.434102], [50.353895, 30.433839], [50.353713, 30.433569], [50.352846, 30.432269], [50.351493, 30.430277], [50.350552, 30.428883], [50.350098, 30.428198], [50.349018, 30.426568], [50.348813, 30.426258], [50.348505, 30.425774], [50.348434, 30.425663], [50.348184, 30.425296], [50.346859, 30.423298], [50.346478, 30.422719], [50.346106, 30.422192], [50.346085, 30.422161], [50.345911, 30.421906], [50.345735, 30.42165], [50.344951, 30.420477], [50.344574, 30.419915], [50.344451, 30.419729], [50.344032, 30.419109], [50.343311, 30.418053], [50.343024, 30.417633], [50.342769, 30.417254], [50.342674, 30.417112], [50.342154, 30.41634], [50.340512, 30.413915], [50.337904, 30.409997], [50.337451, 30.409316], [50.337072, 30.408746], [50.336666, 30.408135], [50.336507, 30.407895], [50.336465, 30.407831], [50.335921, 30.407025], [50.334973, 30.405657], [50.333429, 30.403363], [50.333227, 30.403083], [50.332602, 30.402188], [50.332258, 30.401678], [50.33068, 30.399324], [50.330418, 30.398934], [50.330037, 30.398407], [50.329513, 30.397733], [50.328977, 30.397043], [50.328745, 30.396778], [50.327961, 30.39588], [50.327851, 30.395758], [50.327449, 30.395367], [50.326999, 30.394927], [50.325986, 30.393889], [50.325513, 30.393272], [50.32537, 30.392988], [50.3253, 30.392839], [50.325216, 30.392649], [50.324347, 30.390524], [50.323935, 30.389471], [50.32351, 30.388394], [50.323289, 30.387814], [50.322986, 30.386992], [50.322648, 30.386041], [50.3226, 30.385908], [50.322435, 30.385444], [50.321955, 30.384131], [50.321882, 30.383926], [50.32181, 30.383738], [50.321752, 30.383592], [50.321607, 30.38327], [50.321401, 30.382863], [50.321311, 30.382696], [50.321178, 30.382467], [50.321108, 30.382359], [50.321028, 30.382238], [50.320964, 30.382147], [50.320865, 30.382012], [50.320708, 30.381811], [50.3206, 30.381687], [50.320381, 30.381451], [50.31995, 30.381026], [50.319803, 30.380874], [50.319852, 30.38071], [50.319939, 30.380427], [50.320011, 30.380237], [50.320068, 30.380122], [50.320154, 30.379984], [50.320249, 30.379861], [50.320333, 30.379783], [50.321061, 30.379158], [50.321134, 30.379107], [50.321193, 30.379071], [50.321265, 30.37904], [50.321338, 30.379011], [50.321669, 30.378862], [50.321863, 30.378774], [50.322277, 30.378532], [50.323448, 30.377797], [50.324054, 30.377417], [50.324925, 30.37687], [50.325091, 30.376773], [50.325249, 30.376681], [50.325294, 30.376655], [50.325841, 30.376335], [50.327982, 30.375111], [50.329044, 30.374496], [50.329427, 30.374261], [50.329656, 30.373994], [50.329777, 30.373853], [50.330729, 30.372304], [50.331326, 30.371343], [50.332188, 30.369968], [50.332606, 30.369364], [50.332814, 30.369058], [50.333106, 30.368644], [50.333405, 30.368251], [50.333985, 30.367557], [50.334329, 30.367085], [50.335168, 30.366002], [50.335674, 30.365234], [50.335955, 30.364671], [50.33607, 30.364456], [50.336446, 30.363636], [50.336616, 30.363212], [50.336761, 30.362812], [50.336874, 30.362478], [50.337264, 30.361113], [50.337333, 30.360845], [50.337494, 30.360383], [50.337625, 30.3601], [50.337715, 30.359957], [50.337815, 30.359832], [50.337935, 30.359691], [50.338056, 30.359599], [50.338218, 30.359523], [50.338436, 30.35947], [50.338685, 30.359431], [50.338966, 30.359386], [50.339117, 30.359328], [50.339231, 30.359274], [50.339369, 30.359196], [50.339632, 30.359023], [50.339884, 30.358826], [50.340384, 30.358409], [50.340524, 30.358193], [50.340629, 30.357928], [50.340862, 30.356859], [50.340943, 30.35645], [50.341043, 30.355792], [50.341157, 30.355132], [50.341193, 30.35497], [50.34128, 30.354718], [50.341419, 30.354388], [50.341642, 30.353991], [50.341989, 30.353196], [50.342064, 30.353025], [50.34214, 30.352827], [50.342194, 30.352636], [50.342229, 30.35239], [50.342306, 30.351079], [50.342316, 30.350961], [50.342352, 30.350539], [50.342616, 30.348765], [50.342763, 30.347677], [50.342958, 30.346313], [50.343087, 30.345436], [50.343164, 30.344878], [50.343323, 30.343745], [50.343524, 30.342171], [50.343677, 30.340947], [50.343716, 30.340479], [50.34374, 30.34005], [50.343751, 30.339372], [50.343766, 30.338407], [50.343787, 30.33779], [50.34388, 30.336021], [50.343968, 30.335215], [50.344076, 30.334317], [50.344253, 30.332972], [50.344465, 30.331491], [50.344483, 30.331307], [50.344489, 30.331051], [50.34444, 30.329948], [50.344414, 30.328912], [50.344403, 30.328614], [50.344377, 30.328319], [50.344206, 30.327049], [50.344081, 30.326117], [50.344048, 30.325816], [50.344046, 30.325777], [50.344035, 30.325552], [50.344043, 30.325315], [50.344049, 30.325251], [50.344071, 30.325019], [50.344124, 30.324636], [50.344181, 30.324364], [50.344241, 30.324104], [50.344086, 30.323514], [50.344002, 30.323273], [50.342792, 30.321296], [50.342744, 30.321217], [50.342712, 30.321165], [50.34265, 30.321081], [50.342561, 30.320996], [50.342443, 30.320925], [50.341987, 30.320749], [50.341867, 30.320713], [50.341759, 30.320692], [50.341635, 30.320686], [50.341524, 30.320703], [50.340881, 30.320794], [50.340445, 30.320836], [50.340255, 30.320838], [50.339861, 30.320812], [50.339461, 30.320754], [50.338996, 30.320656], [50.338594, 30.320532], [50.338437, 30.320481], [50.338366, 30.321338], [50.338231, 30.322809], [50.338174, 30.323151], [50.338005, 30.324012], [50.337788, 30.325411], [50.337777, 30.325474]], "routeDbId": 18, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0432\\u0443\\u043b\\u0438\\u0446\\u044f \\u0412\\u0430\\u0441\\u0438\\u043b\\u044f \\u041b\\u0438\\u043f\\u043a\\u0456\\u0432\\u0441\\u044c\\u043a\\u043e\\u0433\\u043e  37\\u0411 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 11, "eta": "09:11", "id": 187, "lat": 50.4310605, "lng": 30.4775347, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u043f\\u0440\\u043e\\u0441\\u043f. \\u041f\\u043e\\u0432\\u0456\\u0442\\u0440\\u044f\\u043d\\u0438\\u0445 \\u0441\\u0438\\u043b 52 ", "delivery_window_end": null, "delivery_window_start": null, "driveMin": 5, "eta": "09:31", "id": 29, "lat": 50.4235516, "lng": 30.4570401, "serviceMin": 15, "stopOrder": 2, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u041c\\u043e\\u043d\\u0442\\u0430\\u0436\\u043d\\u0438\\u043a\\u0456\\u0432 107 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 7, "eta": "09:53", "id": 228, "lat": 50.4127371, "lng": 30.4951845, "serviceMin": 15, "stopOrder": 3, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u041f\\u0440\\u043e\\u0441\\u043f\\u0435\\u043a\\u0442 \\u0413\\u043e\\u043b\\u043e\\u0441\\u0456\\u0457\\u0432\\u0441\\u044c\\u043a\\u0438\\u0439 68 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 6, "eta": "10:14", "id": 177, "lat": 50.3992933, "lng": 30.5109422, "serviceMin": 15, "stopOrder": 4, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0432\\u0443\\u043b\\u0438\\u0446\\u044f \\u0421\\u0442\\u0435\\u043f\\u0430\\u043d\\u0430 \\u0420\\u0443\\u0434\\u043d\\u0438\\u0446\\u044c\\u043a\\u043e\\u0433\\u043e 19/14 ", "delivery_window_end": "13:00", "delivery_window_start": "10:00", "driveMin": 6, "eta": "10:35", "id": 114, "lat": 50.3843281, "lng": 30.4559766, "serviceMin": 15, "stopOrder": 5, "waitMin": 0}, {"address": "\\u041a\\u0438\\u0457\\u0432, \\u0416\\u0443\\u043b\\u044f\\u043d\\u0441\\u044c\\u043a\\u0430 2\\u0433 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 8, "eta": "10:58", "id": 17, "lat": 50.3668574, "lng": 30.4440758, "serviceMin": 15, "stopOrder": 6, "waitMin": 0}, {"address": "\\u041a\\u0440\\u044e\\u043a\\u0456\\u0432\\u0449\\u0438\\u043d\\u0430, \\u041a\\u0438\\u0457\\u0432\\u0441\\u044c\\u043a\\u0430 \\u043e\\u0431\\u043b., \\u0412\\u0456\\u0434\\u0440\\u043e\\u0434\\u0436\\u0435\\u043d\\u043d\\u044f 316\\u0430 ", "delivery_window_end": "12:00", "delivery_window_start": "09:00", "driveMin": 22, "eta": "11:35", "id": 173, "lat": 50.3377801, "lng": 30.3254759, "serviceMin": 15, "stopOrder": 7, "waitMin": 0}], "totalDistanceKm": 39.81, "totalDriveMin": 65}]}	2026-04-25 11:16:05.237934	09:00:00
29	7	2026-04-25	completed	\N	1	5.79	10	\N	\N	\N	\N	2026-04-25 09:50:14.384587	2026-04-25 13:25:54.001287	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 10, "totalDeliveries": 29, "totalDistanceKm": 178.72, "totalDriveMin": 301}, "_selectedDate": "2026-04-25", "_fromDistribute": true, "routes": [{"courierId": "route_29", "courierName": "\\u0423\\u043a\\u043b\\u043e\\u043d", "departureAdjusted": false, "departureTime": "13:20", "geometry": [[50.473297, 30.482599], [50.473502, 30.482355], [50.47347, 30.482288], [50.473047, 30.481403], [50.473463, 30.480252], [50.473597, 30.47993], [50.473735, 30.479606], [50.473899, 30.479227], [50.473984, 30.479031], [50.474299, 30.478379], [50.474456, 30.478042], [50.474477, 30.477997], [50.474267, 30.477757], [50.473786, 30.477209], [50.473675, 30.477083], [50.473602, 30.477], [50.473547, 30.476932], [50.473399, 30.476768], [50.472755, 30.476038], [50.472703, 30.475972], [50.472265, 30.475462], [50.472156, 30.475336], [50.471636, 30.474724], [50.471449, 30.474504], [50.471231, 30.474262], [50.471075, 30.474089], [50.470961, 30.473956], [50.470842, 30.473819], [50.47039, 30.473305], [50.470222, 30.473227], [50.470093, 30.473199], [50.469861, 30.473186], [50.469668, 30.473191], [50.469144, 30.473204], [50.469041, 30.473212], [50.468772, 30.472968], [50.468747, 30.472941], [50.468139, 30.472249], [50.467839, 30.471915], [50.467808, 30.471881], [50.467663, 30.471737], [50.467537, 30.471609], [50.467495, 30.471563], [50.466914, 30.470921], [50.466793, 30.470784], [50.46648, 30.470417], [50.466448, 30.47038], [50.466139, 30.470025], [50.466057, 30.469935], [50.466016, 30.469885], [50.465955, 30.469808], [50.465806, 30.469642], [50.465571, 30.469366], [50.465367, 30.469129], [50.46524, 30.46898], [50.464903, 30.468587], [50.4646, 30.468232], [50.46448, 30.468094], [50.464104, 30.467653], [50.463892, 30.467405], [50.463247, 30.466652], [50.463109, 30.46649], [50.463032, 30.4664], [50.463003, 30.466372], [50.462961, 30.466317], [50.463013, 30.466202], [50.46313, 30.465905], [50.46316, 30.465839], [50.463128, 30.465801], [50.462857, 30.465488], [50.462746, 30.465361], [50.462708, 30.465323], [50.46269, 30.465306], [50.462634, 30.465265], [50.462609, 30.465251], [50.46254, 30.465223], [50.462596, 30.464752], [50.462631, 30.464455], [50.462815, 30.462801], [50.462891, 30.461976], [50.462903, 30.461852], [50.462957, 30.461141], [50.463015, 30.460438], [50.463042, 30.459908], [50.463049, 30.459718], [50.463067, 30.459092], [50.463072, 30.458429], [50.46306, 30.4572], [50.46303, 30.455207], [50.463026, 30.454991], [50.463025, 30.454874], [50.463012, 30.454393], [50.463, 30.453949], [50.462981, 30.453202], [50.462958, 30.452375], [50.462953, 30.452252], [50.462936, 30.451928], [50.462921, 30.451465], [50.46291, 30.451047], [50.462908, 30.450944], [50.462905, 30.450847], [50.462923, 30.450747], [50.462935, 30.45062], [50.462956, 30.450542], [50.462989, 30.450467], [50.463014, 30.450418], [50.463024, 30.450399], [50.463046, 30.45033], [50.46306, 30.450233], [50.463061, 30.450134], [50.463055, 30.44992], [50.463039, 30.449378], [50.463091, 30.44914], [50.463119, 30.449007], [50.463138, 30.448943], [50.463154, 30.448899], [50.463242, 30.448714], [50.463534, 30.448221], [50.463564, 30.448137], [50.463586, 30.448044], [50.463594, 30.447958], [50.463592, 30.447869], [50.463575, 30.447694], [50.463572, 30.447615], [50.463575, 30.447543], [50.463587, 30.447484], [50.463597, 30.447446], [50.463615, 30.447394], [50.463647, 30.447323], [50.463682, 30.447267], [50.463738, 30.447206], [50.463815, 30.447139], [50.464543, 30.447106], [50.464574, 30.447082], [50.464596, 30.447022], [50.464605, 30.446975], [50.464333, 30.446993], [50.463806, 30.447014], [50.463137, 30.447036], [50.462659, 30.447054], [50.461984, 30.44707], [50.4612, 30.447118], [50.461067, 30.447125], [50.460727, 30.447149], [50.460348, 30.447183], [50.460236, 30.447189], [50.460106, 30.447196], [50.459965, 30.447203], [50.459943, 30.447204], [50.45915, 30.447214], [50.458985, 30.447205], [50.458825, 30.447182], [50.458641, 30.447145], [50.45776, 30.446901], [50.457101, 30.446708], [50.45629, 30.446449], [50.456275, 30.446443], [50.455781, 30.446251], [50.454945, 30.445938], [50.454102, 30.445597], [50.453856, 30.445503], [50.452928, 30.445149], [50.452729, 30.445073], [50.452475, 30.444968], [50.452233, 30.444869], [50.451764, 30.444694], [50.451732, 30.444681], [50.451216, 30.444466], [50.450845, 30.444311], [50.450035, 30.443997], [50.44927, 30.443698], [50.449002, 30.443593], [50.448964, 30.443578], [50.448637, 30.443447], [50.448589, 30.443428], [50.448556, 30.443417], [50.448473, 30.443382], [50.448374, 30.443343], [50.446568, 30.44263], [50.446054, 30.442427], [50.445842, 30.442343], [50.445737, 30.442302], [50.445163, 30.442078], [50.445182, 30.441969], [50.44519, 30.441923], [50.445224, 30.44173], [50.445257, 30.441542], [50.444777, 30.441355]], "routeDbId": 29, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u0412\\u0430\\u0434\\u0438\\u043c\\u0430 \\u0413\\u0435\\u0442\\u044c\\u043c\\u0430\\u043d\\u0430 30 ", "delivery_window_end": "14:30", "delivery_window_start": "13:30", "driveMin": 10, "eta": "13:30", "id": 260, "lat": 50.4447465, "lng": 30.441548, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}], "totalDistanceKm": 5.79, "totalDriveMin": 10}]}	2026-04-25 11:16:05.252912	13:20:00
37	\N	2026-04-26	draft	\N	1	0	0	\N	\N	\N	\N	2026-04-25 13:09:30.643508	2026-04-25 17:34:05.364305	{"depot": {"lat": 50.473181, "lng": 30.4823583}, "stats": {"numCouriers": 6, "totalDeliveries": 15, "totalDistanceKm": 106.93, "totalDriveMin": 188}, "_selectedDate": "2026-04-26", "_fromDistribute": true, "routes": [{"courierId": "route_37", "departureAdjusted": false, "departureTime": "12:00", "geometry": [[50.473297, 30.482599], [50.473297, 30.482599]], "routeDbId": 37, "stops": [{"address": "\\u041a\\u0438\\u0457\\u0432, \\u041d\\u0430\\u0433\\u0456\\u0440\\u043d\\u0430 18\\\\16 ", "delivery_window_end": "13:00", "delivery_window_start": "12:00", "driveMin": 0, "eta": "12:00", "id": 62, "lat": 50.473181, "lng": 30.4823583, "serviceMin": 15, "stopOrder": 1, "waitMin": 0}], "totalDistanceKm": 0, "totalDriveMin": 0}]}	2026-04-25 17:34:05.363568	12:00:00
\.


--
-- Data for Name: florist_sale; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.florist_sale (id, florist_id, created_by, amount, bonus_percent, bonus_amount, comment, created_at) FROM stdin;
\.


--
-- Data for Name: order; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public."order" (id, client_id, recipient_name, recipient_phone, recipient_social, city, street, building_number, floor, entrance, is_pickup, size, custom_amount, time_from, time_to, comment, preferences, for_whom, created_at, delivery_method, address_comment, bouquet_type, composition_type, subscription_id, sequence_number, delivery_date, discount) FROM stdin;
1	524	Олександра	+380938182166	alexkomova	Київ	Вул. Осокорська 2а	\N	\N	\N	f	M	\N	\N	\N	\N	Весільна підписка №18\nдивитись побажання та розміри згідно табл	весільна підписка	2026-04-22 17:15:49.11156	courier	2 під’їзд, 4 поверх, 127	\N	\N	1	1	2026-05-17	\N
2	524	Олександра	+380938182166	alexkomova	Київ	Вул. Осокорська 2а	\N	\N	\N	f	M	\N	\N	\N	\N	Весільна підписка №18\nдивитись побажання та розміри згідно табл	весільна підписка	2026-04-22 17:15:49.11156	courier	2 під’їзд, 4 поверх, 127	\N	\N	1	2	2026-06-14	\N
3	524	Олександра	+380938182166	alexkomova	Київ	Вул. Осокорська 2а	\N	\N	\N	f	M	\N	\N	\N	\N	Весільна підписка №18\nдивитись побажання та розміри згідно табл	весільна підписка	2026-04-22 17:15:49.11156	courier	2 під’їзд, 4 поверх, 127	\N	\N	1	3	2026-07-12	\N
4	524	Олександра	+380938182166	alexkomova	Київ	Вул. Осокорська 2а	\N	\N	\N	f	M	\N	\N	\N	\N	Весільна підписка №18\nдивитись побажання та розміри згідно табл	весільна підписка	2026-04-22 17:15:49.11156	courier	2 під’їзд, 4 поверх, 127	\N	\N	1	4	2026-08-09	\N
5	592	Ліза	+380676125686	@Lisa_Chernikova	Київ		\N	\N	\N	f	L	\N	\N	\N	\N	@Lisa_Chernikova	хлопець дівчині	2026-04-22 17:15:50.339631	courier	\N	\N	\N	2	4	2026-05-16	\N
6	627	Михайло	+380682668787	@Mike_Kovtun	Київ	вулиця Звіринецька 9	\N	\N	\N	f	M	\N	\N	\N	\N	не класти Лілії та сильно пахнущі квіти, алергія	хлопець дівчині	2026-04-22 17:15:50.507079	courier	(приватний будинок)	\N	\N	3	3	2026-05-17	\N
7	627	Михайло	+380682668787	@Mike_Kovtun	Київ	вулиця Звіринецька 9	\N	\N	\N	f	M	\N	\N	\N	\N	не класти Лілії та сильно пахнущі квіти, алергія	хлопець дівчині	2026-04-22 17:15:50.507079	courier	(приватний будинок)	\N	\N	3	4	2026-06-14	\N
8	716	Олена	+380935641375	@eastwood_dir	Київ	Володимира Івасюка 60	\N	\N	\N	f	XL	\N	\N	\N	\N	@eastwood_dir, адреса може змінюватись	хлопець дівчині	2026-04-22 17:15:50.584885	courier	підїзд 5, кв 458	\N	\N	4	1	2026-05-21	\N
9	716	Олена	+380935641375	@eastwood_dir	Київ	Володимира Івасюка 60	\N	\N	\N	f	XL	\N	\N	\N	\N	@eastwood_dir, адреса може змінюватись	хлопець дівчині	2026-04-22 17:15:50.584885	courier	підїзд 5, кв 458	\N	\N	4	2	2026-06-18	\N
10	716	Олена	+380935641375	@eastwood_dir	Київ	Володимира Івасюка 60	\N	\N	\N	f	XL	\N	\N	\N	\N	@eastwood_dir, адреса може змінюватись	хлопець дівчині	2026-04-22 17:15:50.584885	courier	підїзд 5, кв 458	\N	\N	4	3	2026-07-16	\N
11	716	Олена	+380935641375	@eastwood_dir	Київ	Володимира Івасюка 60	\N	\N	\N	f	XL	\N	\N	\N	\N	@eastwood_dir, адреса може змінюватись	хлопець дівчині	2026-04-22 17:15:50.584885	courier	підїзд 5, кв 458	\N	\N	4	4	2026-08-13	\N
12	805	Катерина	+380509683133	kateryna_shapovalova	Київ	вул. Олеся Бердника 1-Д	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:50.797866	courier	1 підʼїзд/секція, 6 поверх, кВ.30. ЖК Нивки-парк.	\N	\N	5	3	2026-05-21	\N
13	805	Катерина	+380509683133	kateryna_shapovalova	Київ	вул. Олеся Бердника 1-Д	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:50.797866	courier	1 підʼїзд/секція, 6 поверх, кВ.30. ЖК Нивки-парк.	\N	\N	5	4	2026-06-20	\N
14	891	Альона	+380674968598	@Alona_Garaschuk	Київ	Котарбінського 17	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-22 17:15:51.025756	courier	1а доставка за адресою Воздвиженьска 41. Офіс Хавас Діджитал.\nінші - Далі доставку буде зручно отримувати на Котарбінського 17 , кв 45.	\N	\N	6	2	2026-05-17	\N
15	891	Альона	+380674968598	@Alona_Garaschuk	Київ	Котарбінського 17	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-22 17:15:51.025756	courier	1а доставка за адресою Воздвиженьска 41. Офіс Хавас Діджитал.\nінші - Далі доставку буде зручно отримувати на Котарбінського 17 , кв 45.	\N	\N	6	3	2026-05-30	\N
16	891	Альона	+380674968598	@Alona_Garaschuk	Київ	Котарбінського 17	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-22 17:15:51.025756	courier	1а доставка за адресою Воздвиженьска 41. Офіс Хавас Діджитал.\nінші - Далі доставку буде зручно отримувати на Котарбінського 17 , кв 45.	\N	\N	6	4	2026-06-06	\N
18	900	Олена	+380980492293	ferano_x	Київ	Жулянська 2г	\N	\N	\N	f	M	\N	\N	\N	\N	доставка 10-11	хлопець дівчині	2026-04-22 17:15:51.25425	courier	ЖК Євромісто, 4 підʼїзд, 5 поверх, кв. 151\nВишневе	\N	\N	7	3	2026-05-09	\N
19	900	Олена	+380980492293	ferano_x	Київ	Жулянська 2г	\N	\N	\N	f	M	\N	\N	\N	\N	доставка 10-11	хлопець дівчині	2026-04-22 17:15:51.25425	courier	ЖК Євромісто, 4 підʼїзд, 5 поверх, кв. 151\nВишневе	\N	\N	7	4	2026-05-23	\N
20	623	Маріанна	+380955031164	@mariannaalt	Київ	вул. Павлівська 17	\N	\N	\N	f	XL	\N	\N	\N	\N	погоджувати в телеграмі - @mariannaalt	дівчина собі	2026-04-22 17:15:51.283465	courier	кв. 20, 7й поверх, 1 підʼїзд	\N	\N	8	2	2026-05-03	\N
21	623	Маріанна	+380955031164	@mariannaalt	Київ	вул. Павлівська 17	\N	\N	\N	f	XL	\N	\N	\N	\N	погоджувати в телеграмі - @mariannaalt	дівчина собі	2026-04-22 17:15:51.283465	courier	кв. 20, 7й поверх, 1 підʼїзд	\N	\N	8	3	2026-05-17	\N
22	623	Маріанна	+380955031164	@mariannaalt	Київ	вул. Павлівська 17	\N	\N	\N	f	XL	\N	\N	\N	\N	погоджувати в телеграмі - @mariannaalt	дівчина собі	2026-04-22 17:15:51.283465	courier	кв. 20, 7й поверх, 1 підʼїзд	\N	\N	8	4	2026-05-31	\N
24	901	Валентин	+380639527548	valik_drozdik	Київ	Кахи Бендукідзе 2	\N	\N	\N	f	L	\N	\N	\N	\N	L - XL - L - XL	хлопець дівчині	2026-04-22 17:15:51.293205	courier	кв. 235, 7 поверх, 2 підʼїзд	\N	\N	9	4	2026-05-02	\N
25	902	Борис	+380983145264	seed!	Київ	Глибочицька 13к2	\N	\N	\N	f	M	\N	\N	\N	\N	не додавати фарбовані рослини будь які + не класти гортензіі	хлопець дівчині	2026-04-22 17:15:51.301606	courier	поверх 5, кв. 139	\N	\N	10	4	2026-04-30	\N
23	901	Валентин	+380639527548	valik_drozdik	Київ	Кахи Бендукідзе 2	\N	\N	\N	f	L	\N	\N	\N	\N	L - XL - L - XL	хлопець дівчині	2026-04-22 17:15:51.293205	courier	кв. 235, 7 поверх, 2 підʼїзд	коробка 📦	\N	9	3	2026-04-25	\N
26	903	Юлія	+380509959819	avram_chu	Київ	пр-т Науки 60а	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.309483	courier	кв. 36, 6 поверх, 1 підʼїзд	коробка 📦	\N	11	2	2026-04-26	\N
27	903	Юлія	+380509959819	avram_chu	Київ	пр-т Науки 60а	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.309483	courier	кв. 36, 6 поверх, 1 підʼїзд	\N	\N	11	3	2026-05-24	\N
28	903	Юлія	+380509959819	avram_chu	Київ	пр-т Науки 60а	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.309483	courier	кв. 36, 6 поверх, 1 підʼїзд	\N	\N	11	4	2026-06-21	\N
30	906	Ірина	+380505587408	anatolyakis	Київ	53-а Садова	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.328745	courier	буд. 14 (Йогасфера)	\N	\N	14	4	2026-04-26	\N
31	907	Лукʼян	+380669060594	lukian_halkin	Київ	Чорновола 30	\N	\N	\N	f	M	\N	\N	\N	\N	троянди не хоче отримувати.\n+ переконливо попросив НЕ привозити квіти раніше оговореного часу	хлопець дівчині	2026-04-22 17:15:51.334948	courier	кв. 113, 16 поверх, 1 підʼїзд	\N	\N	15	4	2026-05-10	\N
32	908	Марія	+380503465544	vlysenkoo	Київ	Євгена Коновальця 26А	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.34093	courier	залишать заявку на вхід в комплекс і уточнити більш точну адресу\nнабрати за 10 хвилин	\N	\N	16	3	2026-05-03	\N
33	908	Марія	+380503465544	vlysenkoo	Київ	Євгена Коновальця 26А	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.34093	courier	залишать заявку на вхід в комплекс і уточнити більш точну адресу\nнабрати за 10 хвилин	\N	\N	16	4	2026-05-17	\N
34	909	Тетяна	+380631421775	@ko7tya	Київ	50°33'24.7"N 30°29'23.3"E	\N	\N	\N	f	XL	\N	\N	\N	\N	Дуже уважно з цим клієнтом\nписати в телеграм - @ko7tya\nДоставка раз на 3 тижні\nспецифічна адреса за послианням дивитись	хлопець дівчині	2026-04-22 17:15:51.349354	courier	приватний будинок за цим посиланням\n\n50°33'24.7"N 30°29'23.3"E	\N	\N	17	3	2026-05-03	\N
35	909	Тетяна	+380631421775	@ko7tya	Київ	50°33'24.7"N 30°29'23.3"E	\N	\N	\N	f	XL	\N	\N	\N	\N	Дуже уважно з цим клієнтом\nписати в телеграм - @ko7tya\nДоставка раз на 3 тижні\nспецифічна адреса за послианням дивитись	хлопець дівчині	2026-04-22 17:15:51.349354	courier	приватний будинок за цим посиланням\n\n50°33'24.7"N 30°29'23.3"E	\N	\N	17	4	2026-05-17	\N
36	910	Дарʼя	+380673325214	yevhen17305	Київ	Коперніка 12Д	\N	\N	\N	f	M	\N	\N	\N	\N	по понеділкам на 12 доставка\nінст - yevhen17305	хлопець дівчині	2026-04-22 17:15:51.35945	courier	11 поверх, кв. 36	\N	\N	18	2	2026-04-27	\N
37	910	Дарʼя	+380673325214	yevhen17305	Київ	Коперніка 12Д	\N	\N	\N	f	M	\N	\N	\N	\N	по понеділкам на 12 доставка\nінст - yevhen17305	хлопець дівчині	2026-04-22 17:15:51.35945	courier	11 поверх, кв. 36	\N	\N	18	3	2026-05-04	\N
38	910	Дарʼя	+380673325214	yevhen17305	Київ	Коперніка 12Д	\N	\N	\N	f	M	\N	\N	\N	\N	по понеділкам на 12 доставка\nінст - yevhen17305	хлопець дівчині	2026-04-22 17:15:51.35945	courier	11 поверх, кв. 36	\N	\N	18	4	2026-05-11	\N
39	912	Анна	+380936173017	annieanniannana	Київ	Верхня 3	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.370687	courier	під'їзд 1, поверх 8, кв 91, проїжджати через вул Болбочана	\N	\N	20	2	2026-05-02	\N
40	912	Анна	+380936173017	annieanniannana	Київ	Верхня 3	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.370687	courier	під'їзд 1, поверх 8, кв 91, проїжджати через вул Болбочана	\N	\N	20	3	2026-05-16	\N
41	912	Анна	+380936173017	annieanniannana	Київ	Верхня 3	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.370687	courier	під'їзд 1, поверх 8, кв 91, проїжджати через вул Болбочана	\N	\N	20	4	2026-05-30	\N
42	913	Світлана	+380637056536	limarsvetlana	Київ	Левка Лукʼяненка 21	\N	\N	\N	f	M	\N	\N	\N	\N	доставки на 9 ранку	дівчина собі	2026-04-22 17:15:51.383535	courier	корпус 8, 14 поверх, кв. 45	\N	\N	21	4	2026-05-02	\N
43	919	Ірина	+380967475221	sergii.nesmikh	Київ	вул. Сімʼї Кульженків 31а	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.38967	courier	21 поверх, кв. 187	\N	\N	27	4	2026-05-16	\N
44	920	Тетяна	+380977634701	oleksandr.staruk	Київ	Воскресенська 18а	\N	\N	\N	f	XL	\N	\N	\N	\N	не класти троянди	хлопець дівчині	2026-04-22 17:15:51.413849	courier	кв. 120, 21 поверх, 1 секція	\N	\N	28	4	2026-05-02	\N
45	921	Ірина	+380503864196	Сергій (вотсап) 093 578 7848	Київ	вул. Юрія Кондратюка 6	\N	\N	\N	f	L	\N	\N	\N	\N	по буднях з 9 до 14\nможна більш екзотичні, і не класти тюльпани	хлопець дівчині	2026-04-22 17:15:51.419902	courier	\N	\N	\N	29	1	2026-05-01	\N
46	921	Ірина	+380503864196	Сергій (вотсап) 093 578 7848	Київ	вул. Юрія Кондратюка 6	\N	\N	\N	f	L	\N	\N	\N	\N	по буднях з 9 до 14\nможна більш екзотичні, і не класти тюльпани	хлопець дівчині	2026-04-22 17:15:51.419902	courier	\N	\N	\N	29	2	2026-05-08	\N
47	921	Ірина	+380503864196	Сергій (вотсап) 093 578 7848	Київ	вул. Юрія Кондратюка 6	\N	\N	\N	f	L	\N	\N	\N	\N	по буднях з 9 до 14\nможна більш екзотичні, і не класти тюльпани	хлопець дівчині	2026-04-22 17:15:51.419902	courier	\N	\N	\N	29	3	2026-05-15	\N
48	921	Ірина	+380503864196	Сергій (вотсап) 093 578 7848	Київ	вул. Юрія Кондратюка 6	\N	\N	\N	f	L	\N	\N	\N	\N	по буднях з 9 до 14\nможна більш екзотичні, і не класти тюльпани	хлопець дівчині	2026-04-22 17:15:51.419902	courier	\N	\N	\N	29	4	2026-05-22	\N
50	922	Олена	+380675021778	1 Сергій (вотсап) 093 578 7849	Київ	Ризька 59	\N	\N	\N	f	L	\N	\N	\N	\N	доставка с 9 до 12\nНам би хотілось меньше екзотики та більше сезонних квітів.  В яскравій кольоровій гаммі. Потрібен об'єм	хлопець дівчині	2026-04-22 17:15:51.43183	courier	(приватний будинок)	\N	\N	30	3	2026-05-02	\N
90	951	Тетяна	+380969423787	marchenkobogomaz	Київ	Донця 2а	\N	\N	\N	f	L	\N	\N	\N	\N	Доставки погоджувати з marchenkobogomaz\n6 доставок на 6 місяців	хлопець дівчині	2026-04-22 17:15:51.662144	courier	2 парадне, 9 поверх, 181 кв	\N	\N	64	4	2026-05-09	\N
51	922	Олена	+380675021778	1 Сергій (вотсап) 093 578 7849	Київ	Ризька 59	\N	\N	\N	f	L	\N	\N	\N	\N	доставка с 9 до 12\nНам би хотілось меньше екзотики та більше сезонних квітів.  В яскравій кольоровій гаммі. Потрібен об'єм	хлопець дівчині	2026-04-22 17:15:51.43183	courier	(приватний будинок)	\N	\N	30	4	2026-05-09	\N
52	923	Вадім	+380953033501	vadym.bilotskyi	Київ	Академіка Заболотного 15В	\N	\N	\N	f	L	\N	\N	\N	\N	На скільки я знаю всі квіти підходять). Мабуть бажано щось незвичне))\n\nЛистівку кожного разу «Я тебе кохаю»	хлопець дівчині	2026-04-22 17:15:51.442219	courier	\N	\N	\N	32	4	2026-05-03	\N
54	702	Наталія	+380672706655	vkostiuk	Київ	Вул. Бульварно-Кудрявська 36	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.450334	courier	1 підʼїзд, 8 поверх, кв. 34	\N	\N	35	4	2026-05-03	\N
55	925	Христина	+380507414490	alpha.centaurii	Рівне	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N	f	M	\N	\N	\N	\N	Переїхала у інше місто, чекаємо апдейт коли поновлювати доставки і куди, сама напише\nВесільна підписка #2 - дивитись побажання в табл\nбез евкаліпту\nвона сама буде писати коли ій потрібна доставка	весільна підписка	2026-04-22 17:15:51.46494	nova_poshta	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	36	1	2026-04-25	\N
56	925	Христина	+380507414490	alpha.centaurii	Рівне	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N	f	M	\N	\N	\N	\N	Переїхала у інше місто, чекаємо апдейт коли поновлювати доставки і куди, сама напише\nВесільна підписка #2 - дивитись побажання в табл\nбез евкаліпту\nвона сама буде писати коли ій потрібна доставка	весільна підписка	2026-04-22 17:15:51.46494	nova_poshta	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	36	2	2026-05-23	\N
57	925	Христина	+380507414490	alpha.centaurii	Рівне	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N	f	M	\N	\N	\N	\N	Переїхала у інше місто, чекаємо апдейт коли поновлювати доставки і куди, сама напише\nВесільна підписка #2 - дивитись побажання в табл\nбез евкаліпту\nвона сама буде писати коли ій потрібна доставка	весільна підписка	2026-04-22 17:15:51.46494	nova_poshta	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	36	3	2026-06-20	\N
58	925	Христина	+380507414490	alpha.centaurii	Рівне	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N	f	M	\N	\N	\N	\N	Переїхала у інше місто, чекаємо апдейт коли поновлювати доставки і куди, сама напише\nВесільна підписка #2 - дивитись побажання в табл\nбез евкаліпту\nвона сама буде писати коли ій потрібна доставка	весільна підписка	2026-04-22 17:15:51.46494	nova_poshta	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	36	4	2026-07-18	\N
60	927	Максим	+380959055356	телеграм - @kavinskymax	Київ	Завальна 10г	\N	\N	\N	f	M	\N	\N	\N	\N	телеграм - @kavinskymax	хлопець дівчині	2026-04-22 17:15:51.476073	courier	підїзд Г, кв 35, 5 поверх	\N	\N	38	3	2026-05-09	\N
61	927	Максим	+380959055356	телеграм - @kavinskymax	Київ	Завальна 10г	\N	\N	\N	f	M	\N	\N	\N	\N	телеграм - @kavinskymax	хлопець дівчині	2026-04-22 17:15:51.476073	courier	підїзд Г, кв 35, 5 поверх	\N	\N	38	4	2026-05-23	\N
63	930	Юлія	+380671216260	@yuligrishko	Київ	Нагірна 18\\16	\N	\N	\N	f	M	\N	\N	\N	\N	погоджувати з @yuligrishko	хлопець дівчині	2026-04-22 17:15:51.489496	courier	14 поверх, 294 квартира	\N	\N	41	3	2026-05-10	\N
64	930	Юлія	+380671216260	@yuligrishko	Київ	Нагірна 18\\16	\N	\N	\N	f	M	\N	\N	\N	\N	погоджувати з @yuligrishko	хлопець дівчині	2026-04-22 17:15:51.489496	courier	14 поверх, 294 квартира	\N	\N	41	4	2026-05-24	\N
65	931	Аня	+380631528014	anutellka	Київ	вул . Голосіївська 4	\N	\N	\N	f	M	\N	\N	\N	\N	Весільна підписка №17\nне класти гвоздики	весільна підписка	2026-04-22 17:15:51.510172	courier	кв. 122, поверх 16	\N	\N	42	1	2026-05-16	\N
66	931	Аня	+380631528014	anutellka	Київ	вул . Голосіївська 4	\N	\N	\N	f	M	\N	\N	\N	\N	Весільна підписка №17\nне класти гвоздики	весільна підписка	2026-04-22 17:15:51.510172	courier	кв. 122, поверх 16	\N	\N	42	2	2026-06-13	\N
67	931	Аня	+380631528014	anutellka	Київ	вул . Голосіївська 4	\N	\N	\N	f	M	\N	\N	\N	\N	Весільна підписка №17\nне класти гвоздики	весільна підписка	2026-04-22 17:15:51.510172	courier	кв. 122, поверх 16	\N	\N	42	3	2026-07-11	\N
68	931	Аня	+380631528014	anutellka	Київ	вул . Голосіївська 4	\N	\N	\N	f	M	\N	\N	\N	\N	Весільна підписка №17\nне класти гвоздики	весільна підписка	2026-04-22 17:15:51.510172	courier	кв. 122, поверх 16	\N	\N	42	4	2026-08-08	\N
69	932	Аніта	+380952046405	dr.an_shi	Київ		\N	\N	\N	f	XXL	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.523534	courier	\N	\N	\N	43	2	2026-04-26	\N
70	932	Аніта	+380952046405	dr.an_shi	Київ		\N	\N	\N	f	XXL	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.523534	courier	\N	\N	\N	43	3	2026-05-03	\N
71	932	Аніта	+380952046405	dr.an_shi	Київ		\N	\N	\N	f	XXL	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.523534	courier	\N	\N	\N	43	4	2026-05-10	\N
53	702	Наталія	+380672706655	vkostiuk	Київ	Вул. Бульварно-Кудрявська 36	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.450334	courier	1 підʼїзд, 8 поверх, кв. 34	коробка 📦	\N	35	3	2026-04-26	\N
62	930	Юлія	+380671216260	@yuligrishko	Київ	Нагірна 18\\16	\N	\N	\N	f	M	\N	12:00	13:00	\N	погоджувати з @yuligrishko	хлопець дівчині	2026-04-22 17:15:51.489496	courier	14 поверх, 294 квартира	коробка 📦	\N	41	2	2026-04-26	\N
74	937	Таня	+380975850765	tanya__nadtocheieva	Київ	Волоська 12/4	\N	\N	\N	f	XL	\N	\N	\N	\N	Усього 3 букети, їх не підрізати сильно, залишати більш довгими стебла. \n- 1 композиція в білих кольорах ( розмір М), не додавати панікум та еустоми, без сухлцвітів і декор додатків\n- 2 та 3 букет робити різними, без яскравих поєднаннь кольорів, максимум 2-3 кольри в одній компзиціі , або монокомпозиціі\n\nбез сухлцвітів і декор додатків, щоб не було різкого аромату так як є алергики колеги\nТакож можна використовувати якісь незвичайні екзотичні квітки нехай вона буде дорожче і навколо щось інше\nлюблять поєднання білого і зеленого\n\nДоставка у понеділок 11-13\n\nВідправляти тільки на цей номер: 0975850765-Юлія	корпоративна підписка	2026-04-22 17:15:51.541196	courier	Поділ	\N	\N	49	3	2026-04-27	\N
75	937	Таня	+380975850765	tanya__nadtocheieva	Київ	Волоська 12/4	\N	\N	\N	f	XL	\N	\N	\N	\N	Усього 3 букети, їх не підрізати сильно, залишати більш довгими стебла. \n- 1 композиція в білих кольорах ( розмір М), не додавати панікум та еустоми, без сухлцвітів і декор додатків\n- 2 та 3 букет робити різними, без яскравих поєднаннь кольорів, максимум 2-3 кольри в одній компзиціі , або монокомпозиціі\n\nбез сухлцвітів і декор додатків, щоб не було різкого аромату так як є алергики колеги\nТакож можна використовувати якісь незвичайні екзотичні квітки нехай вона буде дорожче і навколо щось інше\nлюблять поєднання білого і зеленого\n\nДоставка у понеділок 11-13\n\nВідправляти тільки на цей номер: 0975850765-Юлія	корпоративна підписка	2026-04-22 17:15:51.541196	courier	Поділ	\N	\N	49	4	2026-05-04	\N
78	943	Денис	+380678550707	07dolphin70	Київ	провулок Леопольда Ященка 17|25	\N	\N	\N	f	XL	\N	\N	\N	\N	Кидати фото квітів в дірект перед кожною відправкою\nПобажання - дуже важливо БЕЗ фіолетових та жовтих квітів. Квіти потрібно кожен раз інші, може сезонні.	хлопець дівчині	2026-04-22 17:15:51.580898	courier	63 кв	\N	\N	55	2	2026-05-10	\N
79	943	Денис	+380678550707	07dolphin70	Київ	провулок Леопольда Ященка 17|25	\N	\N	\N	f	XL	\N	\N	\N	\N	Кидати фото квітів в дірект перед кожною відправкою\nПобажання - дуже важливо БЕЗ фіолетових та жовтих квітів. Квіти потрібно кожен раз інші, може сезонні.	хлопець дівчині	2026-04-22 17:15:51.580898	courier	63 кв	\N	\N	55	3	2026-06-07	\N
80	943	Денис	+380678550707	07dolphin70	Київ	провулок Леопольда Ященка 17|25	\N	\N	\N	f	XL	\N	\N	\N	\N	Кидати фото квітів в дірект перед кожною відправкою\nПобажання - дуже важливо БЕЗ фіолетових та жовтих квітів. Квіти потрібно кожен раз інші, може сезонні.	хлопець дівчині	2026-04-22 17:15:51.580898	courier	63 кв	\N	\N	55	4	2026-07-05	\N
81	944	Євген	+380934262659	@blackjackmh	Київ	Марка Безручка 29	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.610768	courier	3 під'їзд, 1 поверх, 59 квартира. Код від дверей - 16	\N	\N	56	2	2026-05-10	\N
82	944	Євген	+380934262659	@blackjackmh	Київ	Марка Безручка 29	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.610768	courier	3 під'їзд, 1 поверх, 59 квартира. Код від дверей - 16	\N	\N	56	3	2026-06-07	\N
83	944	Євген	+380934262659	@blackjackmh	Київ	Марка Безручка 29	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.610768	courier	3 під'їзд, 1 поверх, 59 квартира. Код від дверей - 16	\N	\N	56	4	2026-07-05	\N
84	946	Катерина	+380937356031	kate.sakhno	Київ	вул Жилянська 68	\N	\N	\N	f	L	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.623937	courier	(Кадорр) - зустріти у холі	\N	\N	58	4	2026-05-02	\N
86	950	Олена	+380503875956	@sirixy	Київ	провулок Шевченка 34	\N	\N	\N	f	L	\N	\N	\N	\N	не хотіла б отримувати лілії або супер ароматні квіти	хлопець дівчині	2026-04-22 17:15:51.642008	courier	(Жуляни)	\N	\N	63	1	2026-04-27	\N
87	950	Олена	+380503875956	@sirixy	Київ	провулок Шевченка 34	\N	\N	\N	f	L	\N	\N	\N	\N	не хотіла б отримувати лілії або супер ароматні квіти	хлопець дівчині	2026-04-22 17:15:51.642008	courier	(Жуляни)	\N	\N	63	2	2026-05-11	\N
88	950	Олена	+380503875956	@sirixy	Київ	провулок Шевченка 34	\N	\N	\N	f	L	\N	\N	\N	\N	не хотіла б отримувати лілії або супер ароматні квіти	хлопець дівчині	2026-04-22 17:15:51.642008	courier	(Жуляни)	\N	\N	63	3	2026-05-25	\N
89	950	Олена	+380503875956	@sirixy	Київ	провулок Шевченка 34	\N	\N	\N	f	L	\N	\N	\N	\N	не хотіла б отримувати лілії або супер ароматні квіти	хлопець дівчині	2026-04-22 17:15:51.642008	courier	(Жуляни)	\N	\N	63	4	2026-06-08	\N
85	947	Оля	+380952769452	@Olga_vkt	Київ	Вул.Херсонська 4/2	\N	\N	\N	f	L	\N	\N	\N	\N	@Olga_vkt	дівчина іншій дівчині	2026-04-22 17:15:51.636024	courier	Вул.Херсонська 4/2\nБудинок \nhttps://maps.app.goo.gl/v2KD77zFmzv6P2297?g_st=com.google.maps.preview.copy\nСертифікат 013	коробка 📦	\N	59	4	2026-04-25	\N
76	938	Тетяна	+380958271977	s_cooper9	Київ	вул. Богдана Хмельницького 32	\N	\N	\N	f	XL	\N	\N	\N	\N	доставки зранку 11-13\r\nЩоб у букетах не було троянд (в будь якому разі не більше 2 шт.)	хлопець дівчині	2026-04-22 17:15:51.563926	courier	2 підʼїзд, кв. 39	коробка 📦	\N	50	4	2026-04-26	\N
73	556	Валерія та Іван	+380962898470	@Kuleshova_valeriia	Київ	вул. Кудрявська 24а	\N	\N	\N	f	L	\N	\N	\N	\N	Весільна підписка №8\r\n@Kuleshova_valeriia\r\nкожного разу різні розміри (див. згідно табл весільних підписок)	весільна підписка	2026-04-22 17:15:51.533259	courier	3 секція, кв. 202 (ЖК Львівська площа)	\N	\N	44	4	2026-05-09	\N
91	953	Олеся	+380501525455	adastra808	Київ	Андрія Верхогляда 2а	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.668644	courier	перший підʼїзд, 2 поверх , квартира 9	\N	\N	66	3	2026-05-02	\N
92	953	Олеся	+380501525455	adastra808	Київ	Андрія Верхогляда 2а	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.668644	courier	перший підʼїзд, 2 поверх , квартира 9	\N	\N	66	4	2026-05-20	\N
93	954	Ярослав	+380980733259	Ярослав Макійчук	Київ	Михайла Донця 2а	\N	\N	\N	f	M	\N	\N	\N	\N	погоджувати у вотсап	хлопець собі	2026-04-22 17:15:51.680064	courier	2 підʼїзд, 2 поверх, 147 кв.	\N	\N	67	3	2026-05-02	\N
94	954	Ярослав	+380980733259	Ярослав Макійчук	Київ	Михайла Донця 2а	\N	\N	\N	f	M	\N	\N	\N	\N	погоджувати у вотсап	хлопець собі	2026-04-22 17:15:51.680064	courier	2 підʼїзд, 2 поверх, 147 кв.	\N	\N	67	4	2026-05-16	\N
95	473	Аліна	+380933133314	alina_lizina (2)	Київ	Чоколівський бульвар 32	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-22 17:15:51.686978	courier	#VALUE!	\N	\N	68	3	2026-05-11	\N
96	473	Аліна	+380933133314	alina_lizina (2)	Київ	Чоколівський бульвар 32	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-22 17:15:51.686978	courier	#VALUE!	\N	\N	68	4	2026-06-08	\N
97	955	Олександра	+380678998979	@OWL_Olena	Київ	просп. Берестейський 67	\N	\N	\N	f	M	\N	\N	\N	\N	з отримувачем в вотцап	дівчина іншій дівчині	2026-04-22 17:15:51.69377	courier	ЖК Сан-Франциско, біля входу в "Галя Балувана"	\N	\N	69	4	2026-04-25	\N
98	956	Ангеліна	+380937163442	sasha_marchuk1984	Київ	вул. Юлії Здановської 71 Д	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.701325	courier	ЖК Сонячна Брама \nвул. Юлії Здановської 71 Д  1 під‘їзд кв.9	\N	\N	70	3	2026-05-07	\N
99	956	Ангеліна	+380937163442	sasha_marchuk1984	Київ	вул. Юлії Здановської 71 Д	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.701325	courier	ЖК Сонячна Брама \nвул. Юлії Здановської 71 Д  1 під‘їзд кв.9	\N	\N	70	4	2026-05-21	\N
100	957	Катерина	+380635269936	romankushmyruk	Київ	Площа Європейського союзу 80в	\N	\N	\N	f	XL	\N	\N	\N	\N	доставки по середам	хлопець дівчині	2026-04-22 17:15:51.710934	courier	кв 191, під'їзд 6, 3 поверх	\N	\N	71	4	2026-05-07	\N
102	959	Олександра	+380939600253	@alexandra_m1299	Київ	вулиця Вікентія Беретті 12	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.718133	courier	4 підʼїзд ,кв 111, 1 поверх\nКиїв, Україна 02222	\N	\N	73	4	2026-05-23	\N
103	960	Тетяна	+380969976617	097 615 1613(Вайбер)	Івано-Франківськ	Івано-Франківськ	\N	\N	\N	f	L	\N	\N	\N	\N	\N		2026-04-22 17:15:51.729551	courier	Івано-Франківськ, вул. Галицька 169	\N	\N	74	4	2026-05-07	\N
104	962	Андрій	+380997974059	Andrey P (телеграм)	Київ	вул Центральна 19	\N	\N	\N	f	XL	\N	\N	\N	\N	Надіслати фото перед відправкою\nне класти лілії та соняшник - алергія	хлопець дівчині	2026-04-22 17:15:51.737503	courier	(район Осокорки), корпус 2, кв. 39	\N	\N	76	3	2026-05-02	\N
105	962	Андрій	+380997974059	Andrey P (телеграм)	Київ	вул Центральна 19	\N	\N	\N	f	XL	\N	\N	\N	\N	Надіслати фото перед відправкою\nне класти лілії та соняшник - алергія	хлопець дівчині	2026-04-22 17:15:51.737503	courier	(район Осокорки), корпус 2, кв. 39	\N	\N	76	4	2026-05-09	\N
106	963	Яна	+380930178353	vadym_kyrylov	Київ	вулиця Половецька 12	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.751422	courier	\N	\N	\N	78	4	2026-05-16	\N
107	964	Антон	+380972138899	purple_alcoholic	Київ	вулиця Болсуновська  2	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.761201	courier	\N	\N	\N	79	4	2026-05-09	\N
108	967	Анна	+380993728446	@anna_pylypenko28	Київ	вулиця Василя Липківського 38А	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.767303	courier	підʼїзд 1.01, кв. 73	\N	\N	81	4	2026-05-09	\N
109	968	Каріна	+380734595942	karinafonariovawj	Київ	Охтирський провулок 7	\N	\N	\N	f	M	\N	\N	\N	\N	відправляти по 2 збірних букети М	дівчина собі	2026-04-22 17:15:51.786078	courier	корпус 3а	\N	\N	82	3	2026-04-27	\N
110	968	Каріна	+380734595942	karinafonariovawj	Київ	Охтирський провулок 7	\N	\N	\N	f	M	\N	\N	\N	\N	відправляти по 2 збірних букети М	дівчина собі	2026-04-22 17:15:51.786078	courier	корпус 3а	\N	\N	82	4	2026-05-04	\N
111	969	Дмитро	+380673891519	yakovlev.dmitr7	Київ	вул. Регенераторна 4	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.795654	courier	ЖК Комфорт Таунт\nкорп. 9, кв. 21 (5 поверх)	\N	\N	83	4	2026-05-16	\N
113	971	Владислав	+380956673239	yevtushenko_vladislav	Київ	б-р Миколи Міхновського 4/6	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.802227	courier	Третій під'їзд, домофон не працює. Тому набирати по приїзду	\N	\N	85	4	2026-05-02	\N
115	974	Олександр	+380667814745	0667814745(вотцап)	Київ	вулиця Степана Рудницького 19/14	\N	\N	\N	f	M	\N	\N	\N	\N	ТАК: троянди, тюльпани, іриси, нарциси. ТАК: зелений, фіолетовий в комбінації + яскраві акценти. НІ: ромашки, гербери, альстромерії. НІ: салатовий, оранжевий. Монобукети - ок. Мікс з екзотикою - супер	хлопець дівчині	2026-04-22 17:15:51.814097	courier	кв. 523	\N	\N	88	2	2026-05-09	\N
174	1012	Ганна	+380689374919	annanetrebskaia	Крюківщина, Київська обл.	Відродження 316а	\N	\N	\N	f	L	\N	\N	\N	\N	annanetrebskaia	дівчина іншій дівчині	2026-04-22 17:15:52.141899	courier	Крюківщина, Відродження 316а КМ «Беверлі Хілз»	\N	\N	133	2	2026-05-02	\N
116	974	Олександр	+380667814745	0667814745(вотцап)	Київ	вулиця Степана Рудницького 19/14	\N	\N	\N	f	M	\N	\N	\N	\N	ТАК: троянди, тюльпани, іриси, нарциси. ТАК: зелений, фіолетовий в комбінації + яскраві акценти. НІ: ромашки, гербери, альстромерії. НІ: салатовий, оранжевий. Монобукети - ок. Мікс з екзотикою - супер	хлопець дівчині	2026-04-22 17:15:51.814097	courier	кв. 523	\N	\N	88	3	2026-05-23	\N
117	974	Олександр	+380667814745	0667814745(вотцап)	Київ	вулиця Степана Рудницького 19/14	\N	\N	\N	f	M	\N	\N	\N	\N	ТАК: троянди, тюльпани, іриси, нарциси. ТАК: зелений, фіолетовий в комбінації + яскраві акценти. НІ: ромашки, гербери, альстромерії. НІ: салатовий, оранжевий. Монобукети - ок. Мікс з екзотикою - супер	хлопець дівчині	2026-04-22 17:15:51.814097	courier	кв. 523	\N	\N	88	4	2026-06-06	\N
119	737		+380633666699	@Mr_L1f3	Київ		\N	\N	\N	f	L	\N	\N	\N	\N	@Mr_L1f3	корпоративна підписка	2026-04-22 17:15:51.836093	courier	\N	\N	\N	93	4	2026-05-10	\N
120	976	Наталля	+380631715386	@Ilsap	Київ	Голосіївський проспект 118б	\N	\N	\N	f	L	\N	\N	\N	\N	Квіти для офісу	корпоративна підписка	2026-04-22 17:15:51.851828	courier	\N	\N	\N	95	3	2026-04-28	\N
121	976	Наталля	+380631715386	@Ilsap	Київ	Голосіївський проспект 118б	\N	\N	\N	f	L	\N	\N	\N	\N	Квіти для офісу	корпоративна підписка	2026-04-22 17:15:51.851828	courier	\N	\N	\N	95	4	2026-05-05	\N
122	977	Аліна	+380991110078	yura.vataschyk	Київ	Проспект Академіка Глушкова 9г	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.864624	courier	18 поверх квартира 159	\N	\N	96	3	2026-04-27	\N
123	977	Аліна	+380991110078	yura.vataschyk	Київ	Проспект Академіка Глушкова 9г	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.864624	courier	18 поверх квартира 159	\N	\N	96	4	2026-05-10	\N
124	980	Наталія	+380674630780	@nkotelianska	Київ	Оболонський проспект, 26	\N	\N	\N	f	L	\N	\N	\N	\N	@nkotelianska - Без червоних і бордових квітів, Без червоних троянд, Побажання взнала бежева мама \nВсе  ніжне біле  рожеве естетичне	дівчина іншій дівчині	2026-04-22 17:15:51.872889	courier	Це Оболонь резіденс \nСекція А, треба залишати номер авто для перепустки	\N	\N	99	1	2026-05-09	\N
125	980	Наталія	+380674630780	@nkotelianska	Київ	Оболонський проспект, 26	\N	\N	\N	f	L	\N	\N	\N	\N	@nkotelianska - Без червоних і бордових квітів, Без червоних троянд, Побажання взнала бежева мама \nВсе  ніжне біле  рожеве естетичне	дівчина іншій дівчині	2026-04-22 17:15:51.872889	courier	Це Оболонь резіденс \nСекція А, треба залишати номер авто для перепустки	\N	\N	99	2	2026-05-24	\N
126	980	Наталія	+380674630780	@nkotelianska	Київ	Оболонський проспект, 26	\N	\N	\N	f	L	\N	\N	\N	\N	@nkotelianska - Без червоних і бордових квітів, Без червоних троянд, Побажання взнала бежева мама \nВсе  ніжне біле  рожеве естетичне	дівчина іншій дівчині	2026-04-22 17:15:51.872889	courier	Це Оболонь резіденс \nСекція А, треба залишати номер авто для перепустки	\N	\N	99	3	2026-06-07	\N
127	980	Наталія	+380674630780	@nkotelianska	Київ	Оболонський проспект, 26	\N	\N	\N	f	L	\N	\N	\N	\N	@nkotelianska - Без червоних і бордових квітів, Без червоних троянд, Побажання взнала бежева мама \nВсе  ніжне біле  рожеве естетичне	дівчина іншій дівчині	2026-04-22 17:15:51.872889	courier	Це Оболонь резіденс \nСекція А, треба залишати номер авто для перепустки	\N	\N	99	4	2026-06-21	\N
129	982	Konstantin	+380689170743	@Konstantin_Popovchenko	Київ	вулиця Сергія Данченка 1	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.897991	courier	5 корпус, 19 поверх, квартира 94	\N	\N	101	3	2026-05-03	\N
130	982	Konstantin	+380689170743	@Konstantin_Popovchenko	Київ	вулиця Сергія Данченка 1	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.897991	courier	5 корпус, 19 поверх, квартира 94	\N	\N	101	4	2026-05-31	\N
132	983	Тетяна	+380953656882	@latyshev_dn	Київ	вул. Митрополита Василя Липківського 15	\N	\N	\N	f	M	\N	\N	\N	\N	Квіти - білі, бежеві та інші не яскраві кольори (не червоні, не жовті, не рожеві та інше; за можливістю).\nчас з отримувачем узгоджувати\nале самовивіз саме із замовником	хлопець дівчині	2026-04-22 17:15:51.907942	courier	61 кв.	\N	\N	102	4	2026-05-24	\N
135	986	Світлана	+380633345654	0633345654(вотцап)	Київ	вулиця Авiаконструктора Iгоря Сікорського 4д	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.9295	courier	1 під'їзд, 8 поверх, кв 35	\N	\N	105	3	2026-05-02	\N
136	986	Світлана	+380633345654	0633345654(вотцап)	Київ	вулиця Авiаконструктора Iгоря Сікорського 4д	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.9295	courier	1 під'їзд, 8 поверх, кв 35	\N	\N	105	4	2026-05-09	\N
177	1013	Анна	+380732145953	@UkotugoroshkoU	Київ	Проспект Голосіївський 68	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.157815	courier	3 під’їзд, 146 квартира	коробка 📦	\N	134	2	2026-04-25	\N
134	986	Світлана	+380633345654	0633345654(вотцап)	Київ	вулиця Авiаконструктора Iгоря Сікорського 4д	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.9295	courier	1 під'їзд, 8 поверх, кв 35	коробка 📦	\N	105	2	2026-04-25	\N
118	737	М	+380633666699	@Mr_L1f3	Київ	яблунева 15/55	\N	\N	\N	f	L	\N	09:00	12:00	\N	@Mr_L1f3	корпоративна підписка	2026-04-22 17:15:51.836093	courier	кв4, Софіївська Борщагівка	коробка 📦	\N	93	3	2026-04-26	\N
128	981	Тамара	+380503706343	tamaraguseinova	Київ		\N	\N	\N	f	L	\N	\N	\N	\N	Погоджувати tamaraguseinova		2026-04-22 17:15:51.892341	courier	\N	коробка 📦	\N	100	4	2026-04-26	\N
137	987	Катерина	+380663138847	pavel_a_kukharenko	Київ	проспект Володимира Івасюка 27а	\N	\N	\N	f	M	\N	\N	\N	\N	Є дві адреси у отримувача тому краще мабуть уточняти у нього перед доставко	хлопець дівчині	2026-04-22 17:15:51.947495	courier	Під'їзд 3\nПоверх 8\nКв. 309	\N	\N	106	3	2026-05-16	\N
138	987	Катерина	+380663138847	pavel_a_kukharenko	Київ	проспект Володимира Івасюка 27а	\N	\N	\N	f	M	\N	\N	\N	\N	Є дві адреси у отримувача тому краще мабуть уточняти у нього перед доставко	хлопець дівчині	2026-04-22 17:15:51.947495	courier	Під'їзд 3\nПоверх 8\nКв. 309	\N	\N	106	4	2026-06-14	\N
140	990	Олена	+380635821444	0937678147(вотцап)	Київ	вул. де Бальзака 46а	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.974169	courier	7 поверх, 133 квартира	\N	\N	109	4	2026-05-10	\N
141	992	Юлія	+380660136118	632113420(вайбер)	с. Петропавлівська Борщагівка	Оксамитова 9а	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.982538	courier	\N	\N	\N	111	3	2026-05-02	\N
142	992	Юлія	+380660136118	632113420(вайбер)	с. Петропавлівська Борщагівка	Оксамитова 9а	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.982538	courier	\N	\N	\N	111	4	2026-05-16	\N
143	993	Ольга	+380676903863	goshamaksymiak	Київ	Василя Липківського 37в	\N	\N	\N	f	XL	\N	\N	\N	\N	Просив робити наповнення за прикладами які скидав у дірект	хлопець дівчині	2026-04-22 17:15:51.997019	courier	під'їзд 5, поверх 3, кв 404	\N	\N	112	3	2026-05-12	\N
144	993	Ольга	+380676903863	goshamaksymiak	Київ	Василя Липківського 37в	\N	\N	\N	f	XL	\N	\N	\N	\N	Просив робити наповнення за прикладами які скидав у дірект	хлопець дівчині	2026-04-22 17:15:51.997019	courier	під'їзд 5, поверх 3, кв 404	\N	\N	112	4	2026-06-09	\N
145	994	Ігор	+380674039910	@igor11112344	Київ	Регенераторна 4	\N	\N	\N	f	M	\N	\N	\N	\N	\N		2026-04-22 17:15:52.005562	courier	\N	\N	\N	113	3	2026-05-10	\N
146	994	Ігор	+380674039910	@igor11112344	Київ	Регенераторна 4	\N	\N	\N	f	M	\N	\N	\N	\N	\N		2026-04-22 17:15:52.005562	courier	\N	\N	\N	113	4	2026-06-07	\N
148	995	Олексій	+380952943461	@ShitikovOl	Київ	Зарічна 1Г	\N	\N	\N	f	XL	\N	\N	\N	\N	погоджувати доставки в телеграмі - @ShitikovOl	хлопець дівчині	2026-04-22 17:15:52.01408	courier	17 поверх, 160 квартира	\N	\N	114	3	2026-05-02	\N
149	995	Олексій	+380952943461	@ShitikovOl	Київ	Зарічна 1Г	\N	\N	\N	f	XL	\N	\N	\N	\N	погоджувати доставки в телеграмі - @ShitikovOl	хлопець дівчині	2026-04-22 17:15:52.01408	courier	17 поверх, 160 квартира	\N	\N	114	4	2026-05-09	\N
150	996	В'ячеслав	+380934729529	@Slagod	Київ	Проспект Оболонський 7-Б	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.025049	courier	кв 83, 3 підʼїзд, 3 поверх	\N	\N	115	4	2026-04-30	\N
152	997	Юлія	+380939821599	yuliia_nebesenko	Київ	Віктора Некрасова 8	\N	\N	\N	f	L	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:52.032926	courier	поверх 15, кв А122	\N	\N	116	4	2026-05-10	\N
153	998	Олександр Бородін	+380675080419	86boroda86	Рівне	поштомат номер 46346, якщо не влазить - Відділення НП номер 1 м.Дубно Рівненської обл.	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.040659	nova_poshta	поштомат номер 46346, якщо не влазить - Відділення НП номер 1 м.Дубно Рівненської обл.	\N	\N	117	4	2026-05-03	\N
155	1000	Оксана	+380507010477	Oxana Oxana	Київ	проспект Дмитра Павличка 3	\N	\N	\N	f	M	\N	\N	\N	\N	Oxana Oxana - телеграм	дівчина собі	2026-04-22 17:15:52.047921	courier	кв 158	\N	\N	119	4	2026-05-10	\N
156	1002	Тетяна	+380674489130	tanushkas2009	Київ	Проспект Володимира Івасюка 6ак2	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:52.06436	courier	22 поверх, 240 квартира	\N	\N	121	4	2026-04-25	\N
175	1012	Ганна	+380689374919	annanetrebskaia	Крюківщина, Київська обл.	Відродження 316а	\N	\N	\N	f	L	\N	\N	\N	\N	annanetrebskaia	дівчина іншій дівчині	2026-04-22 17:15:52.141899	courier	Крюківщина, Відродження 316а КМ «Беверлі Хілз»	\N	\N	133	3	2026-05-09	\N
176	1012	Ганна	+380689374919	annanetrebskaia	Крюківщина, Київська обл.	Відродження 316а	\N	\N	\N	f	L	\N	\N	\N	\N	annanetrebskaia	дівчина іншій дівчині	2026-04-22 17:15:52.141899	courier	Крюківщина, Відродження 316а КМ «Беверлі Хілз»	\N	\N	133	4	2026-05-16	\N
72	556	Валерія та Іван	+380962898470	@Kuleshova_valeriia	Київ	вул. Кудрявська 24а	\N	\N	\N	f	L	\N	\N	\N	9а, весільна - від Сергія Тумасова	Весільна підписка №8\r\n@Kuleshova_valeriia\r\nкожного разу різні розміри (див. згідно табл весільних підписок)	весільна підписка	2026-04-22 17:15:51.533259	courier	3 секція, кв. 202 (ЖК Львівська площа)	коробка 📦	\N	44	3	2026-04-25	\N
173	1012	Ганна	+380689374919	annanetrebskaia	Крюківщина, Київська обл.	Відродження 316а	\N	\N	\N	f	L	\N	\N	\N	\N	annanetrebskaia	дівчина іншій дівчині	2026-04-22 17:15:52.141899	courier	Крюківщина, Відродження 316а КМ «Беверлі Хілз»	коробка 📦	\N	133	1	2026-04-25	\N
151	997	Юлія	+380939821599	yuliia_nebesenko	Київ	Віктора Некрасова 8	\N	\N	\N	f	L	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:52.032926	courier	поверх 15, кв А122	коробка 📦	\N	116	3	2026-04-26	\N
154	1000	Оксана	+380507010477	Oxana Oxana	Київ	проспект Дмитра Павличка 3	\N	\N	\N	f	M	\N	\N	\N	\N	Oxana Oxana - телеграм	дівчина собі	2026-04-22 17:15:52.047921	courier	кв 158	коробка 📦	\N	119	3	2026-04-26	\N
139	989	Максим	+380668217997	0956810351(вотцап)	Київ	провулок Лобачевського  7	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.956147	courier	3 секція, квартира 225	коробка 📦	\N	108	4	2026-04-26	\N
238	835	Анна	+380675030997	\N	Київ	проспект Соборності 30 	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	дівчина собі	2026-04-24 12:05:11.937824	courier	\N	коробка 📦	\N	153	3	2026-05-23	\N
239	835	Анна	+380675030997	\N	Київ	проспект Соборності 30 	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	дівчина собі	2026-04-24 12:05:11.937824	courier	 Кв 161 поверх 7	\N	\N	153	4	2026-06-06	\N
237	835	Анна	+380675030997	\N	Київ	проспект Соборності 30 	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	дівчина собі	2026-04-24 12:05:11.937824	courier	Кв 161 поверх 7	\N	\N	153	2	2026-05-09	\N
158	1003	Людмила	+380672243986	@LudmilaIvanets	Київ	вул. Ярославська, 32-А	\N	\N	\N	f	L	\N	\N	\N	\N	@LudmilaIvanets, сама будет писать когда отправлять букеты, \nПрошу більше не кидати в коробку яку везуть мені конфеті \n1. Курʼєр не має дзвонити в двері. Ні в домофон, ні в двері квартири. В мене маленька дитина.\nПо квітам \nЯ люблю кольорові букети «а-ля з бабусиного саду» \nВ цілому такі як ц вас в референсі на сайті же замовлення підписки \n\n Екзотика для мене це якісь не стандартні квітки. Типу волохаті всякі \nБутони великі як фрукт \nМене вони трохи лякають 😂\nТипу такі як на фото \nІ схожі \nЯкісь типу чорні чи темні теж не подобаються \nЩе не подобаються типу сухі. Не знаю як пояснити \nЯк шишки \nЦе все не кладіть будь ласка	дівчина іншій дівчині	2026-04-22 17:15:52.072822	courier	Поділ \nу двір заходити НЕ ТРЕБА \n1 підʼїзд з вулиці \n\nОрієнтир: \nРесторан Pan Chang \nЯкщо на нього дивитись, то другі двері справа \nПід вивіскою, 32-А \n\nКод: 5 \nПоверх: 3 \nКвартира: 5	\N	\N	123	3	2026-05-02	\N
159	1003	Людмила	+380672243986	@LudmilaIvanets	Київ	вул. Ярославська, 32-А	\N	\N	\N	f	L	\N	\N	\N	\N	@LudmilaIvanets, сама будет писать когда отправлять букеты, \nПрошу більше не кидати в коробку яку везуть мені конфеті \n1. Курʼєр не має дзвонити в двері. Ні в домофон, ні в двері квартири. В мене маленька дитина.\nПо квітам \nЯ люблю кольорові букети «а-ля з бабусиного саду» \nВ цілому такі як ц вас в референсі на сайті же замовлення підписки \n\n Екзотика для мене це якісь не стандартні квітки. Типу волохаті всякі \nБутони великі як фрукт \nМене вони трохи лякають 😂\nТипу такі як на фото \nІ схожі \nЯкісь типу чорні чи темні теж не подобаються \nЩе не подобаються типу сухі. Не знаю як пояснити \nЯк шишки \nЦе все не кладіть будь ласка	дівчина іншій дівчині	2026-04-22 17:15:52.072822	courier	Поділ \nу двір заходити НЕ ТРЕБА \n1 підʼїзд з вулиці \n\nОрієнтир: \nРесторан Pan Chang \nЯкщо на нього дивитись, то другі двері справа \nПід вивіскою, 32-А \n\nКод: 5 \nПоверх: 3 \nКвартира: 5	\N	\N	123	4	2026-05-09	\N
161	1005	Катерина	+380504071653	Kate (телеграм)	Київ	вул Олега Мудрака 66	\N	\N	\N	f	L	\N	\N	\N	\N	яскраві букети, екзотика	дівчина собі	2026-04-22 17:15:52.084654	courier	кв 12	\N	\N	125	4	2026-05-09	\N
162	1006	Анастасія	+380501602583	@sergii_z	Київ	Берестейський проспект 37/2	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.096053	courier	\N	\N	\N	126	2	2026-04-25	\N
163	1006	Анастасія	+380501602583	@sergii_z	Київ	Берестейський проспект 37/2	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.096053	courier	\N	\N	\N	126	3	2026-05-09	\N
164	1006	Анастасія	+380501602583	@sergii_z	Київ	Берестейський проспект 37/2	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.096053	courier	\N	\N	\N	126	4	2026-05-23	\N
166	1008	Дмитро	+380669003305	@Bronsboro	Київ	Фортечний Тупик 6/8	\N	\N	\N	f	XL	\N	\N	\N	\N	Якщо доставка до 14 години\nто отримувач я\nДмитро 0669003305\nякщо після то Катерина 0994377946\nвсі квіти підходять\nЯкщо у вас є листівки з Днем Народження, то я б хотів якісь різні в обидва букети\nце на день народження мамі та бабусі	хлопець дівчині	2026-04-22 17:15:52.112562	courier	під'їзд 6, поверх 4, кв 122	\N	\N	128	4	2026-05-05	\N
167	1009	Яніна	+380505734831	byinnastef 1	Чернівці	Чернівці	\N	\N	\N	f	M	\N	\N	\N	\N	"Весняні любі квіти\nХоч польові 🤣\nЧим простіші тим краще"\nЛистівка потрібна.\nПисати щоразу "Ти варта найкращого"	дівчина іншій дівчині	2026-04-22 17:15:52.12047	courier	м. Чернівці, Фотокакіс Яніна Костянтинівна. Поштомат 56232, відділення 17 Чернівці	\N	\N	130	2	2026-05-01	\N
168	1009	Яніна	+380505734831	byinnastef 1	Чернівці	Чернівці	\N	\N	\N	f	M	\N	\N	\N	\N	"Весняні любі квіти\nХоч польові 🤣\nЧим простіші тим краще"\nЛистівка потрібна.\nПисати щоразу "Ти варта найкращого"	дівчина іншій дівчині	2026-04-22 17:15:52.12047	courier	м. Чернівці, Фотокакіс Яніна Костянтинівна. Поштомат 56232, відділення 17 Чернівці	\N	\N	130	3	2026-05-29	\N
169	1009	Яніна	+380505734831	byinnastef 1	Чернівці	Чернівці	\N	\N	\N	f	M	\N	\N	\N	\N	"Весняні любі квіти\nХоч польові 🤣\nЧим простіші тим краще"\nЛистівка потрібна.\nПисати щоразу "Ти варта найкращого"	дівчина іншій дівчині	2026-04-22 17:15:52.12047	courier	м. Чернівці, Фотокакіс Яніна Костянтинівна. Поштомат 56232, відділення 17 Чернівці	\N	\N	130	4	2026-06-26	\N
170	1010	Дмитро	+380936546643	@dimalavrishyn	Львів	Львів	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.131584	courier	.Львів, 52 відділення\n+380936546643\nЛаврішин Дмитро	\N	\N	131	2	2026-04-29	\N
171	1010	Дмитро	+380936546643	@dimalavrishyn	Львів	Львів	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.131584	courier	.Львів, 52 відділення\n+380936546643\nЛаврішин Дмитро	\N	\N	131	3	2026-05-27	\N
172	1010	Дмитро	+380936546643	@dimalavrishyn	Львів	Львів	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.131584	courier	.Львів, 52 відділення\n+380936546643\nЛаврішин Дмитро	\N	\N	131	4	2026-06-24	\N
160	1005	Катерина	+380504071653	Kate (телеграм)	Київ	вул Олега Мудрака 66	\N	\N	\N	f	L	\N	\N	\N	\N	яскраві букети, екзотика	дівчина собі	2026-04-22 17:15:52.084654	courier	кв 12	коробка 📦	\N	125	3	2026-04-25	\N
178	1013	Анна	+380732145953	@UkotugoroshkoU	Київ	Проспект Голосіївський 68	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.157815	courier	3 під’їзд, 146 квартира	\N	\N	134	3	2026-05-02	\N
179	1013	Анна	+380732145953	@UkotugoroshkoU	Київ	Проспект Голосіївський 68	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.157815	courier	3 під’їзд, 146 квартира	\N	\N	134	4	2026-05-09	\N
180	1014	Марія	+380950951649	Марія Горобець(телеграм)	Київ	Причальна 14	\N	\N	\N	f	M	\N	\N	\N	\N	Марія Горобець(телеграм)	дівчина іншій дівчині	2026-04-22 17:15:52.170024	courier	кв 71, 6 поверх	\N	\N	135	4	2026-04-25	\N
182	1016	Качмарик Марія	+380685412887	vania_fomchuk	Запоріжжя	Місто Запоріжжя нова пошта 68	\N	\N	\N	f	XL	\N	\N	\N	\N	Попросив відправляти так: Місто Запоріжжя нова пошта 68 .\nІм'я відправника: Фомчук Іван \n0673260403\nІм'я отримувача : Качмарик Марія\n0685412887\nЗа доставку платять вони в додатку\nКвіти які не бажані до відправлення троянда\nКвіти які обожнює гортензія , півонії , ромашки ,  тюльпани ранункулюс	хлопець дівчині	2026-04-22 17:15:52.185083	nova_poshta	Місто Запоріжжя нова пошта 68	\N	\N	137	3	2026-05-06	\N
183	1016	Качмарик Марія	+380685412887	vania_fomchuk	Запоріжжя	Місто Запоріжжя нова пошта 68	\N	\N	\N	f	XL	\N	\N	\N	\N	Попросив відправляти так: Місто Запоріжжя нова пошта 68 .\nІм'я відправника: Фомчук Іван \n0673260403\nІм'я отримувача : Качмарик Марія\n0685412887\nЗа доставку платять вони в додатку\nКвіти які не бажані до відправлення троянда\nКвіти які обожнює гортензія , півонії , ромашки ,  тюльпани ранункулюс	хлопець дівчині	2026-04-22 17:15:52.185083	nova_poshta	Місто Запоріжжя нова пошта 68	\N	\N	137	4	2026-05-20	\N
184	1017	Ольга	+380972449990	@bohdan_tkachuk	Київ	вулиця Олени Теліги 7	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.192874	courier	\N	\N	\N	138	2	2026-04-25	\N
185	1017	Ольга	+380972449990	@bohdan_tkachuk	Київ	вулиця Олени Теліги 7	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.192874	courier	\N	\N	\N	138	3	2026-05-09	\N
186	1017	Ольга	+380972449990	@bohdan_tkachuk	Київ	вулиця Олени Теліги 7	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.192874	courier	\N	\N	\N	138	4	2026-05-23	\N
188	1018	Дмитро	+380932107088	@o_karbovs	Київ	вулиця Василя Липківського  37Б	\N	\N	\N	f	M	\N	\N	\N	\N	@o_karbovs	хлопець дівчині	2026-04-22 17:15:52.203207	courier	підʼїзд 4, поверх 20, кв 348\nКиїв, Україна 03035	\N	\N	139	3	2026-05-09	\N
189	1018	Дмитро	+380932107088	@o_karbovs	Київ	вулиця Василя Липківського  37Б	\N	\N	\N	f	M	\N	\N	\N	\N	@o_karbovs	хлопець дівчині	2026-04-22 17:15:52.203207	courier	підʼїзд 4, поверх 20, кв 348\nКиїв, Україна 03035	\N	\N	139	4	2026-05-23	\N
190	1019	Олександра	+380634917882	_l.e.b.e.d	Київ	вул.Аболмасова 6	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.212931	courier	Там один будинок, тобто 1 підʼїзд, 15 поверх, 82 квартира, ліфт завжди працює, Є дзвіночок до консьєржа на воротах	\N	\N	140	4	2026-04-29	\N
192	1020	Марія	+380939853394	@mrrbanana	Київ	вул. Воскресенська 2в	\N	\N	\N	f	M	\N	\N	\N	\N	@mrrbanana	хлопець дівчині	2026-04-22 17:15:52.218356	courier	1 секція, 10 поверх, 75	\N	\N	141	3	2026-05-10	\N
193	1020	Марія	+380939853394	@mrrbanana	Київ	вул. Воскресенська 2в	\N	\N	\N	f	M	\N	\N	\N	\N	@mrrbanana	хлопець дівчині	2026-04-22 17:15:52.218356	courier	1 секція, 10 поверх, 75	\N	\N	141	4	2026-05-24	\N
195	1021	Анастасія	+380952023484	@morozoovvva	Київ	Андрія Верхогляда, 19б	\N	\N	\N	f	L	\N	\N	\N	\N	час узгодити з отримувачем - @morozoovvva	хлопець дівчині	2026-04-22 17:15:52.226886	courier	поверх 10, кв 53	\N	\N	142	3	2026-05-03	\N
196	1021	Анастасія	+380952023484	@morozoovvva	Київ	Андрія Верхогляда, 19б	\N	\N	\N	f	L	\N	\N	\N	\N	час узгодити з отримувачем - @morozoovvva	хлопець дівчині	2026-04-22 17:15:52.226886	courier	поверх 10, кв 53	\N	\N	142	4	2026-05-10	\N
197	1022	Поліна	+380669973616	adaline.pelykh	Київ	Василя Липківського 33А	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-22 17:15:52.239405	courier	\N	\N	\N	143	2	2026-05-05	\N
198	1022	Поліна	+380669973616	adaline.pelykh	Київ	Василя Липківського 33А	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-22 17:15:52.239405	courier	\N	\N	\N	143	3	2026-05-19	\N
199	1022	Поліна	+380669973616	adaline.pelykh	Київ	Василя Липківського 33А	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-22 17:15:52.239405	courier	\N	\N	\N	143	4	2026-06-02	\N
200	1023	Вікторія	+380935878272	@ryasna	Київ	Набережно-Лугова 3а	\N	\N	\N	f	M	\N	\N	\N	\N	@ryasna\nПерша доставка - 19.04 \nДалі : \n03.05 \n17.05 \n07.06	дівчина іншій дівчині	2026-04-22 17:15:52.252025	courier	кв 53. Підʼїзд 3, поверх 4. Домофон 53	\N	\N	144	2	2026-05-03	\N
201	1023	Вікторія	+380935878272	@ryasna	Київ	Набережно-Лугова 3а	\N	\N	\N	f	M	\N	\N	\N	\N	@ryasna\nПерша доставка - 19.04 \nДалі : \n03.05 \n17.05 \n07.06	дівчина іншій дівчині	2026-04-22 17:15:52.252025	courier	кв 53. Підʼїзд 3, поверх 4. Домофон 53	\N	\N	144	3	2026-05-17	\N
202	1023	Вікторія	+380935878272	@ryasna	Київ	Набережно-Лугова 3а	\N	\N	\N	f	M	\N	\N	\N	\N	@ryasna\nПерша доставка - 19.04 \nДалі : \n03.05 \n17.05 \n07.06	дівчина іншій дівчині	2026-04-22 17:15:52.252025	courier	кв 53. Підʼїзд 3, поверх 4. Домофон 53	\N	\N	144	4	2026-05-31	\N
235	814	Ольга	+380676012283	\N	Київ	Анни Ахматової 18	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-24 11:36:27.452431	courier	12 поверх, 55 квартира 	\N	\N	152	4	2026-06-06	\N
191	1020	Марія	+380939853394	@mrrbanana	Київ	вул. Воскресенська 2в	\N	\N	\N	f	M	\N	\N	\N	\N	@mrrbanana	хлопець дівчині	2026-04-22 17:15:52.218356	courier	1 секція, 10 поверх, 75	коробка 📦	\N	141	2	2026-04-26	\N
181	1015	Лілія	+380955793157	0999855321(вотсап)	Київ	Соборності 17к2	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.178391	courier	зателефонувати за декілька хвилин щоб зробили заявку на пропуск	коробка 📦	\N	136	4	2026-04-26	\N
203	1024	Тетяна	+380979259809	0.antoxa.0	Софіївська Борщагівка	вул Райдужна 88	\N	\N	\N	f	L	\N	\N	\N	\N	не хотіли б жовті троянди, узгоджувати з отримувачем, краще писати, не телефонувати бо маленька дитина	хлопець дівчині	2026-04-22 17:15:52.263186	courier	кв 80, поверх 4	\N	\N	145	2	2026-05-04	\N
204	1024	Тетяна	+380979259809	0.antoxa.0	Софіївська Борщагівка	вул Райдужна 88	\N	\N	\N	f	L	\N	\N	\N	\N	не хотіли б жовті троянди, узгоджувати з отримувачем, краще писати, не телефонувати бо маленька дитина	хлопець дівчині	2026-04-22 17:15:52.263186	courier	кв 80, поверх 4	\N	\N	145	3	2026-05-18	\N
205	1024	Тетяна	+380979259809	0.antoxa.0	Софіївська Борщагівка	вул Райдужна 88	\N	\N	\N	f	L	\N	\N	\N	\N	не хотіли б жовті троянди, узгоджувати з отримувачем, краще писати, не телефонувати бо маленька дитина	хлопець дівчині	2026-04-22 17:15:52.263186	courier	кв 80, поверх 4	\N	\N	145	4	2026-06-01	\N
207	1025	Михайло	+380503116161	0503116161 (вайбер)	Петропавлівська Борщагівка	вул Паркова 22	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.27792	courier	\N	\N	\N	146	3	2026-05-03	\N
208	1025	Михайло	+380503116161	0503116161 (вайбер)	Петропавлівська Борщагівка	вул Паркова 22	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.27792	courier	\N	\N	\N	146	4	2026-05-10	\N
209	1026	Олексій	+380639537363	justblin_	Київ	Столичне шосе 103	\N	\N	\N	f	M	\N	\N	\N	\N	буде писати за декілька днів до замовлення	корпоративна підписка	2026-04-22 17:15:52.296333	courier	(Голосіївський район)	\N	\N	147	2	2026-05-03	\N
210	1026	Олексій	+380639537363	justblin_	Київ	Столичне шосе 103	\N	\N	\N	f	M	\N	\N	\N	\N	буде писати за декілька днів до замовлення	корпоративна підписка	2026-04-22 17:15:52.296333	courier	(Голосіївський район)	\N	\N	147	3	2026-05-17	\N
211	1026	Олексій	+380639537363	justblin_	Київ	Столичне шосе 103	\N	\N	\N	f	M	\N	\N	\N	\N	буде писати за декілька днів до замовлення	корпоративна підписка	2026-04-22 17:15:52.296333	courier	(Голосіївський район)	\N	\N	147	4	2026-05-31	\N
216	915	Олександра	+380996660001	max.ellisen	Київ	ул. Ентузіастов 11	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-23 15:35:04.86588	courier	3й під'їзд (навпроти трансформаторної будки), 2 поверх, кв. 67	\N	\N	149	1	2026-05-02	\N
217	915	Олександра	+380996660001	max.ellisen	Київ	ул. Ентузіастов 11	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-23 15:35:04.86588	courier	3й під'їзд (навпроти трансформаторної будки), 2 поверх, кв. 67	\N	\N	149	2	2026-05-16	\N
218	915	Олександра	+380996660001	max.ellisen	Київ	ул. Ентузіастов 11	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-23 15:35:04.86588	courier	3й під'їзд (навпроти трансформаторної будки), 2 поверх, кв. 67	\N	\N	149	3	2026-05-30	\N
213	939	Анастасія	+380973124469	@Vasily_Baranovsky	Київ	Котельникова 17	\N	\N	\N	f	L	\N	\N	\N	\N	доставки узгоджувати із замовником, писати в телеграм	хлопець дівчині	2026-04-23 11:57:11.400746	courier	12 поверх, кв. 55	\N	\N	148	2	2026-05-09	\N
214	939	Анастасія	+380973124469	@Vasily_Baranovsky	Київ	Котельникова 17	\N	\N	\N	f	L	\N	\N	\N	\N	доставки узгоджувати із замовником, писати в телеграм	хлопець дівчині	2026-04-23 11:57:11.400746	courier	12 поверх, кв. 55	\N	\N	148	3	2026-05-23	\N
215	939	Анастасія	+380973124469	@Vasily_Baranovsky	Київ	Котельникова 17	\N	\N	\N	f	L	\N	\N	\N	\N	доставки узгоджувати із замовником, писати в телеграм	хлопець дівчині	2026-04-23 11:57:11.400746	courier	12 поверх, кв. 55	\N	\N	148	4	2026-06-06	\N
17	900	Олена	+380980492293	ferano_x	Київ	Жулянська 2г	\N	\N	\N	f	M	\N	\N	\N	\N	доставка 10-11 	хлопець дівчині	2026-04-22 17:15:51.25425	courier	ЖК Євромісто, 4 підʼїзд, 5 поверх, кв. 151Вишневе	коробка 📦	\N	7	2	2026-04-25	\N
133	984	Анатолій	+380636235750	0 50 442 57 57 (телеграм Anatoliy)	Київ	вулиця Іоанна Павла II, 6/1	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.918695	courier	\N	коробка 📦	\N	103	4	2026-04-25	\N
147	995	Олексій	+380952943461	@ShitikovOl	Київ	Зарічна 1Г	\N	\N	\N	f	XL	\N	\N	\N	\N	Доставки завжди 9-12\r\nпогоджувати доставки в телеграмі - @ShitikovOl	хлопець дівчині	2026-04-22 17:15:52.01408	courier	17 поверх, 160 квартира	коробка 📦	\N	114	2	2026-04-25	\N
165	1007	Даша	+380671326366	@hellsiss	Київ	Вул. Байди-Вишневецького буд. 9	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.106264	courier	поверх 9, кв 25	коробка 📦	\N	127	4	2026-04-25	\N
212	939	Анастасія	+380973124469	@Vasily_Baranovsky	Київ	Котельникова 17	\N	\N	\N	f	L	\N	\N	\N	\N	доставки узгоджувати із замовником, писати в телеграм	хлопець дівчині	2026-04-23 11:57:11.400746	courier	12 поверх, кв. 55	коробка 📦	\N	148	1	2026-04-25	\N
77	940	Ольга	+380632018762	@daisygun	Київ	вулиця Митрополита Володимира Сабодана 21	\N	\N	\N	f	M	\N	\N	\N	\N	Доставку узгоджуємо з отримувачем - @daisygun\nподобається кущова троянда та евкаліпт	хлопець дівчині	2026-04-22 17:15:51.570358	courier	\N	коробка 📦	\N	52	4	2026-04-25	\N
219	915	Олександра	+380996660001	max.ellisen	Київ	ул. Ентузіастов 11	\N	\N	\N	f	L	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-23 15:35:04.86588	courier	3й під'їзд (навпроти трансформаторної будки), 2 поверх, кв. 67	\N	\N	149	4	2026-06-13	\N
29	905	Галина	+380964819288	cottoncoffe.kyiv	Київ	просп. Повітряних сил 52	\N	\N	\N	f	M	\N	\N	\N	\N	\N	корпоративна підписка	2026-04-22 17:15:51.318821	courier	(кавʼярня Cotton Coffee)\nвхід з вул. Сімʼї Ідзиковських (навпроти Добробуту)	коробка 📦	\N	13	4	2026-04-25	\N
59	927	Максим	+380959055356	телеграм - @kavinskymax	Київ	Завальна 10г	\N	\N	\N	f	M	\N	\N	\N	залишити у консьєржа	телеграм - @kavinskymax	хлопець дівчині	2026-04-22 17:15:51.476073	courier	підїзд Г, кв 35, 5 поверх	коробка 📦	\N	38	2	2026-04-25	\N
206	1025	Михайло	+380503116161	0503116161 (вайбер)	Петропавлівська Борщагівка	вул Паркова 22	\N	\N	\N	f	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:52.27792	courier	\N	коробка 📦	\N	146	2	2026-04-26	\N
157	1003	Людмила	+380672243986	@LudmilaIvanets	Київ	вул. Ярославська, 32-А	\N	\N	\N	f	L	\N	\N	\N	\N	@LudmilaIvanets, сама будет писать когда отправлять букеты, \nПрошу більше не кидати в коробку яку везуть мені конфеті \n1. Курʼєр не має дзвонити в двері. Ні в домофон, ні в двері квартири. В мене маленька дитина.\nПо квітам \nЯ люблю кольорові букети «а-ля з бабусиного саду» \nВ цілому такі як ц вас в референсі на сайті же замовлення підписки \n\n Екзотика для мене це якісь не стандартні квітки. Типу волохаті всякі \nБутони великі як фрукт \nМене вони трохи лякають 😂\nТипу такі як на фото \nІ схожі \nЯкісь типу чорні чи темні теж не подобаються \nЩе не подобаються типу сухі. Не знаю як пояснити \nЯк шишки \nЦе все не кладіть будь ласка	дівчина іншій дівчині	2026-04-22 17:15:52.072822	courier	Поділ \nу двір заходити НЕ ТРЕБА \n1 підʼїзд з вулиці \n\nОрієнтир: \nРесторан Pan Chang \nЯкщо на нього дивитись, то другі двері справа \nПід вивіскою, 32-А \n\nКод: 5 \nПоверх: 3 \nКвартира: 5	\N	\N	123	2	2026-04-25	\N
221	1027	Дарія	+380506819961	@mitr	Київ	Каземира Малевича 48	\N	\N	\N	f	XL	\N	\N	\N	\N	не класти троянди	хлопець дівчині	2026-04-23 19:07:40.967399	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	\N	\N	150	2	2026-05-09	\N
222	1027	Дарія	+380506819961	@mitr	Київ	Каземира Малевича 48	\N	\N	\N	f	XL	\N	\N	\N	\N	не класти троянди	хлопець дівчині	2026-04-23 19:07:40.967399	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	\N	\N	150	3	2026-05-16	\N
223	1027	Дарія	+380506819961	@mitr	Київ	Каземира Малевича 48	\N	\N	\N	f	XL	\N	\N	\N	\N	не класти троянди	хлопець дівчині	2026-04-23 19:07:40.967399	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	\N	\N	150	4	2026-05-23	\N
224	1027	Дарія	+380506819961	@mitr	Київ	Каземира Малевича 48	\N	\N	\N	f	XL	\N	\N	\N	\N	не класти троянди	хлопець дівчині	2026-04-23 19:07:40.967399	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	\N	\N	150	5	2026-05-30	\N
225	1027	Дарія	+380506819961	@mitr	Київ	Каземира Малевича 48	\N	\N	\N	f	XL	\N	\N	\N	\N	не класти троянди	хлопець дівчині	2026-04-23 19:07:40.967399	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	\N	\N	150	6	2026-06-06	\N
220	1027	Дарія	+380506819961	@mitr	Київ	Каземира Малевича 48	\N	\N	\N	f	XL	\N	\N	\N	ваза+ножиці\r\nЛистівка: "Кохаю тебе"	не класти троянди	хлопець дівчині	2026-04-23 19:07:40.967399	courier	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	коробка 📦 + пакет 🌸	\N	150	1	2026-05-01	\N
226	914	Юля	+380631547637	\N	Київ	Юрія Шумського 5	\N	\N	\N	f	M	\N	\N	\N	\N	не класти гвоздіку,  не класти у наступні замовлення підписки піон і бузок (повʼязано з алергією	дівчина собі	2026-04-24 08:24:43.921692	courier	2 підʼїзд, 24 поверх, 254 кв.	\N	\N	\N	\N	2026-05-02	10
112	971	Владислав	+380956673239	yevtushenko_vladislav	Київ	б-р Миколи Міхновського 4/6	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-22 17:15:51.802227	courier	Третій під'їзд, домофон не працює. Тому набирати по приїзду	коробка 📦	\N	85	3	2026-04-25	\N
49	922	Олена	+380675021778	1 Сергій (вотсап) 093 578 7849	Київ	Ризька 59	\N	\N	\N	f	L	\N	\N	\N	\N	доставка с 9 до 12\nНам би хотілось меньше екзотики та більше сезонних квітів.  В яскравій кольоровій гаммі. Потрібен об'єм	хлопець дівчині	2026-04-22 17:15:51.43183	courier	(приватний будинок)	коробка 📦	\N	30	2	2026-04-25	\N
230	973	Сергій	+380509536315	\N	Київ	Монтажників 107	\N	\N	\N	f	L	\N	\N	\N	\N	сюди дві коробки М та Л, треба щоб було різне наповнення	хлопець дівчині	2026-04-24 10:52:22.153547	courier	 (приватний будинок)	\N	\N	151	3	2026-05-09	\N
228	973	Сергій	+380509536315	\N	Київ	Монтажників 107	\N	\N	\N	f	L	\N	09:00	12:00	\N	сюди дві коробки М та Л, треба щоб було різне наповнення	хлопець дівчині	2026-04-24 10:52:22.153547	courier	 (приватний будинок)	коробка 📦	\N	151	1	2026-04-25	\N
229	973	Сергій	+380509536315	\N	Київ	Монтажників 107	\N	\N	\N	f	L	\N	\N	\N	\N	сюди дві коробки М та Л, треба щоб було різне наповнення	хлопець дівчині	2026-04-24 10:52:22.153547	courier	 (приватний будинок)	\N	\N	151	2	2026-05-02	\N
231	973	Сергій	+380509536315	\N	Київ	Монтажників 107	\N	\N	\N	f	L	\N	\N	\N	\N	сюди дві коробки М та Л, треба щоб було різне наповнення	хлопець дівчині	2026-04-24 10:52:22.153547	courier	 (приватний будинок)	\N	\N	151	4	2026-05-16	\N
233	814	Ольга	+380676012283	\N	Київ	Анни Ахматової 18	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-24 11:36:27.452431	courier	12 поверх, 55 квартира 	\N	\N	152	2	2026-05-09	\N
234	814	Ольга	+380676012283	\N	Київ	Анни Ахматової 18	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-24 11:36:27.452431	courier	12 поверх, 55 квартира 	\N	\N	152	3	2026-05-23	\N
232	814	Ольга	+380676012283	\N	Київ	Анни Ахматової 18	\N	\N	\N	f	M	\N	10:00	13:00	доставки узгоджувати з отримувачем у вотсап - залишати у консьєржа	\N	дівчина іншій дівчині	2026-04-24 11:36:27.452431	courier	12 поверх, 55 квартира 	коробка 📦	\N	152	1	2026-04-25	\N
227	729	Любов	+380633689697	\N	Київ	Самовивіз	\N	\N	\N	t	XL	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-24 08:53:53.59986	courier	 (Офіс, зателефонувати отримувачу перед шлакбаумом)	\N	\N	\N	\N	2026-04-27	10
236	835	Анна	+380675030997	\N	Київ	проспект Соборності 30 	\N	\N	\N	f	XL	\N	09:00	22:30	\N	\N	дівчина собі	2026-04-24 12:05:11.937824	courier	 Кв 161 поверх 7	\N	\N	153	1	2026-04-25	\N
101	959	Олександра	+380939600253	@alexandra_m1299	Київ	Йорданська, 26 	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина собі	2026-04-22 17:15:51.718133	courier	( метро Оболонь) 7 поверх, 702 кабінет	коробка 📦	\N	73	3	2026-04-25	\N
131	983	Тетяна	+380953656882	телеграм - Танюша Латишева	Київ	вул. Митрополита Василя Липківського 15	\N	\N	\N	f	M	\N	\N	\N	Квіти - білі, бежеві та інші не яскраві кольори (не червоні, не жовті, не рожеві та інше; за можливістю).\r\nчас з отримувачем узгоджувати\r\nале самовивіз саме із замовником	додати ножиці м'ятні, а свої хай кур'єру віддасть, завезе потім як зручно буде	хлопець дівчині	2026-04-22 17:15:51.907942	courier	61 кв.	коробка 📦	\N	102	3	2026-04-26	\N
240	1028	Поліна	+380508542523	\N	Київ	треба уточнити	\N	\N	\N	f	M	\N	\N	\N	уточнити всі деталі у отримувача, ще не оплачено	\N	дівчина іншій дівчині	2026-04-24 13:47:32.103541	courier	\N	\N	\N	154	1	2026-05-02	\N
241	1028	Поліна	+380508542523	\N	Київ	треба уточнити	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-24 13:47:32.103541	courier	\N	\N	\N	154	2	2026-05-11	\N
242	1028	Поліна	+380508542523	\N	Київ	треба уточнити	\N	\N	\N	f	M	\N	\N	\N	\N	\N	дівчина іншій дівчині	2026-04-24 13:47:32.103541	courier	\N	\N	\N	154	3	2026-05-18	\N
243	1028	Поліна	+380508542523	\N	Київ	треба уточнити	\N	\N	\N	f	M	\N	\N	\N	уточнити всі деталі у отримувача, не оплачено, перша дотсавка на 5.05	\N	дівчина іншій дівчині	2026-04-24 13:47:32.103541	courier	\N	\N	\N	154	4	2026-05-02	\N
245	1009	Інна	+380954081262	\N	Чернівці	НП, м. Чернівці, поштомат 25392, Стефанець Інна, 0954081262	\N	\N	\N	f	L	\N	\N	\N	\N	"Точно ранунклюс, півонія та еустома(знає що не відправляємо новою поштою півонії і еустоми, можливо щось подібне відправляти). Багато дивної і цікавої зелені. Можна хвою чи лопузи якісь навіть.\r\n\r\nНепотрібні гербери, троянди, лілії та решта із солодким стійким ароматом. \r\n"	дівчина іншій дівчині	2026-04-24 14:17:17.694916	nova_poshta	\N	\N	\N	155	1	2026-05-02	\N
187	1018	Дмитро	+380932107088	@o_karbovs	Київ	вулиця Василя Липківського  37Б	\N	\N	\N	f	M	\N	\N	\N	\N	@o_karbovs	хлопець дівчині	2026-04-22 17:15:52.203207	courier	підʼїзд 4, поверх 20, кв 348\nКиїв, Україна 03035	коробка 📦	\N	139	2	2026-04-25	\N
114	974	Олександр	+380667814745	0667814745(вотцап)	Київ	вулиця Степана Рудницького 19/14	\N	\N	\N	f	M	\N	\N	\N	залишити у консьєржа	ТАК: троянди, тюльпани, іриси, нарциси. ТАК: зелений, фіолетовий в комбінації + яскраві акценти. НІ: ромашки, гербери, альстромерії. НІ: салатовий, оранжевий. Монобукети - ок. Мікс з екзотикою - супер	хлопець дівчині	2026-04-22 17:15:51.814097	courier	кв. 523	коробка 📦	\N	88	1	2026-04-25	\N
194	1021	Анастасія	+380952023484	@morozoovvva	Київ	Андрія Верхогляда, 19б	\N	\N	\N	f	L	\N	\N	\N	\N	час узгодити з отримувачем - @morozoovvva	хлопець дівчині	2026-04-22 17:15:52.226886	courier	поверх 10, кв 53	коробка 📦	\N	142	2	2026-04-26	\N
244	1029	Валерія	+380956275582	\N	Київ	Івана Виговського 42	\N	\N	\N	f	L	\N	\N	\N	уточнити адресу, спитати коли зручно отримати, З любовʼю “Na Golovy”, приклад який робили за 2400, ваза и ножиці	\N	дівчина іншій дівчині	2026-04-24 14:03:23.199994	courier	\N	коробка 📦 + пакет 🌸	\N	\N	\N	2026-04-25	\N
248	916	Людмила	+380676301500	\N	Київ	бульвар Миколи Міхновського, 14-16	\N	\N	\N	f	L	\N	\N	\N	\N	Останній раз писала з інсти: karlustemi	дівчина собі	2026-04-24 15:17:24.331016	courier	 1 секція, забирають внизу	\N	\N	156	2	2026-05-03	\N
249	916	Людмила	+380676301500	\N	Київ	бульвар Миколи Міхновського, 14-16	\N	\N	\N	f	L	\N	\N	\N	\N	Останній раз писала з інсти: karlustemi	дівчина собі	2026-04-24 15:17:24.331016	courier	 1 секція, забирають внизу	\N	\N	156	3	2026-05-10	\N
250	916	Людмила	+380676301500	\N	Київ	бульвар Миколи Міхновського, 14-16	\N	\N	\N	f	L	\N	\N	\N	\N	Останній раз писала з інсти: karlustemi	дівчина собі	2026-04-24 15:17:24.331016	courier	 1 секція, забирають внизу	\N	\N	156	4	2026-05-17	\N
251	840	Іва	+380984922911	@Ivien_Moon	Київ	Проспект Володимира Івасюка 28	\N	\N	\N	f	M	\N	18:54	20:00	Приклад на 2000 тис\r\nДодати листівку: For someone special	\N	хлопець дівчині	2026-04-24 15:55:06.008266	courier	Під'їзд 3 Поверх 8 Кв. 102	букет 🌸	\N	\N	\N	2026-04-24	\N
255	1034	Поліна	+380992945852	\N	Київ	Богдана Хмельницького 58а	\N	\N	\N	f	XL	\N	11:00	13:00	Додати листівку: нажаль все мить як і ці чудові квіти - на щастя все мить як і наша відстань	\N	хлопець дівчині	2026-04-25 08:00:49.557408	courier	Спортивний клуб Вокршоп, залишити на рецепції 	букет 🌸	\N	\N	\N	2026-04-25	\N
256	1035	Карина	+380636994090	\N	Київ	Європейського союзу 41Г	\N	\N	\N	f	M	\N	\N	\N	Додати листівку: Привітання з днем весілля	\N	хлопець дівчині	2026-04-25 09:28:01.557836	courier	кв 110	\N	\N	157	1	2026-04-28	\N
253	1031	Ярослава	+380932957487	\N	Київ	Вул. Вітряні гори 10Г	\N	\N	\N	f	XL	\N	\N	\N	треба переробити приклад для нього, на уточнити деталі доставки окрім доставки	\N	хлопець дівчині	2026-04-24 17:58:57.308084	courier	\N	букет 🌸	\N	\N	\N	2026-04-25	\N
257	1035	Карина	+380636994090	\N	Київ	Європейського союзу 41Г	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-25 09:28:01.557836	courier	кв 110	\N	\N	157	2	2026-05-26	\N
246	1030	Уляна	+380676860822	\N	Київ	Вул.Ревуцького, 9	\N	\N	\N	f	M	\N	\N	\N	треба в суботу уточнити у отримувача коли зручно отримати, приклад який Наталя робила за 1500грн	\N	дівчина іншій дівчині	2026-04-24 15:10:17.730532	courier	Секція А, поверх 23, кв 418	коробка 📦	\N	\N	\N	2026-04-25	\N
258	1035	Карина	+380636994090	\N	Київ	Європейського союзу 41Г	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-25 09:28:01.557836	courier	кв 110	\N	\N	157	3	2026-06-23	\N
259	1035	Карина	+380636994090	\N	Київ	Європейського союзу 41Г	\N	\N	\N	f	M	\N	\N	\N	\N	\N	хлопець дівчині	2026-04-25 09:28:01.557836	courier	кв 110	\N	\N	157	4	2026-07-21	\N
260	1036	Анастасія	+380997837494	\N	Київ	Вадима Гетьмана 30	\N	\N	\N	f	L	\N	13:30	14:30	приклад на 3000 грн з піонами	\N	хлопець дівчині	2026-04-25 09:49:00.700092	courier	4-й під'їзд	букет 🌸	\N	\N	\N	2026-04-25	\N
254	1033	Ірина	+380660167066	\N	Київ	вулиця Казимира Малевича, 83	\N	\N	\N	f	L	\N	\N	\N	ще не оплатив, уточнити час доставки,  по можливості додайте будь ласка ранункулюсів	\N	хлопець дівчині	2026-04-24 18:32:18.23624	courier	\N	коробка 📦	\N	\N	\N	2026-04-25	\N
247	916	Людмила	+380676301500	\N	Київ	бульвар Миколи Міхновського, 14-16	\N	\N	\N	f	L	\N	09:00	12:00	1а, треба взяти готівку 7920 за підписку, потрібен наш кур'єр	Останній раз писала з інсти: karlustemi	дівчина собі	2026-04-24 15:17:24.331016	courier	 1 секція, забирають внизу	коробка 📦	\N	156	1	2026-04-26	\N
252	965	Інна Сірак 	+380679895636	\N	Село Іванковичі	село Іванковичі, вул Акрадівська,1  Інна Сірак  +380 (67) 989 56 36	\N	\N	\N	f	XL	\N	\N	\N	приклад того, що хоче кидала у дірект, потрібно відправити після оплати, вона відпише скоріше за все у продовж дня, якщо ні - нагадати \r\n«Дякую за найкращу дружину!»	\N	дівчина іншій дівчині	2026-04-24 17:50:51.13266	nova_poshta	\N	коробка 📦	\N	\N	\N	2026-04-25	\N
\.


--
-- Data for Name: prices; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.prices (id, subscription_type_id, size_id, price) FROM stdin;
\.


--
-- Data for Name: recipient_phone; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.recipient_phone (id, order_id, phone, "position") FROM stdin;
1	25	+380993165257	1
2	30	+380730644265	1
5	100	+380633959425	1
7	147	+380956116626	1
9	72	+380502471637	1
10	76	+380683996586	1
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.roles (id, name, description) FROM stdin;
1	admin	Administrator
2	manager	Manager
3	florist	Florist
\.


--
-- Data for Name: route_deliveries; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.route_deliveries (id, route_id, delivery_id, stop_order, distance_from_previous_km, duration_from_previous_min, planned_arrival, actual_arrival, created_at) FROM stdin;
362	30	191	1	\N	24	2026-04-26 09:15:00	\N	2026-04-25 17:34:05.359326
363	30	139	2	\N	13	2026-04-26 09:43:00	\N	2026-04-25 17:34:05.35933
364	37	62	1	\N	0	2026-04-26 12:00:00	\N	2026-04-25 17:34:05.367565
365	40	131	1	\N	10	2026-04-26 09:08:00	\N	2026-04-25 17:34:05.377477
366	40	118	2	\N	11	2026-04-26 09:34:00	\N	2026-04-25 17:34:05.377481
367	40	26	3	\N	11	2026-04-26 10:00:00	\N	2026-04-25 17:34:05.377483
368	40	247	4	\N	10	2026-04-26 10:25:00	\N	2026-04-25 17:34:05.377485
369	40	194	5	\N	6	2026-04-26 10:46:00	\N	2026-04-25 17:34:05.377487
370	38	181	1	\N	28	2026-04-26 16:00:00	\N	2026-04-25 17:34:05.387312
371	38	128	2	\N	17	2026-04-26 16:32:00	\N	2026-04-25 17:34:05.387316
372	39	53	1	\N	7	2026-04-26 12:03:00	\N	2026-04-25 17:34:05.39544
373	39	76	2	\N	3	2026-04-26 12:21:00	\N	2026-04-25 17:34:05.395445
374	39	206	3	\N	24	2026-04-26 13:00:00	\N	2026-04-25 17:34:05.395448
375	36	154	1	\N	12	2026-04-26 09:00:00	\N	2026-04-25 17:34:05.402535
130	24	86	1	\N	21	2026-04-27 15:00:00	\N	2026-04-24 18:18:44.027409
131	25	36	1	\N	5	2026-04-27 11:00:00	\N	2026-04-24 18:18:44.030612
132	25	109	2	\N	16	2026-04-27 11:31:00	\N	2026-04-24 18:18:44.030616
133	25	122	3	\N	9	2026-04-27 11:55:00	\N	2026-04-24 18:18:44.030618
376	36	151	2	\N	12	2026-04-26 09:27:00	\N	2026-04-25 17:34:05.40254
303	18	187	1	\N	11	2026-04-25 09:11:00	\N	2026-04-25 11:16:05.242293
304	18	29	2	\N	5	2026-04-25 09:31:00	\N	2026-04-25 11:16:05.2423
305	18	228	3	\N	7	2026-04-25 09:53:00	\N	2026-04-25 11:16:05.242303
306	18	177	4	\N	6	2026-04-25 10:14:00	\N	2026-04-25 11:16:05.242306
307	18	114	5	\N	6	2026-04-25 10:35:00	\N	2026-04-25 11:16:05.24231
308	18	17	6	\N	8	2026-04-25 10:58:00	\N	2026-04-25 11:16:05.242313
309	18	173	7	\N	22	2026-04-25 11:35:00	\N	2026-04-25 11:16:05.242316
310	28	254	1	\N	12	2026-04-25 16:12:00	\N	2026-04-25 11:16:05.24954
311	28	246	2	\N	21	2026-04-25 16:48:00	\N	2026-04-25 11:16:05.249544
312	29	260	1	\N	10	2026-04-25 13:30:00	\N	2026-04-25 11:16:05.254755
313	19	49	1	\N	7	2026-04-25 10:07:00	\N	2026-04-25 11:16:05.261191
314	19	134	2	\N	5	2026-04-25 10:27:00	\N	2026-04-25 11:16:05.261196
315	19	212	3	\N	9	2026-04-25 10:51:00	\N	2026-04-25 11:16:05.261198
316	26	255	1	\N	8	2026-04-25 11:00:00	\N	2026-04-25 11:16:05.267028
317	21	165	1	\N	11	2026-04-25 11:41:00	\N	2026-04-25 11:16:05.273172
318	21	77	2	\N	28	2026-04-25 12:24:00	\N	2026-04-25 11:16:05.273176
319	21	101	3	\N	14	2026-04-25 12:53:00	\N	2026-04-25 11:16:05.273177
320	21	253	4	\N	11	2026-04-25 13:19:00	\N	2026-04-25 11:16:05.273178
321	27	244	1	\N	15	2026-04-25 12:00:00	\N	2026-04-25 11:16:05.278505
322	20	160	1	\N	21	2026-04-25 16:00:00	\N	2026-04-25 11:16:05.283123
323	22	85	1	\N	9	2026-04-25 15:22:00	\N	2026-04-25 11:16:05.289352
324	12	72	1	\N	6	2026-04-25 09:06:00	\N	2026-04-25 11:16:05.295267
325	12	133	2	\N	11	2026-04-25 09:32:00	\N	2026-04-25 11:16:05.295271
326	12	112	3	\N	5	2026-04-25 09:52:00	\N	2026-04-25 11:16:05.295273
327	12	23	4	\N	4	2026-04-25 10:11:00	\N	2026-04-25 11:16:05.295274
328	12	236	5	\N	11	2026-04-25 10:37:00	\N	2026-04-25 11:16:05.295275
329	12	232	6	\N	9	2026-04-25 11:01:00	\N	2026-04-25 11:16:05.295276
330	12	59	7	\N	5	2026-04-25 11:21:00	\N	2026-04-25 11:16:05.295278
331	12	147	8	\N	4	2026-04-25 11:40:00	\N	2026-04-25 11:16:05.295279
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.settings (id, type, value, description, created_at) FROM stdin;
1	delivery_type	Test	\N	\N
2	city	Київ	\N	\N
3	city	Полтава	\N	\N
4	city	Вишгород	\N	\N
5	city	Бровари	\N	\N
6	city	Буча	\N	\N
7	delivery_type	Weekly	\N	\N
8	delivery_type	Monthly	\N	\N
9	delivery_type	Bi-weekly	\N	\N
10	delivery_type	One-Time	\N	\N
11	size	M	\N	\N
12	size	L	\N	\N
13	size	XL	\N	\N
14	size	XXL	\N	\N
15	size	Власний	\N	\N
16	for_whom	дівчина собі	\N	\N
17	for_whom	дівчина іншій дівчині	\N	\N
18	for_whom	хлопець дівчині	\N	\N
19	for_whom	хлопець собі	\N	\N
20	for_whom	корпоративна підписка	\N	\N
21	for_whom	весільна підписка	\N	\N
22	for_whom	хлопець хлопцю	\N	\N
23	marketing_source	Таргет	\N	\N
24	marketing_source	Тікток	\N	\N
25	marketing_source	Контент інстаграм	\N	\N
26	marketing_source	Розповіли друзі	\N	\N
27	marketing_source	Побачили офлайн	\N	\N
28	marketing_source	UGC/блогери	\N	\N
29	marketing_source	Гугл пошук	\N	\N
30	feature_flag	ai_agent_disabled	\N	\N
31	packaging_type	коробка 📦	\N	\N
32	packaging_type	коробка 📦 + пакет 🌸	\N	\N
33	packaging_type	букет 🌸	\N	\N
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.subscription (id, client_id, type, status, delivery_day, time_from, time_to, recipient_name, recipient_phone, recipient_social, city, street, building_number, floor, entrance, is_pickup, address_comment, delivery_method, size, custom_amount, bouquet_type, composition_type, for_whom, comment, preferences, is_wedding, is_extended, followup_status, followup_at, created_at, is_renewal_reminder, contact_date, draft_comment, draft_bank_link, draft_wedding_date, discount, delivery_count) FROM stdin;
1	524	Monthly	active	НД	\N	\N	Олександра	+380938182166	alexkomova	Київ	Вул. Осокорська 2а	\N	\N	\N	f	2 під’їзд, 4 поверх, 127	courier	M	\N	\N	\N	весільна підписка	\N	Весільна підписка №18\nдивитись побажання та розміри згідно табл	t	f	\N	\N	2026-04-22 17:15:49.11156	f	\N	\N	\N	\N	\N	4
2	592	Bi-weekly	active	СБ	\N	\N	Ліза	+380676125686	@Lisa_Chernikova	Київ		\N	\N	\N	f	\N	courier	L	\N	\N	\N	хлопець дівчині	\N	@Lisa_Chernikova	f	f	\N	\N	2026-04-22 17:15:50.339631	f	\N	\N	\N	\N	\N	4
3	627	Monthly	active	НД	\N	\N	Михайло	+380682668787	@Mike_Kovtun	Київ	вулиця Звіринецька 9	\N	\N	\N	f	(приватний будинок)	courier	M	\N	\N	\N	хлопець дівчині	\N	не класти Лілії та сильно пахнущі квіти, алергія	f	f	\N	\N	2026-04-22 17:15:50.507079	f	\N	\N	\N	\N	\N	4
4	716	Monthly	active	ЧТ	\N	\N	Олена	+380935641375	@eastwood_dir	Київ	Володимира Івасюка 60	\N	\N	\N	f	підїзд 5, кв 458	courier	XL	\N	\N	\N	хлопець дівчині	\N	@eastwood_dir, адреса може змінюватись	f	f	\N	\N	2026-04-22 17:15:50.584885	f	\N	\N	\N	\N	\N	4
5	805	Monthly	active	СБ	\N	\N	Катерина	+380509683133	kateryna_shapovalova	Київ	вул. Олеся Бердника 1-Д	\N	\N	\N	f	1 підʼїзд/секція, 6 поверх, кВ.30. ЖК Нивки-парк.	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:50.797866	f	\N	\N	\N	\N	\N	4
6	891	Weekly	active	СБ	\N	\N	Альона	+380674968598	@Alona_Garaschuk	Київ	Котарбінського 17	\N	\N	\N	f	1а доставка за адресою Воздвиженьска 41. Офіс Хавас Діджитал.\nінші - Далі доставку буде зручно отримувати на Котарбінського 17 , кв 45.	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.025756	f	\N	\N	\N	\N	\N	4
7	900	Bi-weekly	active	СБ	\N	\N	Олена	+380980492293	ferano_x	Київ	Жулянська 2г	\N	\N	\N	f	ЖК Євромісто, 4 підʼїзд, 5 поверх, кв. 151\nВишневе	courier	M	\N	\N	\N	хлопець дівчині	\N	доставка 10-11	f	f	\N	\N	2026-04-22 17:15:51.25425	f	\N	\N	\N	\N	\N	4
8	623	Bi-weekly	active	НД	\N	\N	Маріанна	+380955031164	@mariannaalt	Київ	вул. Павлівська 17	\N	\N	\N	f	кв. 20, 7й поверх, 1 підʼїзд	courier	XL	\N	\N	\N	дівчина собі	\N	погоджувати в телеграмі - @mariannaalt	f	f	\N	\N	2026-04-22 17:15:51.283465	f	\N	\N	\N	\N	\N	4
9	901	Weekly	active	СБ	\N	\N	Валентин	+380639527548	valik_drozdik	Київ	Кахи Бендукідзе 2	\N	\N	\N	f	кв. 235, 7 поверх, 2 підʼїзд	courier	L	\N	\N	\N	хлопець дівчині	\N	L - XL - L - XL	f	f	\N	\N	2026-04-22 17:15:51.293205	f	\N	\N	\N	\N	\N	4
10	902	Weekly	active	ЧТ	\N	\N	Борис	+380983145264	seed!	Київ	Глибочицька 13к2	\N	\N	\N	f	поверх 5, кв. 139	courier	M	\N	\N	\N	хлопець дівчині	\N	не додавати фарбовані рослини будь які + не класти гортензіі	f	f	\N	\N	2026-04-22 17:15:51.301606	f	\N	\N	\N	\N	\N	4
11	903	Monthly	active	НД	\N	\N	Юлія	+380509959819	avram_chu	Київ	пр-т Науки 60а	\N	\N	\N	f	кв. 36, 6 поверх, 1 підʼїзд	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.309483	f	\N	\N	\N	\N	\N	4
12	904	Monthly	active	ПН	\N	\N	Євгеній	+380937625767	e.bachinskii	Київ	вул. Донця 2a	\N	\N	\N	f	6й підʼїзд, 653 кв., 12й поверх\nтреба номери авто передавати на охорону у форматі АА0000КВ перед доставкою	courier	L	\N	\N	\N	хлопець дівчині	\N	Доставка по понеділкам\nзвичайні троянди не дуже подобаються	f	f	pending	\N	2026-04-22 17:15:51.318821	t	\N	\N	\N	\N	\N	4
13	905	Weekly	active	СБ	\N	\N	Галина	+380964819288	cottoncoffe.kyiv	Київ	просп. Повітряних сил 52	\N	\N	\N	f	(кавʼярня Cotton Coffee)\nвхід з вул. Сімʼї Ідзиковських (навпроти Добробуту)	courier	M	\N	\N	\N	корпоративна підписка	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.318821	f	\N	\N	\N	\N	\N	4
14	906	Bi-weekly	active	НД	\N	\N	Ірина	+380505587408	anatolyakis	Київ	53-а Садова	\N	\N	\N	f	буд. 14 (Йогасфера)	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.328745	f	\N	\N	\N	\N	\N	4
15	907	Monthly	active	НД	\N	\N	Лукʼян	+380669060594	lukian_halkin	Київ	Чорновола 30	\N	\N	\N	f	кв. 113, 16 поверх, 1 підʼїзд	courier	M	\N	\N	\N	хлопець дівчині	\N	троянди не хоче отримувати.\n+ переконливо попросив НЕ привозити квіти раніше оговореного часу	f	f	\N	\N	2026-04-22 17:15:51.334948	f	\N	\N	\N	\N	\N	4
16	908	Bi-weekly	active	НД	\N	\N	Марія	+380503465544	vlysenkoo	Київ	Євгена Коновальця 26А	\N	\N	\N	f	залишать заявку на вхід в комплекс і уточнити більш точну адресу\nнабрати за 10 хвилин	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.34093	f	\N	\N	\N	\N	\N	4
17	909	Bi-weekly	active	НД	\N	\N	Тетяна	+380631421775	@ko7tya	Київ	50°33'24.7"N 30°29'23.3"E	\N	\N	\N	f	приватний будинок за цим посиланням\n\n50°33'24.7"N 30°29'23.3"E	courier	XL	\N	\N	\N	хлопець дівчині	\N	Дуже уважно з цим клієнтом\nписати в телеграм - @ko7tya\nДоставка раз на 3 тижні\nспецифічна адреса за послианням дивитись	f	f	\N	\N	2026-04-22 17:15:51.349354	f	\N	\N	\N	\N	\N	4
18	910	Weekly	active	ПН	\N	\N	Дарʼя	+380673325214	yevhen17305	Київ	Коперніка 12Д	\N	\N	\N	f	11 поверх, кв. 36	courier	M	\N	\N	\N	хлопець дівчині	\N	по понеділкам на 12 доставка\nінст - yevhen17305	f	f	\N	\N	2026-04-22 17:15:51.35945	f	\N	\N	\N	\N	\N	4
20	912	Bi-weekly	active	СБ	\N	\N	Анна	+380936173017	annieanniannana	Київ	Верхня 3	\N	\N	\N	f	під'їзд 1, поверх 8, кв 91, проїжджати через вул Болбочана	courier	M	\N	\N	\N	дівчина собі	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.370687	f	\N	\N	\N	\N	\N	4
21	913	Bi-weekly	active	СБ	\N	\N	Світлана	+380637056536	limarsvetlana	Київ	Левка Лукʼяненка 21	\N	\N	\N	f	корпус 8, 14 поверх, кв. 45	courier	M	\N	\N	\N	дівчина собі	\N	доставки на 9 ранку	f	f	\N	\N	2026-04-22 17:15:51.383535	f	\N	\N	\N	\N	\N	4
22	914	Monthly	active	ЧТ	\N	\N	Юля	+380631547637	yuliya_brunette	Київ	Юрія Шумського 5	\N	\N	\N	f	2 підʼїзд, 24 поверх, 254 кв.	courier	M	\N	\N	\N	дівчина собі	\N	не класти гвоздіку,  не класти у наступні замовлення підписки піон і бузок (повʼязано з алергією	f	f	pending	\N	2026-04-22 17:15:51.38967	t	\N	\N	\N	\N	\N	4
23	915	Bi-weekly	active	СБ	\N	\N	Олександра	+380996660001	max.ellisen	Київ	ул. Ентузіастов 11	\N	\N	\N	f	3й під'їзд (навпроти трансформаторної будки), 2 поверх, кв. 67	courier	L	\N	\N	\N	хлопець дівчині	\N	доставка у проміжку 11-12	f	f	declined	2026-04-24 09:27:24.627178	2026-04-22 17:15:51.38967	t	\N	\N	\N	\N	\N	4
24	916	Weekly	active	НД	\N	\N	Людмила	+380676301500	awfultty	Київ		\N	\N	\N	f	\N	courier	M	\N	\N	\N	дівчина собі	\N	Останній раз писала з інсти: karlustemi	f	f	pending	\N	2026-04-22 17:15:51.38967	f	\N	\N	\N	\N	\N	4
25	917	Monthly	active	СБ	\N	\N	Анастасія	+380672972656	petrivskyi	Київ	проспект Європейського союзу 43а	\N	\N	\N	f	під'їзд 1, кв 83, поверх 9	courier	L	\N	\N	\N	хлопець дівчині	\N	Не любить червоні троянди	f	f	pending	\N	2026-04-22 17:15:51.38967	t	\N	\N	\N	\N	\N	4
26	918	Bi-weekly	active	ПТ	\N	\N	Уляна	+380508577799	ulianakharyna	Київ	Коновальця 44а	\N	\N	\N	f	2 секція, Квартира 345, 26 поверх (ліфт працює)	courier	XXL	\N	\N	\N	дівчина собі	\N	Не класти лілії \nбез блискіток	f	f	pending	\N	2026-04-22 17:15:51.38967	t	\N	\N	\N	\N	\N	4
27	919	Monthly	active	СБ	\N	\N	Ірина	+380967475221	sergii.nesmikh	Київ	вул. Сімʼї Кульженків 31а	\N	\N	\N	f	21 поверх, кв. 187	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.38967	f	\N	\N	\N	\N	\N	4
28	920	Bi-weekly	active	СБ	\N	\N	Тетяна	+380977634701	oleksandr.staruk	Київ	Воскресенська 18а	\N	\N	\N	f	кв. 120, 21 поверх, 1 секція	courier	XL	\N	\N	\N	хлопець дівчині	\N	не класти троянди	f	f	\N	\N	2026-04-22 17:15:51.413849	f	\N	\N	\N	\N	\N	4
29	921	Weekly	active	ПТ	\N	\N	Ірина	+380503864196	Сергій (вотсап) 093 578 7848	Київ	вул. Юрія Кондратюка 6	\N	\N	\N	f	\N	courier	L	\N	\N	\N	хлопець дівчині	\N	по буднях з 9 до 14\nможна більш екзотичні, і не класти тюльпани	t	f	\N	\N	2026-04-22 17:15:51.419902	f	\N	\N	\N	\N	\N	4
30	922	Weekly	active	СБ	\N	\N	Олена	+380675021778	1 Сергій (вотсап) 093 578 7849	Київ	Ризька 59	\N	\N	\N	f	(приватний будинок)	courier	L	\N	\N	\N	хлопець дівчині	\N	доставка с 9 до 12\nНам би хотілось меньше екзотики та більше сезонних квітів.  В яскравій кольоровій гаммі. Потрібен об'єм	f	f	\N	\N	2026-04-22 17:15:51.43183	f	\N	\N	\N	\N	\N	4
32	923	Bi-weekly	active	НД	\N	\N	Вадім	+380953033501	vadym.bilotskyi	Київ	Академіка Заболотного 15В	\N	\N	\N	f	\N	courier	L	\N	\N	\N	хлопець дівчині	\N	На скільки я знаю всі квіти підходять). Мабуть бажано щось незвичне))\n\nЛистівку кожного разу «Я тебе кохаю»	f	f	\N	\N	2026-04-22 17:15:51.442219	f	\N	\N	\N	\N	\N	4
33	924	Bi-weekly	active	НД	\N	\N	Оксана	+380504403500	Korinna_oksana	Київ	вул. Андрія Малишка 37	\N	\N	\N	f	кВ.87, 12 поверх, підʼїзд один у будинку	courier	M	\N	\N	\N	дівчина собі	\N	\N	f	f	pending	\N	2026-04-22 17:15:51.450334	t	\N	\N	\N	\N	\N	4
34	429	Monthly	active	СБ	\N	\N	Олена	+380933250661	https://www.instagram.com/yaroshlena?igsh=YTQxeWlrb2w4MWRs	Київ	пр. відрадний 18а	\N	\N	\N	f	кв 26	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	у людини алергія на мʼяту, евкаліпт, ментол\nпогоджувати доставки з отримувачем\nhttps://www.instagram.com/yaroshlena?igsh=YTQxeWlrb2w4MWRs	f	f	pending	\N	2026-04-22 17:15:51.450334	t	\N	\N	\N	\N	\N	4
35	702	Weekly	active	НД	\N	\N	Наталія	+380672706655	vkostiuk	Київ	Вул. Бульварно-Кудрявська 36	\N	\N	\N	f	1 підʼїзд, 8 поверх, кв. 34	courier	XL	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.450334	f	\N	\N	\N	\N	\N	4
36	925	Monthly	active	СБ	\N	\N	Христина	+380507414490	alpha.centaurii	Рівне	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	\N	\N	\N	f	Миргородська Христина Олегівна \n0507414390\nРівне\nНП 39	nova_poshta	M	\N	\N	\N	весільна підписка	\N	Переїхала у інше місто, чекаємо апдейт коли поновлювати доставки і куди, сама напише\nВесільна підписка #2 - дивитись побажання в табл\nбез евкаліпту\nвона сама буде писати коли ій потрібна доставка	t	f	\N	\N	2026-04-22 17:15:51.46494	f	\N	\N	\N	\N	\N	4
37	926	Bi-weekly	active	НД	\N	\N	Дарʼя	+380934000479	darya_brill	Київ	вул. Урлівська, 38	\N	\N	\N	f	5 підʼїзд, 18 поверх, 627 кв	courier	L	\N	\N	\N	хлопець дівчині	\N	погоджувати з отримувачем - darya_brill	f	f	pending	\N	2026-04-22 17:15:51.476073	t	\N	\N	\N	\N	\N	4
38	927	Bi-weekly	active	СБ	\N	\N	Максим	+380959055356	телеграм - @kavinskymax	Київ	Завальна 10г	\N	\N	\N	f	підїзд Г, кв 35, 5 поверх	courier	M	\N	\N	\N	хлопець дівчині	\N	телеграм - @kavinskymax	f	f	\N	\N	2026-04-22 17:15:51.476073	f	\N	\N	\N	\N	\N	4
39	928	Monthly	active	СБ	\N	\N	Олена	+380995085929	a.shvetsov91	Київ	вул. Ревуцького 36/2	\N	\N	\N	f	3 підʼїзд, 12 поверх, кв. 255	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	pending	\N	2026-04-22 17:15:51.489496	t	\N	\N	\N	\N	\N	4
40	929	Monthly	active	НД	\N	\N	Діана	+380977033717	diana_voronyuk	Київ	вул. Софії Русової 3а	\N	\N	\N	f	буде забирати внизу	courier	M	\N	\N	\N	дівчина собі	\N	\N	f	f	pending	\N	2026-04-22 17:15:51.489496	t	\N	\N	\N	\N	\N	4
41	930	Bi-weekly	active	НД	\N	\N	Юлія	+380671216260	@yuligrishko	Київ	Нагірна 18\\16	\N	\N	\N	f	14 поверх, 294 квартира	courier	M	\N	\N	\N	хлопець дівчині	\N	погоджувати з @yuligrishko	f	f	\N	\N	2026-04-22 17:15:51.489496	f	\N	\N	\N	\N	\N	4
42	931	Monthly	active	СБ	\N	\N	Аня	+380631528014	anutellka	Київ	вул . Голосіївська 4	\N	\N	\N	f	кв. 122, поверх 16	courier	M	\N	\N	\N	весільна підписка	\N	Весільна підписка №17\nне класти гвоздики	t	f	\N	\N	2026-04-22 17:15:51.510172	f	\N	\N	\N	\N	\N	4
43	932	Weekly	active	НД	\N	\N	Аніта	+380952046405	dr.an_shi	Київ		\N	\N	\N	f	\N	courier	XXL	\N	\N	\N	дівчина собі	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.523534	f	\N	\N	\N	\N	\N	4
44	556	Bi-weekly	active	СБ	\N	\N	Валерія та Іван	+380962898470	@Kuleshova_valeriia	Львів	вул. Кудрявська 24а	\N	\N	\N	f	3 секція, кв. 202 (ЖК Львівська площа)	courier	L	\N	\N	\N	весільна підписка	\N	Весільна підписка №8\n@Kuleshova_valeriia\nкожного разу різні розміри (див. згідно табл весільних підписок)	t	f	\N	\N	2026-04-22 17:15:51.533259	f	\N	\N	\N	\N	\N	4
45	933	Monthly	active	СБ	\N	\N	Кірін Владислав	+380981339931	vladyslavkir	Київ	бул. Лесі Українки буд. 19	\N	\N	\N	f	7 під’їзд 5 поверх, кв. 184	courier	L	\N	\N	\N	хлопець дівчині	\N	не класти кали, є коти	f	f	pending	\N	2026-04-22 17:15:51.541196	t	\N	\N	\N	\N	\N	4
46	934	Monthly	active	ПН	\N	\N	Ірина	+380660762064	mantra_soul_	Київ	вулиця Василя Доманицького, 3	\N	\N	\N	f	Школа 13\nабо Самовивіз	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	в неі 3 самовивози, 1 доставка, дати проставлю коли влад таблицю зробе	f	f	pending	\N	2026-04-22 17:15:51.541196	t	\N	\N	\N	\N	\N	4
47	935	Monthly	active	СБ	\N	\N	Роман і Марія	+380966792396	sokhatska.m	Київ	Польова 73	\N	\N	\N	f	ЖК Караваєві Дачі, кв. 270, 2 підʼїзд	courier	XXL	\N	\N	\N	весільна підписка	\N	Весільна підписка №29\nкожен раз різні розміри, дивитись в табл	t	f	pending	\N	2026-04-22 17:15:51.541196	t	\N	\N	\N	\N	\N	4
48	936	Monthly	active	НД	\N	\N	Настя	+380664428158	@Old_sema (Ігор Стародуб)	Київ	Данила Щербаківського 45	\N	\N	\N	f	кв. 67	courier	M	\N	\N	\N	хлопець дівчині	\N	запитати у Ігоря з ким погоджувтаи наступні доставки	f	f	pending	\N	2026-04-22 17:15:51.541196	t	\N	\N	\N	\N	\N	4
49	937	Weekly	active	ПН	\N	\N	Таня	+380975850765	tanya__nadtocheieva	Київ	Волоська 12/4	\N	\N	\N	f	Поділ	courier	XL	\N	\N	\N	корпоративна підписка	\N	Усього 3 букети, їх не підрізати сильно, залишати більш довгими стебла. \n- 1 композиція в білих кольорах ( розмір М), не додавати панікум та еустоми, без сухлцвітів і декор додатків\n- 2 та 3 букет робити різними, без яскравих поєднаннь кольорів, максимум 2-3 кольри в одній компзиціі , або монокомпозиціі\n\nбез сухлцвітів і декор додатків, щоб не було різкого аромату так як є алергики колеги\nТакож можна використовувати якісь незвичайні екзотичні квітки нехай вона буде дорожче і навколо щось інше\nлюблять поєднання білого і зеленого\n\nДоставка у понеділок 11-13\n\nВідправляти тільки на цей номер: 0975850765-Юлія	f	f	\N	\N	2026-04-22 17:15:51.541196	f	\N	\N	\N	\N	\N	4
50	938	Bi-weekly	active	НД	\N	\N	Тетяна	+380958271977	s_cooper9	Київ	вул. Богдана Хмельницького 32	\N	\N	\N	f	2 підʼїзд, кв. 39	courier	XL	\N	\N	\N	хлопець дівчині	\N	доставки зранку 9-10\nЩоб у букетах не було троянд (в будь якому разі не більше 2 шт.)	f	f	\N	\N	2026-04-22 17:15:51.563926	f	\N	\N	\N	\N	\N	4
51	939	Bi-weekly	active	СБ	\N	\N	Анастасія	+380973124469	@Vasily_Baranovsky (сайт)	Київ	Котельникова 17	\N	\N	\N	f	12 поверх, кв. 55	courier	L	\N	\N	\N	хлопець дівчині	\N	доставки узгоджувати із замовником, писати в телеграм	f	f	pending	\N	2026-04-22 17:15:51.570358	t	\N	\N	\N	\N	\N	4
52	940	Bi-weekly	active	СБ	\N	\N	Ольга	+380632018762	@daisygun	Київ	вулиця Митрополита Володимира Сабодана 21	\N	\N	\N	f	\N	courier	M	\N	\N	\N	хлопець дівчині	\N	Доставку узгоджуємо з отримувачем - @daisygun\nподобається кущова троянда та евкаліпт	f	f	\N	\N	2026-04-22 17:15:51.570358	f	\N	\N	\N	\N	\N	4
53	941	Bi-weekly	active	СБ	\N	\N	Ксенія	+380669029893	@Kseniia_Krasnopolska	Київ	Самовивіз	\N	\N	\N	f	\N	courier	M	\N	\N	\N		\N	Весільна підписка №38\nДивитись побажання які класти	f	f	pending	\N	2026-04-22 17:15:51.580898	t	\N	\N	\N	\N	\N	4
54	942	Bi-weekly	active	НД	\N	\N	Владислав	+380508622642	@dictumfactu	Київ	вул. Драгоманова 14-А	\N	\N	\N	f	третій підʼїзд, квартира 130 (перший поверх)	courier	M	\N	\N	\N	весільна підписка	\N	Весільна підписка №41\nДоставка по неділям до 11:00\nВнести побажання та додавати\nЗагалом у них буде 1 Л та 7 М	t	f	pending	\N	2026-04-22 17:15:51.580898	t	\N	\N	\N	\N	\N	4
55	943	Monthly	active	НД	\N	\N	Денис	+380678550707	07dolphin70	Київ	провулок Леопольда Ященка 17|25	\N	\N	\N	f	63 кв	courier	XL	\N	\N	\N	хлопець дівчині	\N	Кидати фото квітів в дірект перед кожною відправкою\nПобажання - дуже важливо БЕЗ фіолетових та жовтих квітів. Квіти потрібно кожен раз інші, може сезонні.	f	f	\N	\N	2026-04-22 17:15:51.580898	f	\N	\N	\N	\N	\N	4
56	944	Monthly	active	НД	\N	\N	Євген	+380934262659	@blackjackmh	Київ	Марка Безручка 29	\N	\N	\N	f	3 під'їзд, 1 поверх, 59 квартира. Код від дверей - 16	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.610768	f	\N	\N	\N	\N	\N	4
57	945	Weekly	active	НД	\N	\N	Христина	+380509621070	anton_shulyk	Київ	Ділова 2/1	\N	\N	\N	f	квартира 149(1й тестрис хол, залишати на охорі(якщо не буде ії дома)	courier	L	\N	\N	\N	хлопець дівчині	\N	узгоджувати з Христоною у вотцап\nХоче ""не тривіальні"" букети, щось єкзотичне, цікаве, оригільне, полюбляє якісь палички, зелень в букеті\n\nКожного разу питати у замовника який текст для листівки додати	f	f	pending	\N	2026-04-22 17:15:51.623937	t	\N	\N	\N	\N	\N	4
58	946	Bi-weekly	active	СБ	\N	\N	Катерина	+380937356031	kate.sakhno	Київ	вул Жилянська 68	\N	\N	\N	f	(Кадорр) - зустріти у холі	courier	L	\N	\N	\N	дівчина собі	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.623937	f	\N	\N	\N	\N	\N	4
59	947	Monthly	active	СБ	\N	\N	Оля	+380952769452	@Olga_vkt	Київ	Вул.Херсонська 4/2	\N	\N	\N	f	Вул.Херсонська 4/2\nБудинок \nhttps://maps.app.goo.gl/v2KD77zFmzv6P2297?g_st=com.google.maps.preview.copy\nСертифікат 013	courier	L	\N	\N	\N	дівчина іншій дівчині	\N	@Olga_vkt	f	f	\N	\N	2026-04-22 17:15:51.636024	f	\N	\N	\N	\N	\N	4
60	948	Weekly	active	СР	\N	\N	Вікторія	+380996248457	victoria_vasyliv	Київ	Євгена Коновальця 36Е	\N	\N	\N	f	Підʼїзд 6 ( вхід всередину двору)\nПоверх 5\nКвартира 288	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	victoria_vasyliv	f	f	pending	\N	2026-04-22 17:15:51.642008	t	\N	\N	\N	\N	\N	4
61	657	Monthly	active	СБ	\N	\N	Ольга	+380962639505	olyasolodovnik783	Київ	вул. Ірпінська 69Б	\N	\N	\N	f	(буде забирати внизу)	courier	XXL	\N	\N	\N	дівчина іншій дівчині	\N	не класти гвоздики, olyasolodovnik783	f	f	pending	\N	2026-04-22 17:15:51.642008	t	\N	\N	\N	\N	\N	4
62	949	Bi-weekly	active	СБ	\N	\N	Ірина	+380985074891	@Irina9Globa	Київ	вулиця Богатирська 6А	\N	\N	\N	f	1 підʼїзд, 12 поверх, квартира 123	courier	L	\N	\N	\N	дівчина іншій дівчині	\N	@Irina9Globa	f	f	pending	\N	2026-04-22 17:15:51.642008	t	\N	\N	\N	\N	\N	4
63	950	Bi-weekly	active	ПН	\N	\N	Олена	+380503875956	@sirixy	Київ	провулок Шевченка 34	\N	\N	\N	f	(Жуляни)	courier	L	\N	\N	\N	хлопець дівчині	\N	не хотіла б отримувати лілії або супер ароматні квіти	f	f	\N	\N	2026-04-22 17:15:51.642008	f	\N	\N	\N	\N	\N	4
64	951	Monthly	active	СБ	\N	\N	Тетяна	+380969423787	marchenkobogomaz	Київ	Донця 2а	\N	\N	\N	f	2 парадне, 9 поверх, 181 кв	courier	L	\N	\N	\N	хлопець дівчині	\N	Доставки погоджувати з marchenkobogomaz\n6 доставок на 6 місяців	f	f	\N	\N	2026-04-22 17:15:51.662144	f	\N	\N	\N	\N	\N	4
65	952	Monthly	active	СБ	\N	\N	Даша	+380639606938	@ddashatu	Київ	Гарматна 37А	\N	\N	\N	f	17п, кв 111кв	courier	M	\N	\N	\N	хлопець дівчині	\N	погоджувати з @ddashatu	f	f	pending	\N	2026-04-22 17:15:51.668644	t	\N	\N	\N	\N	\N	4
66	953	Bi-weekly	active	СР	\N	\N	Олеся	+380501525455	adastra808	Київ	Андрія Верхогляда 2а	\N	\N	\N	f	перший підʼїзд, 2 поверх , квартира 9	courier	M	\N	\N	\N	дівчина собі	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.668644	f	\N	\N	\N	\N	\N	4
67	954	Bi-weekly	active	СБ	\N	\N	Ярослав	+380980733259	Ярослав Макійчук	Київ	Михайла Донця 2а	\N	\N	\N	f	2 підʼїзд, 2 поверх, 147 кв.	courier	M	\N	\N	\N	хлопець собі	\N	погоджувати у вотсап	f	f	\N	\N	2026-04-22 17:15:51.680064	f	\N	\N	\N	\N	\N	4
68	473	Monthly	active	ПН	\N	\N	Аліна	+380933133314	alina_lizina (2)	Київ	Чоколівський бульвар 32	\N	\N	\N	f	#VALUE!	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.686978	f	\N	\N	\N	\N	\N	4
69	955	Monthly	active	СБ	\N	\N	Олександра	+380678998979	@OWL_Olena	Київ	просп. Берестейський 67	\N	\N	\N	f	ЖК Сан-Франциско, біля входу в "Галя Балувана"	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	з отримувачем в вотцап	f	f	\N	\N	2026-04-22 17:15:51.69377	f	\N	\N	\N	\N	\N	4
70	956	Bi-weekly	active	ЧТ	\N	\N	Ангеліна	+380937163442	sasha_marchuk1984	Київ	вул. Юлії Здановської 71 Д	\N	\N	\N	f	ЖК Сонячна Брама \nвул. Юлії Здановської 71 Д  1 під‘їзд кв.9	courier	XL	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.701325	f	\N	\N	\N	\N	\N	4
71	957	Weekly	active	СР	\N	\N	Катерина	+380635269936	romankushmyruk	Київ	Площа Європейського союзу 80в	\N	\N	\N	f	кв 191, під'їзд 6, 3 поверх	courier	XL	\N	\N	\N	хлопець дівчині	\N	доставки по середам	f	f	\N	\N	2026-04-22 17:15:51.710934	f	\N	\N	\N	\N	\N	4
72	958	Monthly	active	СБ	\N	\N	Ольга	+380935868251	userone3088	Київ	Вулиця вереснева 24а	\N	\N	\N	f	1 підʼїзд 6 поверх квартира 22	courier	M	\N	\N	\N	хлопець дівчині	\N	14 лютого і далі на 23 число кожного місяця включно з лютим	f	f	pending	\N	2026-04-22 17:15:51.718133	t	\N	\N	\N	\N	\N	4
73	959	Monthly	active	СБ	\N	\N	Олександра	+380939600253	@alexandra_m1299	Київ	вулиця Вікентія Беретті 12	\N	\N	\N	f	4 підʼїзд ,кв 111, 1 поверх\nКиїв, Україна 02222	courier	M	\N	\N	\N	дівчина собі	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.718133	f	\N	\N	\N	\N	\N	4
74	960	Monthly	active	ЧТ	\N	\N	Тетяна	+380969976617	097 615 1613(Вайбер)	Івано-Франківськ	Івано-Франківськ	\N	\N	\N	f	Івано-Франківськ, вул. Галицька 169	courier	L	\N	\N	\N		\N	\N	f	f	\N	\N	2026-04-22 17:15:51.729551	f	\N	\N	\N	\N	\N	4
75	961	Bi-weekly	active	СБ	\N	\N	Євген	+380509422484	@Tanya_Linnyk	Київ	вул. Велика Кільцева	\N	\N	\N	f	\N	courier	M	\N	\N	\N	хлопець дівчині	\N	@Tanya_Linnyk Не класти троянди	f	f	pending	\N	2026-04-22 17:15:51.737503	t	\N	\N	\N	\N	\N	4
76	962	Weekly	active	СБ	\N	\N	Андрій	+380997974059	Andrey P (телеграм)	Київ	вул Центральна 19	\N	\N	\N	f	(район Осокорки), корпус 2, кв. 39	courier	XL	\N	\N	\N	хлопець дівчині	\N	Надіслати фото перед відправкою\nне класти лілії та соняшник - алергія	f	f	\N	\N	2026-04-22 17:15:51.737503	f	\N	\N	\N	\N	\N	4
77	520	Bi-weekly	active	СБ	\N	\N	Наталія	+380677732511	nataliya.pogrebnyak	Київ	Вул. Максима Кривоноса 17	\N	\N	\N	f	10 поверх, 34 квартира.	courier	L	\N	\N	\N	хлопець дівчині	\N	Отримувач - nataliya.pogrebnyak (з нею все погоджувати)	f	f	pending	\N	2026-04-22 17:15:51.751422	t	\N	\N	\N	\N	\N	4
78	963	Monthly	active	СБ	\N	\N	Яна	+380930178353	vadym_kyrylov	Київ	вулиця Половецька 12	\N	\N	\N	f	\N	courier	XL	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.751422	f	\N	\N	\N	\N	\N	4
79	964	Monthly	active	СБ	\N	\N	Антон	+380972138899	purple_alcoholic	Київ	вулиця Болсуновська  2	\N	\N	\N	f	\N	courier	XL	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.761201	f	\N	\N	\N	\N	\N	4
80	966	Bi-weekly	active	СБ	\N	\N	Олександра	+380931857939	@Stanislav_Hus	Київ	чавдар 5	\N	\N	\N	f	50 квартира 8 поверх	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	зібрані букети\nне подобаютсья класичні троянди	f	f	pending	\N	2026-04-22 17:15:51.767303	t	\N	\N	\N	\N	\N	4
81	967	Monthly	active	СБ	\N	\N	Анна	+380993728446	@anna_pylypenko28	Київ	вулиця Василя Липківського 38А	\N	\N	\N	f	підʼїзд 1.01, кв. 73	courier	M	\N	\N	\N	дівчина собі	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.767303	f	\N	\N	\N	\N	\N	4
82	968	Weekly	active	ПН	\N	\N	Каріна	+380734595942	karinafonariovawj	Київ	Охтирський провулок 7	\N	\N	\N	f	корпус 3а	courier	M	\N	\N	\N	дівчина собі	\N	відправляти по 2 збірних букети М	f	f	\N	\N	2026-04-22 17:15:51.786078	f	\N	\N	\N	\N	\N	4
83	969	Monthly	active	СБ	\N	\N	Дмитро	+380673891519	yakovlev.dmitr7	Київ	вул. Регенераторна 4	\N	\N	\N	f	ЖК Комфорт Таунт\nкорп. 9, кв. 21 (5 поверх)	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.795654	f	\N	\N	\N	\N	\N	4
84	970	Bi-weekly	active	НД	\N	\N	Вероніка	+380971058494	@veronica_kravets	Київ	Юрія Іллєнка 83д	\N	\N	\N	f	кв 78	courier	L	\N	\N	\N	дівчина іншій дівчині	\N	погоджувати з отримувачем @veronica_kravets	f	f	pending	\N	2026-04-22 17:15:51.802227	t	\N	\N	\N	\N	\N	4
85	971	Weekly	active	СБ	\N	\N	Владислав	+380956673239	yevtushenko_vladislav	Київ	б-р Миколи Міхновського 4/6	\N	\N	\N	f	Третій під'їзд, домофон не працює. Тому набирати по приїзду	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.802227	f	\N	\N	\N	\N	\N	4
86	972	Weekly	active	ПТ	\N	\N	Максим	+380979527244	0979527245(вотцап)	Лебедівка	Максим Цимбалюк\nНова пошта 1\nЛебедівка, Україна 07360\n+380979527244	\N	\N	\N	f	Максим Цимбалюк\nНова пошта 1\nЛебедівка, Україна 07360\n+380979527244	nova_poshta	XL	\N	\N	\N		\N	Нова Пошта, треба відправляти в п'ятницю, щоб отримував у суботу	f	f	pending	\N	2026-04-22 17:15:51.814097	t	\N	\N	\N	\N	\N	4
88	974	Bi-weekly	active	СБ	\N	\N	Олександр	+380667814745	0667814745(вотцап)	Київ	вулиця Степана Рудницького 19/14	\N	\N	\N	f	кв. 523	courier	M	\N	\N	\N	хлопець дівчині	\N	ТАК: троянди, тюльпани, іриси, нарциси. ТАК: зелений, фіолетовий в комбінації + яскраві акценти. НІ: ромашки, гербери, альстромерії. НІ: салатовий, оранжевий. Монобукети - ок. Мікс з екзотикою - супер	f	f	\N	\N	2026-04-22 17:15:51.814097	f	\N	\N	\N	\N	\N	4
89	737	Bi-weekly	active	НД	\N	\N	Камилла	+380956456700	@KamillaAv	Київ	Ул.Голосеевская 13	\N	\N	\N	f	кВ.228	courier	L	\N	\N	\N	корпоративна підписка	\N	@KamillaAv	f	f	pending	\N	2026-04-22 17:15:51.836093	t	\N	\N	\N	\N	\N	4
90	737	Bi-weekly	active	СБ	\N	\N	Литвіна Осанна	+380689125749	ilona.kucherian 3	Одеса	Одеса	\N	\N	\N	f	г Одеса 22 отделение новой почты ул.Еврейская1,угол ул.Канатной., Литвіна Осанна Грантівна 0689125749	courier	L	\N	\N	\N	корпоративна підписка	\N	з отримувачем в вотцап	f	f	pending	\N	2026-04-22 17:15:51.836093	t	\N	\N	\N	\N	\N	4
91	737	Bi-weekly	active	СБ	\N	\N	Наталя	+380507152755	Natalya Rusanova	Київ	Київ	\N	\N	\N	f	397 відділення нової пошти, Русанова Наталя Олександрівна, 0507152755	courier	L	\N	\N	\N	корпоративна підписка	\N	Natalya Rusanova - телеграм	f	f	pending	\N	2026-04-22 17:15:51.836093	t	\N	\N	\N	\N	\N	4
92	737	Bi-weekly	active	НД	\N	\N	Яна	+380668785447	@Sydorenko_Y	Київ	вул. Марганецька, 89/1	\N	\N	\N	f	\N	courier	L	\N	\N	\N	корпоративна підписка	\N	@Sydorenko_Y	f	f	pending	\N	2026-04-22 17:15:51.836093	t	\N	\N	\N	\N	\N	4
93	737	Bi-weekly	active	НД	\N	\N		+380633666699	@Mr_L1f3	Київ		\N	\N	\N	f	\N	courier	L	\N	\N	\N	корпоративна підписка	\N	@Mr_L1f3	f	f	\N	\N	2026-04-22 17:15:51.836093	f	\N	\N	\N	\N	\N	4
94	975	Bi-weekly	active	СР	\N	\N	Світлана	+380967076617	@S_Snizhko	Київ	вул. Кропивницького 18	\N	\N	\N	f	\N	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	@S_Snizhko - Треба уточнити чи буде вдома, додати листівку:Люба моя сестричко, вітаю тебе з твоїм днем і бажаю, щоб після будь-яких труднощів приходило відродження. Бажаю, аби кожен день ти розквітала, як квітки після зими. Тож відкривай серце для нового, вір у себе і незабувай, що після найтемнішої ночі настає світанок.  Люблю тебе .	f	f	pending	\N	2026-04-22 17:15:51.851828	t	\N	\N	\N	\N	\N	4
95	976	Weekly	active	ВТ	\N	\N	Наталля	+380631715386	@Ilsap	Київ	Голосіївський проспект 118б	\N	\N	\N	f	\N	courier	L	\N	\N	\N	корпоративна підписка	\N	Квіти для офісу	f	f	\N	\N	2026-04-22 17:15:51.851828	f	\N	\N	\N	\N	\N	4
96	977	Weekly	active	НД	\N	\N	Аліна	+380991110078	yura.vataschyk	Київ	Проспект Академіка Глушкова 9г	\N	\N	\N	f	18 поверх квартира 159	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.864624	f	\N	\N	\N	\N	\N	4
97	978	Bi-weekly	active	СБ	\N	\N	Михайло	+380631040387	ostrov.skyy	Київ	вулиця Михайла Максимовича 28к	\N	\N	\N	f	\N	courier	M	\N	\N	\N	хлопець дівчині	\N	Жінка любить незвичні весняні квіти, а також піони	f	f	pending	\N	2026-04-22 17:15:51.872889	t	\N	\N	\N	\N	\N	4
98	979	Bi-weekly	active	НД	\N	\N	Володимир	+380957255980	@volodymyrshykun	Київ	Зарічна 3а	\N	\N	\N	f	Перший підʼїзд, 24 поверх, квартира 221	courier	XL	\N	\N	\N	хлопець дівчині	\N	\N	f	f	pending	\N	2026-04-22 17:15:51.872889	t	\N	\N	\N	\N	\N	4
99	980	Bi-weekly	active	НД	\N	\N	Наталія	+380674630780	@nkotelianska	Київ	Оболонський проспект, 26	\N	\N	\N	f	Це Оболонь резіденс \nСекція А, треба залишати номер авто для перепустки	courier	L	\N	\N	\N	дівчина іншій дівчині	\N	@nkotelianska - Без червоних і бордових квітів, Без червоних троянд, Побажання взнала бежева мама \nВсе  ніжне біле  рожеве естетичне	f	f	\N	\N	2026-04-22 17:15:51.872889	f	\N	\N	\N	\N	\N	4
100	981	Weekly	active	НД	\N	\N	Тамара	+380503706343	tamaraguseinova	Київ		\N	\N	\N	f	\N	courier	L	\N	\N	\N		\N	Погоджувати tamaraguseinova	f	f	\N	\N	2026-04-22 17:15:51.892341	f	\N	\N	\N	\N	\N	4
101	982	Monthly	active	НД	\N	\N	Konstantin	+380689170743	@Konstantin_Popovchenko	Київ	вулиця Сергія Данченка 1	\N	\N	\N	f	5 корпус, 19 поверх, квартира 94	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.897991	f	\N	\N	\N	\N	\N	4
102	983	Monthly	active	НД	\N	\N	Тетяна	+380953656882	@latyshev_dn	Київ	вул. Митрополита Василя Липківського 15	\N	\N	\N	f	61 кв.	courier	M	\N	\N	\N	хлопець дівчині	\N	Квіти - білі, бежеві та інші не яскраві кольори (не червоні, не жовті, не рожеві та інше; за можливістю).\nчас з отримувачем узгоджувати\nале самовивіз саме із замовником	f	f	\N	\N	2026-04-22 17:15:51.907942	f	\N	\N	\N	\N	\N	4
103	984	Bi-weekly	active	СБ	\N	\N	Анатолій	+380636235750	0 50 442 57 57 (телеграм Anatoliy)	Київ	вулиця Іоанна Павла II, 6/1	\N	\N	\N	f	\N	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.918695	f	\N	\N	\N	\N	\N	4
104	985	Bi-weekly	active	НД	\N	\N	Андрій	+380507831054	@andrew_light	Київ	вулиця Тулузи 2/58	\N	\N	\N	f	кв 6	courier	M	\N	\N	\N	хлопець дівчині	\N	будь ласка без лілій, гіацинтів, нарцисів	f	f	pending	\N	2026-04-22 17:15:51.9295	t	\N	\N	\N	\N	\N	4
105	986	Weekly	active	СБ	\N	\N	Світлана	+380633345654	0633345654(вотцап)	Київ	вулиця Авiаконструктора Iгоря Сікорського 4д	\N	\N	\N	f	1 під'їзд, 8 поверх, кв 35	courier	XL	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.9295	f	\N	\N	\N	\N	\N	4
106	987	Monthly	active	НД	\N	\N	Катерина	+380663138847	pavel_a_kukharenko	Київ	проспект Володимира Івасюка 27а	\N	\N	\N	f	Під'їзд 3\nПоверх 8\nКв. 309	courier	M	\N	\N	\N	хлопець дівчині	\N	Є дві адреси у отримувача тому краще мабуть уточняти у нього перед доставко	f	f	\N	\N	2026-04-22 17:15:51.947495	f	\N	\N	\N	\N	\N	4
107	988	Weekly	active	СБ	\N	\N	Яна	+380950876846	@Vladosta	Чернівці	Чернівці	\N	\N	\N	f	вул Героїв Майдану 55 підʼїзд 2 кВ 20\nЯна	courier	L	\N	\N	\N	хлопець дівчині	\N	відправляти у суботу, щоб отримали у неділю	f	f	pending	\N	2026-04-22 17:15:51.956147	t	\N	\N	\N	\N	\N	4
108	989	Weekly	active	НД	\N	\N	Максим	+380668217997	0956810351(вотцап)	Київ	провулок Лобачевського  7	\N	\N	\N	f	3 секція, квартира 225	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.956147	f	\N	\N	\N	\N	\N	4
109	990	Monthly	active	НД	\N	\N	Олена	+380635821444	0937678147(вотцап)	Київ	вул. де Бальзака 46а	\N	\N	\N	f	7 поверх, 133 квартира	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.974169	f	\N	\N	\N	\N	\N	4
110	991	Weekly	active	НД	\N	\N	Яна	+380975314488	someonenew.vl	Київ	Приозерна 8А	\N	\N	\N	f	поверх 6, кв 42 (оболонь)	courier	M	\N	\N	\N		\N	\N	f	f	pending	\N	2026-04-22 17:15:51.982538	t	\N	\N	\N	\N	\N	4
111	992	Bi-weekly	active	СБ	\N	\N	Юлія	+380660136118	632113420(вайбер)	с. Петропавлівська Борщагівка	Оксамитова 9а	\N	\N	\N	f	\N	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:51.982538	f	\N	\N	\N	\N	\N	4
112	993	Monthly	active	ВТ	\N	\N	Ольга	+380676903863	goshamaksymiak	Київ	Василя Липківського 37в	\N	\N	\N	f	під'їзд 5, поверх 3, кв 404	courier	XL	\N	\N	\N	хлопець дівчині	\N	Просив робити наповнення за прикладами які скидав у дірект	f	f	\N	\N	2026-04-22 17:15:51.997019	f	\N	\N	\N	\N	\N	4
113	994	Monthly	active	НД	\N	\N	Ігор	+380674039910	@igor11112344	Київ	Регенераторна 4	\N	\N	\N	f	\N	courier	M	\N	\N	\N		\N	\N	f	f	\N	\N	2026-04-22 17:15:52.005562	f	\N	\N	\N	\N	\N	4
114	995	Weekly	active	СБ	\N	\N	Олексій	+380952943461	@ShitikovOl	Київ	Зарічна 1Г	\N	\N	\N	f	17 поверх, 160 квартира	courier	XL	\N	\N	\N	хлопець дівчині	\N	погоджувати доставки в телеграмі - @ShitikovOl	f	f	\N	\N	2026-04-22 17:15:52.01408	f	\N	\N	\N	\N	\N	4
115	996	Weekly	active	ЧТ	\N	\N	В'ячеслав	+380934729529	@Slagod	Київ	Проспект Оболонський 7-Б	\N	\N	\N	f	кв 83, 3 підʼїзд, 3 поверх	courier	XL	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.025049	f	\N	\N	\N	\N	\N	4
116	997	Bi-weekly	active	НД	\N	\N	Юлія	+380939821599	yuliia_nebesenko	Київ	Віктора Некрасова 8	\N	\N	\N	f	поверх 15, кв А122	courier	L	\N	\N	\N	дівчина собі	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.032926	f	\N	\N	\N	\N	\N	4
117	998	Bi-weekly	active	НД	\N	\N	Олександр Бородін	+380675080419	86boroda86	Рівне	поштомат номер 46346, якщо не влазить - Відділення НП номер 1 м.Дубно Рівненської обл.	\N	\N	\N	f	поштомат номер 46346, якщо не влазить - Відділення НП номер 1 м.Дубно Рівненської обл.	nova_poshta	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.040659	f	\N	\N	\N	\N	\N	4
118	999	Weekly	active	НД	\N	\N	Юлія	+380633579820	@tarasyukhym	Київ	Тираспольська 52	\N	\N	\N	f	642кв\n6 підʼїзд \n3 поверх\nАле перед заїздом наберіть шоб подзвонив на охорону і вас пропустили	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	pending	\N	2026-04-22 17:15:52.047921	t	\N	\N	\N	\N	\N	4
119	1000	Bi-weekly	active	НД	\N	\N	Оксана	+380507010477	Oxana Oxana	Київ	проспект Дмитра Павличка 3	\N	\N	\N	f	кв 158	courier	M	\N	\N	\N	дівчина собі	\N	Oxana Oxana - телеграм	f	f	\N	\N	2026-04-22 17:15:52.047921	f	\N	\N	\N	\N	\N	4
120	1001	Weekly	active	ПН	\N	\N	Vitalii Kharechko	+380673720032	vitaliyharechko	Львів	Львів	\N	\N	\N	f	Vitalii Kharechko\nвулиця Стрийська  111 )Е \nЛьвів Україна, 79045\n0673720032	courier	M	\N	\N	\N	хлопець дівчині	\N	Замовляю через сайт і відразу щоб не забути ідею цитат\n\nРомантичні цитати з твору «маленький принц»:  \n1) «Кохати — це не дивитися одне на одного, а дивитися разом в одному напрямку». \n2) «Ось мій секрет, він дуже простий: пильне одне лише серце. Найголовнішого очима не побачиш».3) «Вночі, коли ти будеш дивитися на небо, ти побачиш мою зірку, ту, на якій я живу, на якій я сміюся. І ти почуєш, що всі зірки сміються».	f	f	pending	\N	2026-04-22 17:15:52.06436	t	\N	\N	\N	\N	\N	4
121	1002	Weekly	active	СБ	\N	\N	Тетяна	+380674489130	tanushkas2009	Київ	Проспект Володимира Івасюка 6ак2	\N	\N	\N	f	22 поверх, 240 квартира	courier	M	\N	\N	\N	дівчина собі	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.06436	f	\N	\N	\N	\N	\N	4
123	1003	Weekly	active	СБ	\N	\N	Людмила	+380672243986	@LudmilaIvanets	Київ	вул. Ярославська, 32-А	\N	\N	\N	f	Поділ \nу двір заходити НЕ ТРЕБА \n1 підʼїзд з вулиці \n\nОрієнтир: \nРесторан Pan Chang \nЯкщо на нього дивитись, то другі двері справа \nПід вивіскою, 32-А \n\nКод: 5 \nПоверх: 3 \nКвартира: 5	courier	L	\N	\N	\N	дівчина іншій дівчині	\N	@LudmilaIvanets, сама будет писать когда отправлять букеты, \nПрошу більше не кидати в коробку яку везуть мені конфеті \n1. Курʼєр не має дзвонити в двері. Ні в домофон, ні в двері квартири. В мене маленька дитина.\nПо квітам \nЯ люблю кольорові букети «а-ля з бабусиного саду» \nВ цілому такі як ц вас в референсі на сайті же замовлення підписки \n\n Екзотика для мене це якісь не стандартні квітки. Типу волохаті всякі \nБутони великі як фрукт \nМене вони трохи лякають 😂\nТипу такі як на фото \nІ схожі \nЯкісь типу чорні чи темні теж не подобаються \nЩе не подобаються типу сухі. Не знаю як пояснити \nЯк шишки \nЦе все не кладіть будь ласка	f	f	\N	\N	2026-04-22 17:15:52.072822	f	\N	\N	\N	\N	\N	4
124	1004	Weekly	active	ПТ	\N	\N	Дарина	+380638908362	@babys_dora	Київ	Олени Теліги  25	\N	\N	\N	f	\N	courier	XL	\N	\N	\N	хлопець дівчині	\N	@babys_dora	f	f	pending	\N	2026-04-22 17:15:52.084654	t	\N	\N	\N	\N	\N	4
125	1005	Bi-weekly	active	СБ	\N	\N	Катерина	+380504071653	Kate (телеграм)	Київ	вул Олега Мудрака 66	\N	\N	\N	f	кв 12	courier	L	\N	\N	\N	дівчина собі	\N	яскраві букети, екзотика	f	f	\N	\N	2026-04-22 17:15:52.084654	f	\N	\N	\N	\N	\N	4
126	1006	Bi-weekly	active	СБ	\N	\N	Анастасія	+380501602583	@sergii_z	Київ	Берестейський проспект 37/2	\N	\N	\N	f	\N	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.096053	f	\N	\N	\N	\N	\N	4
127	1007	Weekly	active	СБ	\N	\N	Даша	+380671326366	@hellsiss	Київ	Вул. Байди-Вишневецького буд. 9	\N	\N	\N	f	поверх 9, кв 25	courier	XL	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.106264	f	\N	\N	\N	\N	\N	4
128	1008	Monthly	active	СБ	\N	\N	Дмитро	+380669003305	@Bronsboro	Київ	Фортечний Тупик 6/8	\N	\N	\N	f	під'їзд 6, поверх 4, кв 122	courier	XL	\N	\N	\N	хлопець дівчині	\N	Якщо доставка до 14 години\nто отримувач я\nДмитро 0669003305\nякщо після то Катерина 0994377946\nвсі квіти підходять\nЯкщо у вас є листівки з Днем Народження, то я б хотів якісь різні в обидва букети\nце на день народження мамі та бабусі	f	f	\N	\N	2026-04-22 17:15:52.112562	f	\N	\N	\N	\N	\N	4
130	1009	Monthly	active	ПТ	\N	\N	Яніна	+380505734831	byinnastef 1	Чернівці	Чернівці	\N	\N	\N	f	м. Чернівці, Фотокакіс Яніна Костянтинівна. Поштомат 56232, відділення 17 Чернівці	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	"Весняні любі квіти\nХоч польові 🤣\nЧим простіші тим краще"\nЛистівка потрібна.\nПисати щоразу "Ти варта найкращого"	f	f	\N	\N	2026-04-22 17:15:52.12047	f	\N	\N	\N	\N	\N	4
131	1010	Monthly	active	СР	\N	\N	Дмитро	+380936546643	@dimalavrishyn	Львів	Львів	\N	\N	\N	f	.Львів, 52 відділення\n+380936546643\nЛаврішин Дмитро	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.131584	f	\N	\N	\N	\N	\N	4
132	1011	Weekly	active	ЧТ	\N	\N	Катерина Годунок	+380672507615	@q_salllko_p	Вінниця	Вінниця	\N	\N	\N	f	Вінниця, Відділення #4\n Поштомат #58106	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	pending	\N	2026-04-22 17:15:52.141899	t	\N	\N	\N	\N	\N	4
133	1012	Weekly	active	СБ	\N	\N	Ганна	+380689374919	annanetrebskaia	Крюківщина, Київська обл.	Відродження 316а	\N	\N	\N	f	Крюківщина, Відродження 316а КМ «Беверлі Хілз»	courier	L	\N	\N	\N	дівчина іншій дівчині	\N	annanetrebskaia	f	f	\N	\N	2026-04-22 17:15:52.141899	f	\N	\N	\N	\N	\N	4
134	1013	Weekly	active	СБ	\N	\N	Анна	+380732145953	@UkotugoroshkoU	Київ	Проспект Голосіївський 68	\N	\N	\N	f	3 під’їзд, 146 квартира	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.157815	f	\N	\N	\N	\N	\N	4
135	1014	Weekly	active	СБ	\N	\N	Марія	+380950951649	Марія Горобець(телеграм)	Київ	Причальна 14	\N	\N	\N	f	кв 71, 6 поверх	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	Марія Горобець(телеграм)	f	f	\N	\N	2026-04-22 17:15:52.170024	f	\N	\N	\N	\N	\N	4
136	1015	Weekly	active	НД	\N	\N	Лілія	+380955793157	0999855321(вотсап)	Київ	Соборності 17к2	\N	\N	\N	f	зателефонувати за декілька хвилин щоб зробили заявку на пропуск	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.178391	f	\N	\N	\N	\N	\N	4
137	1016	Bi-weekly	active	СР	\N	\N	Качмарик Марія	+380685412887	vania_fomchuk	Запоріжжя	Місто Запоріжжя нова пошта 68	\N	\N	\N	f	Місто Запоріжжя нова пошта 68	nova_poshta	XL	\N	\N	\N	хлопець дівчині	\N	Попросив відправляти так: Місто Запоріжжя нова пошта 68 .\nІм'я відправника: Фомчук Іван \n0673260403\nІм'я отримувача : Качмарик Марія\n0685412887\nЗа доставку платять вони в додатку\nКвіти які не бажані до відправлення троянда\nКвіти які обожнює гортензія , півонії , ромашки ,  тюльпани ранункулюс	f	f	\N	\N	2026-04-22 17:15:52.185083	f	\N	\N	\N	\N	\N	4
138	1017	Bi-weekly	active	СБ	\N	\N	Ольга	+380972449990	@bohdan_tkachuk	Київ	вулиця Олени Теліги 7	\N	\N	\N	f	\N	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.192874	f	\N	\N	\N	\N	\N	4
139	1018	Bi-weekly	active	СБ	\N	\N	Дмитро	+380932107088	@o_karbovs	Київ	вулиця Василя Липківського  37Б	\N	\N	\N	f	підʼїзд 4, поверх 20, кв 348\nКиїв, Україна 03035	courier	M	\N	\N	\N	хлопець дівчині	\N	@o_karbovs	f	f	\N	\N	2026-04-22 17:15:52.203207	f	\N	\N	\N	\N	\N	4
140	1019	Weekly	active	СР	\N	\N	Олександра	+380634917882	_l.e.b.e.d	Київ	вул.Аболмасова 6	\N	\N	\N	f	Там один будинок, тобто 1 підʼїзд, 15 поверх, 82 квартира, ліфт завжди працює, Є дзвіночок до консьєржа на воротах	courier	M	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.212931	f	\N	\N	\N	\N	\N	4
141	1020	Bi-weekly	active	НД	\N	\N	Марія	+380939853394	@mrrbanana	Київ	вул. Воскресенська 2в	\N	\N	\N	f	1 секція, 10 поверх, 75	courier	M	\N	\N	\N	хлопець дівчині	\N	@mrrbanana	f	f	\N	\N	2026-04-22 17:15:52.218356	f	\N	\N	\N	\N	\N	4
142	1021	Weekly	active	НД	\N	\N	Анастасія	+380952023484	@morozoovvva	Київ	Андрія Верхогляда, 19б	\N	\N	\N	f	поверх 10, кв 53	courier	L	\N	\N	\N	хлопець дівчині	\N	час узгодити з отримувачем - @morozoovvva	f	f	\N	\N	2026-04-22 17:15:52.226886	f	\N	\N	\N	\N	\N	4
143	1022	Bi-weekly	active	ВТ	\N	\N	Поліна	+380669973616	adaline.pelykh	Київ	Василя Липківського 33А	\N	\N	\N	f	\N	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.239405	f	\N	\N	\N	\N	\N	4
144	1023	Bi-weekly	active	НД	\N	\N	Вікторія	+380935878272	@ryasna	Київ	Набережно-Лугова 3а	\N	\N	\N	f	кв 53. Підʼїзд 3, поверх 4. Домофон 53	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	@ryasna\nПерша доставка - 19.04 \nДалі : \n03.05 \n17.05 \n07.06	f	f	\N	\N	2026-04-22 17:15:52.252025	f	\N	\N	\N	\N	\N	4
145	1024	Bi-weekly	active	ПН	\N	\N	Тетяна	+380979259809	0.antoxa.0	Софіївська Борщагівка	вул Райдужна 88	\N	\N	\N	f	кв 80, поверх 4	courier	L	\N	\N	\N	хлопець дівчині	\N	не хотіли б жовті троянди, узгоджувати з отримувачем, краще писати, не телефонувати бо маленька дитина	f	f	\N	\N	2026-04-22 17:15:52.263186	f	\N	\N	\N	\N	\N	4
146	1025	Weekly	active	НД	\N	\N	Михайло	+380503116161	0503116161 (вайбер)	Петропавлівська Борщагівка	вул Паркова 22	\N	\N	\N	f	\N	courier	XL	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-22 17:15:52.27792	f	\N	\N	\N	\N	\N	4
147	1026	Bi-weekly	active	НД	\N	\N	Олексій	+380639537363	justblin_	Київ	Столичне шосе 103	\N	\N	\N	f	(Голосіївський район)	courier	M	\N	\N	\N	корпоративна підписка	\N	буде писати за декілька днів до замовлення	f	f	\N	\N	2026-04-22 17:15:52.296333	f	\N	\N	\N	\N	\N	4
19	911	Weekly	active	СБ	\N	\N	Ніна	+380689841170	@drive_me_blind	Київ		\N	\N	\N	f	\N	courier	L	\N	\N	\N	хлопець дівчині	\N	погоджувати в телеграмі - @drive_me_blind\nдоставка по суботам у першій половині дня, десь о 10й. \nбез мімози та квітів з специфічним запахом	f	f	declined	2026-04-23 11:46:38.337241	2026-04-22 17:15:51.370687	t	\N	\N	\N	\N	\N	4
148	939	Bi-weekly	active	СБ	\N	\N	Анастасія	+380973124469	@Vasily_Baranovsky	Київ	Котельникова 17	\N	\N	\N	f	12 поверх, кв. 55	courier	L	\N	\N	\N	хлопець дівчині	\N	доставки узгоджувати із замовником, писати в телеграм	f	f	\N	\N	2026-04-23 11:57:11.400746	f	\N	\N	\N	\N	10	4
149	915	Bi-weekly	active	СБ	\N	\N	Олександра	+380996660001	max.ellisen	Київ	ул. Ентузіастов 11	\N	\N	\N	f	3й під'їзд (навпроти трансформаторної будки), 2 поверх, кв. 67	courier	L	\N	\N	\N	хлопець дівчині	\N	\N	f	f	\N	\N	2026-04-23 15:35:04.86588	f	\N	\N	\N	\N	10	4
150	1027	Weekly	active	СБ	\N	\N	Дарія	+380506819961	@mitr	Київ	Каземира Малевича 48	\N	\N	\N	f	5 підʼїзд, 8 поверх, 82 кв. (код до дверей: 123)	courier	XL	\N	\N	\N	хлопець дівчині	ваза+ножиці\r\nЛистівка: "Кохаю тебе"	не класти троянди	f	f	\N	\N	2026-04-23 19:07:40.967399	f	\N	\N	\N	\N	\N	6
151	973	Weekly	active	СБ	09:00	12:00	Сергій	+380509536315	\N	Київ	Монтажників 107	\N	\N	\N	f	 (приватний будинок)	courier	L	\N	\N	\N	хлопець дівчині	\N	сюди дві коробки М та Л, треба щоб було різне наповнення	f	f	\N	\N	2026-04-24 10:52:22.153547	f	\N	\N	\N	\N	10	4
87	973	Weekly	active	СБ	\N	\N	Сергій	+380509536315	@n0okOne	Київ	Монтажників 107	\N	\N	\N	f	(приватний будинок)	courier	L	\N	\N	\N	хлопець дівчині	\N	сюди дві коробки М та Л, треба щоб було різне наповнення	f	f	pending	\N	2026-04-22 17:15:51.814097	f	\N	\N	\N	\N	\N	4
122	973	Weekly	active	СБ	\N	\N	Сергій	+380509536315	@n0okOne 1	Київ	Січових Стрельців 68	\N	\N	\N	f	Шоурум Бібліотека	courier	XL	\N	\N	\N	дівчина собі	\N	\N	f	f	pending	\N	2026-04-22 17:15:52.072822	f	\N	\N	\N	\N	\N	4
152	814	Bi-weekly	active	СБ	10:00	13:00	Ольга	+380676012283	\N	Київ	Анни Ахматової 18	\N	\N	\N	f	12 поверх, 55 квартира 	courier	M	\N	\N	\N	дівчина іншій дівчині	доставки узгоджувати з отримувачем у вотсап - залишати у консьєржа	\N	f	f	\N	\N	2026-04-24 11:36:27.452431	f	\N	\N	\N	\N	10	4
31	814	Bi-weekly	active	СБ	\N	\N	Ольга	+380676012283	darya_brill	Київ	Анни Ахматової 18	\N	\N	\N	f	12 поверх, 55 квартира	courier	M	\N	\N	\N	дівчина іншій дівчині	\N	доставки узгоджувати з отримувачем у вотсап	f	f	pending	\N	2026-04-22 17:15:51.442219	f	\N	\N	\N	\N	\N	4
153	835	Bi-weekly	active	СБ	09:00	22:30	Анна	+380675030997	\N	Київ	проспект Соборності 30 	\N	\N	\N	f	\N	courier	XL	\N	\N	\N	дівчина собі	\N	\N	f	f	\N	\N	2026-04-24 12:05:11.937824	f	\N	\N	\N	\N	5	4
154	1028	Weekly	active	ПН	\N	\N	Поліна	+380508542523	\N	Київ	треба уточнити	\N	\N	\N	f	\N	courier	M	\N	\N	\N	дівчина іншій дівчині	уточнити всі деталі у отримувача, ще не оплачено	\N	f	f	\N	\N	2026-04-24 13:47:32.103541	f	\N	\N	\N	\N	\N	4
155	1009	Weekly	active	СБ	\N	\N	Інна	+380954081262	\N	Чернівці	НП, м. Чернівці, поштомат 25392, Стефанець Інна, 0954081262	\N	\N	\N	f	\N	nova_poshta	L	\N	\N	\N	дівчина іншій дівчині	\N	"Точно ранунклюс, півонія та еустома(знає що не відправляємо новою поштою півонії і еустоми, можливо щось подібне відправляти). Багато дивної і цікавої зелені. Можна хвою чи лопузи якісь навіть.\r\n\r\nНепотрібні гербери, троянди, лілії та решта із солодким стійким ароматом. \r\n"	f	f	\N	\N	2026-04-24 14:17:17.694916	f	\N	\N	\N	\N	\N	1
129	1009	Weekly	active	ПТ	\N	\N	Інна	+380954081262	byinnastef	Чернівці	НП, м. Чернівці, поштомат 25392, Стефанець Інна, 0954081262	\N	\N	\N	f	НП, м. Чернівці, поштомат 25392, Стефанець Інна, 0954081262	nova_poshta	L	\N	\N	\N	дівчина собі	\N	Точно ранунклюс, півонія та еустома(знає що не відправляємо новою поштою півонії і еустоми, можливо щось подібне відправляти). Багато дивної і цікавої зелені. Можна хвою чи лопузи якісь навіть.\n\nНепотрібні гербери, троянди, лілії та решта із солодким стійким ароматом.	f	f	pending	\N	2026-04-22 17:15:52.12047	f	\N	\N	\N	\N	\N	4
156	916	Weekly	active	НД	09:00	12:00	Людмила	+380676301500	\N	Київ	бульвар Миколи Міхновського, 14-16	\N	\N	\N	f	 1 секція, забирають внизу	courier	L	\N	\N	\N	дівчина собі	1а, треба взяти готівку 7920 за підписку, потрібен наш кур'єр	Останній раз писала з інсти: karlustemi	f	f	\N	\N	2026-04-24 15:17:24.331016	f	\N	\N	\N	\N	5	4
157	1035	Monthly	active	ВТ	\N	\N	Карина	+380636994090	\N	Київ	Європейського союзу 41Г	\N	\N	\N	f	кв 110	courier	M	\N	\N	\N	хлопець дівчині	Додати листівку: Привітання з днем весілля	\N	f	f	\N	\N	2026-04-25 09:28:01.557836	f	\N	\N	\N	\N	10	4
\.


--
-- Data for Name: transaction; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.transaction (id, transaction_type, client_id, amount, payment_type, expense_type, comment, date, created_at) FROM stdin;
1	credit	915	7920	monobank	\N	\N	2026-04-23	2026-04-23 15:37:47.527077
2	credit	835	10260	monobank	\N	\N	2026-04-24	2026-04-24 18:14:10.103331
3	credit	1031	2910	monobank	\N	\N	2026-04-24	2026-04-24 18:20:32.259168
4	credit	1029	3300	monobank	\N	\N	2026-04-24	2026-04-24 18:21:44.106047
5	credit	1032	2100	monobank	\N	\N	2026-04-24	2026-04-24 18:24:23.233585
6	credit	1030	2200	monobank	\N	\N	2026-04-24	2026-04-24 18:25:01.364588
7	credit	1031	740	monobank	\N	\N	2026-04-25	2026-04-25 07:30:07.719299
8	credit	1034	4000	monobank	\N	\N	2026-04-25	2026-04-25 08:52:04.690272
9	credit	965	2900	monobank	\N	\N	2026-04-25	2026-04-25 17:40:45.883856
10	credit	1036	3240	monobank	\N	\N	2026-04-25	2026-04-25 17:41:41.219116
11	credit	1037	2700	monobank	\N	\N	2026-04-24	2026-04-25 17:45:30.658934
\.


--
-- Data for Name: user; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public."user" (id, email, username, password_hash, is_active, created_at, last_login, user_type, display_name, last_seen) FROM stdin;
5	Natalka@crm.local	Natalka	scrypt:32768:8:1$eiBHAGtk0cTxDbb8$da7d635400e9b1d59c748f633c7cd6020ba1f731ef67e41a8763f3bbf526736325792b27f01cdacf888ac8636ddeaf8aee0d960151800bb0c6d3010a01078f21	t	2026-04-24 07:12:21.519292	2026-04-25 15:33:31.253546	manager	Наталя	2026-04-25 17:45:03.497282
2	vbilobrov@crm.local	vbilobrov	scrypt:32768:8:1$DI7bJYfyFHL6u1Lz$bff845ed01ec2c8a02d26494c318edc806c9ad5479753d39c728c1e087895d4866894b3a81e2a8fa9842219e20a6c0a68e4a304c0172d2ad60fdfde48a87fbbf	t	2026-04-22 17:16:09.26701	2026-04-24 10:26:06.937754	admin	Влад Білобров	2026-04-25 19:26:20.644985
3	pahanchik@crm.local	pahanchik	scrypt:32768:8:1$fpEOwH2zRpF7Avwg$86ea6fd421e03e0a28d630876a7d974158d4526f5c69d5ef87b5b14ea99cb4e55f5ad6035488748e42a79266d7f0197e1eef0548ffbb82c3496128aa1fc72e0b	t	2026-04-23 11:34:19.494362	2026-04-23 11:41:50.614283	manager	Павло	2026-04-24 18:35:10.815116
4	anna_florist@crm.local	anna_florist	scrypt:32768:8:1$51L7xg23SFh6Xg8A$674438bc677061c7ce0d215a02ce8abadabeca70da7948ed8fab58a23284ae3d07f7e40e9efa5f2e615de32c108b474f9287cbfa920d284fdabca322c2aa144d	t	2026-04-23 18:51:19.359065	2026-04-25 10:34:58.267373	florist	Анна	2026-04-25 13:34:15.699372
1	admin@kvitkovapovnya.com	admin	scrypt:32768:8:1$OYBC69ntyun44yed$e284da5e5b9ee28c93d7f53ea2b749e1bfec0b27ec97e5c4ddf08e81c084d998792e0482d191ce5978034461952f1a03f777b24db25f24404b685d0950cd69cd	t	2026-04-22 17:14:26.216385	2026-04-23 18:41:09.373734	admin	\N	2026-04-25 09:59:55.811505
6	Natalya_florist@crm.local	Natalya_florist	scrypt:32768:8:1$1DNlK7H1lDQVAxF1$476242c6ffbf5105a31532b465e5ffb2e325f068a9421a94eb44638edf50a12ae5672f085cf04362adb68c5a2738ce43536595cb4a8b552402a9279e1ce6c491	t	2026-04-24 15:59:08.06962	2026-04-24 16:11:39.706043	florist	наталя (флорист)	2026-04-24 16:11:39.826079
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: kvitkova_user
--

COPY public.user_roles (user_id, role_id) FROM stdin;
1	1
3	2
2	1
4	3
5	2
6	3
\.


--
-- Name: activity_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.activity_log_id_seq', 1, false);


--
-- Name: ai_agent_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.ai_agent_log_id_seq', 1, false);


--
-- Name: certificates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.certificates_id_seq', 1, false);


--
-- Name: client_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.client_id_seq', 1037, true);


--
-- Name: courier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.courier_id_seq', 8, true);


--
-- Name: delivery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.delivery_id_seq', 260, true);


--
-- Name: delivery_routes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.delivery_routes_id_seq', 40, true);


--
-- Name: florist_sale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.florist_sale_id_seq', 1, false);


--
-- Name: order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.order_id_seq', 260, true);


--
-- Name: prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.prices_id_seq', 1, false);


--
-- Name: recipient_phone_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.recipient_phone_id_seq', 10, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.roles_id_seq', 3, true);


--
-- Name: route_deliveries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.route_deliveries_id_seq', 376, true);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.settings_id_seq', 34, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.subscription_id_seq', 157, true);


--
-- Name: transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.transaction_id_seq', 11, true);


--
-- Name: user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: kvitkova_user
--

SELECT pg_catalog.setval('public.user_id_seq', 6, true);


--
-- Name: activity_log activity_log_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_pkey PRIMARY KEY (id);


--
-- Name: ai_agent_log ai_agent_log_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.ai_agent_log
    ADD CONSTRAINT ai_agent_log_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: client client_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.client
    ADD CONSTRAINT client_pkey PRIMARY KEY (id);


--
-- Name: courier courier_phone_key; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.courier
    ADD CONSTRAINT courier_phone_key UNIQUE (phone);


--
-- Name: courier courier_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.courier
    ADD CONSTRAINT courier_pkey PRIMARY KEY (id);


--
-- Name: delivery delivery_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.delivery
    ADD CONSTRAINT delivery_pkey PRIMARY KEY (id);


--
-- Name: delivery_routes delivery_routes_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.delivery_routes
    ADD CONSTRAINT delivery_routes_pkey PRIMARY KEY (id);


--
-- Name: florist_sale florist_sale_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.florist_sale
    ADD CONSTRAINT florist_sale_pkey PRIMARY KEY (id);


--
-- Name: order order_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_pkey PRIMARY KEY (id);


--
-- Name: prices prices_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT prices_pkey PRIMARY KEY (id);


--
-- Name: recipient_phone recipient_phone_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.recipient_phone
    ADD CONSTRAINT recipient_phone_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: route_deliveries route_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.route_deliveries
    ADD CONSTRAINT route_deliveries_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: subscription subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.subscription
    ADD CONSTRAINT subscription_pkey PRIMARY KEY (id);


--
-- Name: transaction transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT transaction_pkey PRIMARY KEY (id);


--
-- Name: certificates uq_certificates_code; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT uq_certificates_code UNIQUE (code);


--
-- Name: prices uq_price_sub_size; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT uq_price_sub_size UNIQUE (subscription_type_id, size_id);


--
-- Name: user user_email_key; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_email_key UNIQUE (email);


--
-- Name: user user_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: user user_username_key; Type: CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public."user"
    ADD CONSTRAINT user_username_key UNIQUE (username);


--
-- Name: ix_activity_log_created_at; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_activity_log_created_at ON public.activity_log USING btree (created_at);


--
-- Name: ix_certificates_status; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_certificates_status ON public.certificates USING btree (status);


--
-- Name: ix_client_instagram; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_client_instagram ON public.client USING btree (instagram);


--
-- Name: ix_delivery_client_id; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_delivery_client_id ON public.delivery USING btree (client_id);


--
-- Name: ix_delivery_courier_id; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_delivery_courier_id ON public.delivery USING btree (courier_id);


--
-- Name: ix_delivery_delivery_date; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_delivery_delivery_date ON public.delivery USING btree (delivery_date);


--
-- Name: ix_delivery_order_id; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_delivery_order_id ON public.delivery USING btree (order_id);


--
-- Name: ix_delivery_status; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_delivery_status ON public.delivery USING btree (status);


--
-- Name: ix_florist_sale_created_at; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_florist_sale_created_at ON public.florist_sale USING btree (created_at);


--
-- Name: ix_florist_sale_florist_id; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_florist_sale_florist_id ON public.florist_sale USING btree (florist_id);


--
-- Name: ix_order_client_id; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_order_client_id ON public."order" USING btree (client_id);


--
-- Name: ix_order_subscription_id; Type: INDEX; Schema: public; Owner: kvitkova_user
--

CREATE INDEX ix_order_subscription_id ON public."order" USING btree (subscription_id);


--
-- Name: activity_log activity_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.activity_log
    ADD CONSTRAINT activity_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id) ON DELETE SET NULL;


--
-- Name: delivery delivery_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.delivery
    ADD CONSTRAINT delivery_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: delivery delivery_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.delivery
    ADD CONSTRAINT delivery_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.courier(id);


--
-- Name: delivery delivery_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.delivery
    ADD CONSTRAINT delivery_order_id_fkey FOREIGN KEY (order_id) REFERENCES public."order"(id);


--
-- Name: delivery_routes delivery_routes_courier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.delivery_routes
    ADD CONSTRAINT delivery_routes_courier_id_fkey FOREIGN KEY (courier_id) REFERENCES public.courier(id);


--
-- Name: ai_agent_log fk_ai_agent_log_user_id; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.ai_agent_log
    ADD CONSTRAINT fk_ai_agent_log_user_id FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- Name: certificates fk_certificates_created_by_user_id; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT fk_certificates_created_by_user_id FOREIGN KEY (created_by_user_id) REFERENCES public."user"(id);


--
-- Name: certificates fk_certificates_order_id; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT fk_certificates_order_id FOREIGN KEY (order_id) REFERENCES public."order"(id);


--
-- Name: order fk_order_subscription_id; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT fk_order_subscription_id FOREIGN KEY (subscription_id) REFERENCES public.subscription(id);


--
-- Name: recipient_phone fk_recipient_phone_order_id; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.recipient_phone
    ADD CONSTRAINT fk_recipient_phone_order_id FOREIGN KEY (order_id) REFERENCES public."order"(id);


--
-- Name: transaction fk_transaction_client_id; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.transaction
    ADD CONSTRAINT fk_transaction_client_id FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: florist_sale florist_sale_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.florist_sale
    ADD CONSTRAINT florist_sale_created_by_fkey FOREIGN KEY (created_by) REFERENCES public."user"(id);


--
-- Name: florist_sale florist_sale_florist_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.florist_sale
    ADD CONSTRAINT florist_sale_florist_id_fkey FOREIGN KEY (florist_id) REFERENCES public."user"(id);


--
-- Name: order order_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public."order"
    ADD CONSTRAINT order_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: prices prices_size_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT prices_size_id_fkey FOREIGN KEY (size_id) REFERENCES public.settings(id) ON DELETE CASCADE;


--
-- Name: prices prices_subscription_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.prices
    ADD CONSTRAINT prices_subscription_type_id_fkey FOREIGN KEY (subscription_type_id) REFERENCES public.settings(id) ON DELETE CASCADE;


--
-- Name: route_deliveries route_deliveries_delivery_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.route_deliveries
    ADD CONSTRAINT route_deliveries_delivery_id_fkey FOREIGN KEY (delivery_id) REFERENCES public.delivery(id);


--
-- Name: route_deliveries route_deliveries_route_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.route_deliveries
    ADD CONSTRAINT route_deliveries_route_id_fkey FOREIGN KEY (route_id) REFERENCES public.delivery_routes(id);


--
-- Name: subscription subscription_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.subscription
    ADD CONSTRAINT subscription_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.client(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id);


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: kvitkova_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public."user"(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 4lupL01gFYERhCRWpDS0YLO50RlG5zsZwGvDE9DY2NJZf8PODQYRVnApyo68HCP

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict CLj0Vvk0qfShg7rEmIr9UmPqucBqe4t9nzmIKgOqEz0nQPYOZkIjeIfUZwZ5bYi

-- Dumped from database version 15.17
-- Dumped by pg_dump version 15.17

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict CLj0Vvk0qfShg7rEmIr9UmPqucBqe4t9nzmIKgOqEz0nQPYOZkIjeIfUZwZ5bYi

--
-- PostgreSQL database cluster dump complete
--

